package com.v2ray.ang.handler

import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

class AppForegroundTrackerTest {
    @BeforeEach
    fun setUp() = AppForegroundTracker.resetForTest()

    @AfterEach
    fun tearDown() = AppForegroundTracker.resetForTest()

    @Test
    fun `background until an activity starts`() {
        assertFalse(AppForegroundTracker.isInForeground)
        AppForegroundTracker.onActivityStarted()
        assertTrue(AppForegroundTracker.isInForeground)
    }

    @Test
    fun `recreating an activity keeps the app in the foreground`() {
        AppForegroundTracker.onActivityStarted()
        AppForegroundTracker.onActivityStarted() // new instance starts before the old one stops
        AppForegroundTracker.onActivityStopped()
        assertTrue(AppForegroundTracker.isInForeground)
    }

    @Test
    fun `returns to background after the last activity stops and never goes negative`() {
        AppForegroundTracker.onActivityStarted()
        AppForegroundTracker.onActivityStopped()
        assertFalse(AppForegroundTracker.isInForeground)
        AppForegroundTracker.onActivityStopped()
        assertFalse(AppForegroundTracker.isInForeground)
        AppForegroundTracker.onActivityStarted()
        assertTrue(AppForegroundTracker.isInForeground)
    }
}
