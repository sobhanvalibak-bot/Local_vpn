package com.v2ray.ang.handler

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class AutoConnectSelectorTest {

    @Test
    fun `one failed probe is not enough to switch`() {
        assertFalse(AutoConnectSelector.shouldSwitch(0))
        assertFalse(AutoConnectSelector.shouldSwitch(AutoConnectSelector.FAILURES_BEFORE_SWITCH - 1))
        assertTrue(AutoConnectSelector.shouldSwitch(AutoConnectSelector.FAILURES_BEFORE_SWITCH))
    }

    @Test
    fun `candidates drop excluded profiles and duplicates but keep order`() {
        val result = AutoConnectSelector.candidates(
            all = listOf("a", "b", "a", "c", "d"),
            excluded = setOf("b", "d"),
        )

        assertEquals(listOf("a", "c"), result)
    }

    @Test
    fun `candidates of an empty store are empty`() {
        assertEquals(emptyList<String>(), AutoConnectSelector.candidates(emptyList(), setOf("x")))
    }

    @Test
    fun `shortlist takes the fastest successful profiles and ignores failures`() {
        val round = mapOf("slow" to 900L, "fast" to 80L, "dead" to -1L, "untested" to 0L, "mid" to 200L, "ok" to 150L)

        assertEquals(listOf("fast", "ok", "mid"), AutoConnectSelector.shortlist(round))
    }

    @Test
    fun `shortlist breaks ties by guid so the order is stable`() {
        assertEquals(listOf("a", "b"), AutoConnectSelector.shortlist(mapOf("b" to 100L, "a" to 100L), size = 2))
    }

    @Test
    fun `shortlist is empty when nothing answered`() {
        assertEquals(emptyList<String>(), AutoConnectSelector.shortlist(mapOf("a" to -1L, "b" to 0L)))
        assertEquals(emptyList<String>(), AutoConnectSelector.shortlist(emptyMap()))
    }

    @Test
    fun `best profile has the lowest average over all rounds`() {
        val first = mapOf("a" to 100L, "b" to 120L)
        val second = mapOf("a" to 300L, "b" to 130L)

        assertEquals("b", AutoConnectSelector.pickBest(listOf(first, second), listOf("a", "b")))
    }

    @Test
    fun `a profile that failed in any round cannot win`() {
        val first = mapOf("fast" to 50L, "steady" to 200L)
        val second = mapOf("fast" to -1L, "steady" to 210L)

        assertEquals("steady", AutoConnectSelector.pickBest(listOf(first, second), listOf("fast", "steady")))
    }

    @Test
    fun `a profile missing from a round cannot win`() {
        val first = mapOf("a" to 50L, "b" to 200L)
        val second = mapOf("b" to 190L)

        assertEquals("b", AutoConnectSelector.pickBest(listOf(first, second), listOf("a", "b")))
    }

    @Test
    fun `equal averages prefer the lower worst case`() {
        val first = mapOf("jumpy" to 50L, "even" to 150L)
        val second = mapOf("jumpy" to 250L, "even" to 150L)

        assertEquals("even", AutoConnectSelector.pickBest(listOf(first, second), listOf("jumpy", "even")))
    }

    @Test
    fun `no winner without rounds or without a successful profile`() {
        assertNull(AutoConnectSelector.pickBest(emptyList(), listOf("a")))
        assertNull(AutoConnectSelector.pickBest(listOf(mapOf("a" to -1L)), listOf("a")))
        assertNull(AutoConnectSelector.pickBest(listOf(mapOf("a" to 10L)), emptyList()))
    }

    @Test
    fun `retry delay doubles and stops at the ceiling`() {
        assertEquals(30_000L, AutoConnectSelector.retryDelayMs(0, 30_000L, 300_000L))
        assertEquals(60_000L, AutoConnectSelector.retryDelayMs(1, 30_000L, 300_000L))
        assertEquals(120_000L, AutoConnectSelector.retryDelayMs(2, 30_000L, 300_000L))
        assertEquals(300_000L, AutoConnectSelector.retryDelayMs(5, 30_000L, 300_000L))
        assertEquals(300_000L, AutoConnectSelector.retryDelayMs(500, 30_000L, 300_000L))
        assertEquals(30_000L, AutoConnectSelector.retryDelayMs(-3, 30_000L, 300_000L))
    }
}
