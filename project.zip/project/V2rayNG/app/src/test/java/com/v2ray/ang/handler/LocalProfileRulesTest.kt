package com.v2ray.ang.handler

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class LocalProfileRulesTest {

    private val server = LocalShareServer(onConfigsReceived = {})

    @Test
    fun `plain text with a share link becomes a config message`() {
        val detected = LocalProfileRules.detectConfig(ChatPayload("text", "vless://a@h:1#My%20node"))
        assertEquals("config", detected.kind)
        assertEquals("vless://a@h:1#My%20node", detected.text)
    }

    @Test
    fun `several pasted links keep only the links`() {
        val detected = LocalProfileRules.detectConfig(ChatPayload("text", "look:\nvless://a@h:1\ntrojan://p@h:2\nthanks"))
        assertEquals("config", detected.kind)
        assertEquals("vless://a@h:1\ntrojan://p@h:2", detected.text)
    }

    @Test
    fun `text without links and other kinds stay unchanged`() {
        val text = ChatPayload("text", "hello there")
        assertEquals(text, LocalProfileRules.detectConfig(text))
        val image = ChatPayload("image", "", "abc")
        assertEquals(image, LocalProfileRules.detectConfig(image))
        val config = ChatPayload("config", "vless://a@h:1")
        assertEquals(config, LocalProfileRules.detectConfig(config))
    }

    @Test
    fun `names are trimmed, collapsed and capped`() {
        assertEquals("Ali Reza", LocalProfileRules.cleanName("  Ali \n  Reza  "))
        assertEquals(LocalProfileRules.MAX_NAME_CHARS, LocalProfileRules.cleanName("x".repeat(100)).length)
        assertEquals("", LocalProfileRules.cleanName("   "))
    }

    @Test
    fun `banner types are jpeg and mp4 only`() {
        assertTrue(LocalProfileRules.isValidBannerMime("video/mp4"))
        assertTrue(LocalProfileRules.isValidBannerMime("image/jpeg"))
        assertFalse(LocalProfileRules.isValidBannerMime("video/webm"))
        assertFalse(LocalProfileRules.isValidBannerMime(null))
    }

    @Test
    fun `link name comes from the fragment or falls back to the protocol`() {
        assertEquals("My node", LocalProfileRules.linkName("vless://a@h:1#My%20node"))
        assertEquals("VMESS", LocalProfileRules.linkName("vmess://eyJhIjoxfQ=="))
    }

    private val id = "0123456789abcdef0123456789abcdef"

    @Test
    fun `server accepts a profile with an avatar and keeps it`() {
        val profile = server.parsePayload("""{"kind":"profile","text":"Ali","image":"QUJD"}""")
        assertNotNull(profile)
        assertEquals("QUJD", profile?.image)
    }

    @Test
    fun `server accepts banner and file references`() {
        val banner = server.parsePayload("""{"kind":"banner","text":"{\"id\":\"$id\",\"name\":\"b.mp4\",\"size\":1000,\"mime\":\"video/mp4\"}"}""")
        assertEquals("banner", banner?.kind)
        val file = server.parsePayload("""{"kind":"file","text":"{\"id\":\"$id\",\"name\":\"a.zip\",\"size\":24000000,\"mime\":\"application/zip\"}"}""")
        assertEquals("file", file?.kind)
    }

    @Test
    fun `server rejects bad references and an empty profile`() {
        // Banner that is not an image or mp4.
        assertNull(server.parsePayload("""{"kind":"banner","text":"{\"id\":\"$id\",\"name\":\"b\",\"size\":10,\"mime\":\"video/webm\"}"}"""))
        // Over 25 MB.
        assertNull(server.parsePayload("""{"kind":"file","text":"{\"id\":\"$id\",\"name\":\"a\",\"size\":26214401,\"mime\":\"a/b\"}"}"""))
        // Id that is not a stored-file id.
        assertNull(server.parsePayload("""{"kind":"file","text":"{\"id\":\"../etc\",\"name\":\"a\",\"size\":10,\"mime\":\"a/b\"}"}"""))
        assertNull(server.parsePayload("""{"kind":"file","text":"not json"}"""))
        assertNull(server.parsePayload("""{"kind":"profile","text":" "}"""))
        assertNull(server.parsePayload("""{"kind":"unknown","text":"x"}"""))
    }

    @Test
    fun `file names lose path parts and control characters`() {
        assertEquals("evil.txt", LocalProfileRules.sanitizeFileName("../../evil.txt"))
        assertEquals("a.txt", LocalProfileRules.sanitizeFileName("C:\\dir\\a.txt"))
        assertEquals("file", LocalProfileRules.sanitizeFileName("  "))
        assertEquals(100, LocalProfileRules.sanitizeFileName("x".repeat(300)).length)
    }

    @Test
    fun `the file limit is 25 MB`() {
        assertEquals(25L * 1024 * 1024, LocalProfileRules.MAX_FILE_BYTES)
    }

    @Test
    fun `text messages still drop any attached image`() {
        val text = server.parsePayload("""{"kind":"text","text":"hi","image":"QUJD"}""")
        assertNull(text?.image)
    }
}
