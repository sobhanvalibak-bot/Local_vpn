package com.v2ray.ang.ui.compose

import androidx.compose.ui.graphics.Color
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test

class ColorThemeTest {

    @Test
    fun fromValue_knownValues_resolveToTheme() {
        AppColorTheme.values().forEach { assertEquals(it, AppColorTheme.fromValue(it.value)) }
    }

    @Test
    fun fromValue_nullOrUnknown_fallsBackToDefault() {
        assertEquals(AppColorTheme.DEFAULT, AppColorTheme.fromValue(null))
        assertEquals(AppColorTheme.DEFAULT, AppColorTheme.fromValue(""))
        assertEquals(AppColorTheme.DEFAULT, AppColorTheme.fromValue("orange"))
    }

    @Test
    fun themedColorScheme_default_isNull() {
        assertNull(themedColorScheme(AppColorTheme.DEFAULT, dark = false))
        assertNull(themedColorScheme(AppColorTheme.DEFAULT, dark = true))
    }

    @Test
    fun themedColorScheme_everyThemeAndMode_isDefined() {
        AppColorTheme.values().filter { it != AppColorTheme.DEFAULT }.forEach { theme ->
            assertNotNull(themedColorScheme(theme, dark = false))
            assertNotNull(themedColorScheme(theme, dark = true))
        }
    }

    @Test
    fun themedColorScheme_connectButtonAccentFollowsPrimary() {
        val scheme = themedColorScheme(AppColorTheme.PINK, dark = false)!!
        assertEquals(scheme.primary, scheme.tertiary)
        assertEquals(scheme.primary, scheme.secondary)
        assertNotEquals(Color(0xFFF97910), scheme.secondary)
    }

    @Test
    fun themedColorScheme_lightAndDarkDiffer() {
        AppColorTheme.values().filter { it != AppColorTheme.DEFAULT }.forEach { theme ->
            assertNotEquals(
                themedColorScheme(theme, dark = false)!!.surface,
                themedColorScheme(theme, dark = true)!!.surface
            )
        }
    }
}
