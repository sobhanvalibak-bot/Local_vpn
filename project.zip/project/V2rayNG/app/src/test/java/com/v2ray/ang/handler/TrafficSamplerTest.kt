package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.OutboundTrafficStat
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class TrafficSamplerTest {

    private fun stat(tag: String, direction: String, value: Long) = OutboundTrafficStat(tag, direction, value)

    @Test
    fun `summarize separates proxy direct and ignores blocked`() {
        val window = TrafficSampler.summarize(
            listOf(
                stat(AppConfig.TAG_PROXY, AppConfig.UPLINK, 100),
                stat(AppConfig.TAG_PROXY, AppConfig.DOWNLINK, 1000),
                stat(AppConfig.TAG_DIRECT, AppConfig.UPLINK, 5),
                stat(AppConfig.TAG_DIRECT, AppConfig.DOWNLINK, 50),
                stat(AppConfig.TAG_BLOCKED, AppConfig.DOWNLINK, 9999),
            ),
            elapsedMs = 1000,
        )

        assertEquals(TrafficWindow(100, 1000, 5, 50, 1000), window)
    }

    @Test
    fun `summarize adds every custom proxy tag`() {
        val window = TrafficSampler.summarize(
            listOf(
                stat("proxy-a", AppConfig.DOWNLINK, 300),
                stat("proxy-b", AppConfig.DOWNLINK, 200),
                stat("proxy-b", AppConfig.UPLINK, 20),
            ),
            elapsedMs = 1000,
        )

        assertEquals(500L, window.proxyDownlink)
        assertEquals(20L, window.proxyUplink)
    }

    @Test
    fun `summarize of no stats is an empty window`() {
        assertEquals(TrafficWindow(elapsedMs = 1000), TrafficSampler.summarize(emptyList(), 1000))
    }

    @Test
    fun `speed is bytes per second of the window`() {
        val speed = TrafficSampler.speedOf(TrafficWindow(proxyUplink = 500, proxyDownlink = 3000, elapsedMs = 2000))

        assertEquals(1500L, speed.downlinkBytesPerSec)
        assertEquals(250L, speed.uplinkBytesPerSec)
    }

    @Test
    fun `speed of a zero length window is zero instead of dividing by zero`() {
        val speed = TrafficSampler.speedOf(TrafficWindow(proxyDownlink = 10, elapsedMs = 0))

        assertEquals(0L, speed.downlinkBytesPerSec)
        assertEquals(0L, speed.uplinkBytesPerSec)
    }

    @Test
    fun `windows add up so a slow notification reader loses nothing`() {
        val total = TrafficWindow(1, 2, 3, 4, 1000) + TrafficWindow(10, 20, 30, 40, 1000)

        assertEquals(TrafficWindow(11, 22, 33, 44, 2000), total)
    }
}
