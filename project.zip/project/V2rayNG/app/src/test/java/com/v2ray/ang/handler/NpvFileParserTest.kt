package com.v2ray.ang.handler

import com.v2ray.ang.enums.EConfigType
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import java.util.Base64

class NpvFileParserTest {

    private fun b64(text: String) = Base64.getEncoder().encodeToString(text.toByteArray())
    private fun field(text: String) = "npvs1:" + b64(text)

    private fun npvsFile(header: String = "NPVS\n") = header + """
        {"configs":[
          {"name":"Tokyo","v2rayProfile":{"configType":5,"server":"${field("1.2.3.4")}","serverPort":"443",
            "password":"${field("uuid-1")}","security":"tls","network":"ws","sni":"${field("a.com")}","path":"/x","insecure":"true"}},
          {"name":"Unsupported","v2rayProfile":{"configType":8,"server":"x","serverPort":"1"}},
          {"name":"VM","v2rayProfile":{"configType":1,"server":"5.6.7.8","serverPort":"80","id":"u2","security":"chacha20-poly1305"}}
        ]}
    """.trimIndent()

    private fun npvtLine(name: String, json: String) = b64(name) + "," + b64(json)

    @Test
    fun `npvs decodes prefixed fields and skips unsupported types`() {
        val profiles = NpvFileParser.parse(npvsFile())
        assertNotNull(profiles)
        assertEquals(2, profiles!!.size)

        val vless = profiles[0]
        assertEquals(EConfigType.VLESS, vless.configType)
        assertEquals("Tokyo", vless.remarks)
        assertEquals("1.2.3.4", vless.server)
        assertEquals("443", vless.serverPort)
        assertEquals("uuid-1", vless.password)
        assertEquals("tls", vless.security)
        assertEquals("ws", vless.network)
        assertEquals("a.com", vless.sni)
        assertEquals(true, vless.insecure)
        assertEquals(NpvFileParser.SOURCE_NPVS, vless.npvSource)
    }

    @Test
    fun `npvs vmess keeps cipher separate from transport security and defaults network`() {
        val vmess = NpvFileParser.parse(npvsFile())!![1]
        assertEquals(EConfigType.VMESS, vmess.configType)
        assertEquals("u2", vmess.password)
        assertEquals("chacha20-poly1305", vmess.method)
        assertNull(vmess.security)
        assertEquals("tcp", vmess.network)
    }

    @Test
    fun `npvs works without header and with byte order mark`() {
        assertNotNull(NpvFileParser.parse(npvsFile(header = "")))
        assertNotNull(NpvFileParser.parse("﻿" + npvsFile()))
    }

    @Test
    fun `npvt parses base64 lines and header`() {
        val text = "NPVT\n" +
            npvtLine("SS1", """{"configType":3,"server":"9.9.9.9","serverPort":"8388","method":"aes-256-gcm","password":"pw"}""") +
            "\n" +
            npvtLine("T", """{"configType":6,"server":"t.com","serverPort":"443","password":"p"}""")

        val profiles = NpvFileParser.parse(text)!!
        assertEquals(2, profiles.size)
        assertEquals(EConfigType.SHADOWSOCKS, profiles[0].configType)
        assertEquals("aes-256-gcm", profiles[0].method)
        assertEquals("SS1", profiles[0].remarks)
        assertEquals(NpvFileParser.SOURCE_NPVT, profiles[0].npvSource)
        assertEquals(EConfigType.TROJAN, profiles[1].configType)
        assertEquals("tcp", profiles[1].network)
    }

    @Test
    fun `other text is not treated as an npv file`() {
        assertNull(NpvFileParser.parse(null))
        assertNull(NpvFileParser.parse(""))
        assertNull(NpvFileParser.parse("hello world"))
        assertNull(NpvFileParser.parse("vless://abc@x:443?type=tcp#a"))
        assertNull(NpvFileParser.parse("""{"inbounds":[],"outbounds":[]}"""))
        assertNull(NpvFileParser.parse("""garbage {"configs":[]}"""))
    }

    @Test
    fun `entries missing server or port are dropped`() {
        val text = """{"configs":[{"name":"x","v2rayProfile":{"configType":5,"server":"1.1.1.1"}}]}"""
        assertNull(NpvFileParser.parse(text))
    }

    @Test
    fun `only npvs and npvt extensions are accepted`() {
        assertTrue(NpvFileParser.hasSupportedExtension("a.npvs"))
        assertTrue(NpvFileParser.hasSupportedExtension("A.NPVT"))
        assertFalse(NpvFileParser.hasSupportedExtension("a.json"))
        assertFalse(NpvFileParser.hasSupportedExtension("npvs"))
        assertFalse(NpvFileParser.hasSupportedExtension(null))
    }

    @Test
    fun `npvt tolerates windows line endings, blank lines, header-less files and spaces`() {
        val line = npvtLine("A", """{"configType":6,"server":"t.com","serverPort":"443","password":"p"}""")
        val text = "\r\n\r\n  $line  \r\n\r\n" + npvtLine("B", """{"configType":5,"server":"v.com","serverPort":"443","id":"u"}""") + "\r\n"
        val profiles = NpvFileParser.parse(text)!!
        assertEquals(listOf("A", "B"), profiles.map { it.remarks })
    }

    @Test
    fun `npvt accepts url-safe base64, unpadded base64 and a v2rayProfile wrapper`() {
        val json = """{"v2rayProfile":{"configType":6,"server":"t.com","serverPort":"443","password":"p"}}"""
        val encoder = Base64.getUrlEncoder().withoutPadding()
        val line = encoder.encodeToString("Name".toByteArray()) + "," + encoder.encodeToString(json.toByteArray())
        val profiles = NpvFileParser.parse("NPVT1\n$line")!!
        assertEquals("Name", profiles.single().remarks)
        assertEquals("t.com", profiles.single().server)
    }

    @Test
    fun `whole file wrapped in base64 is unwrapped`() {
        assertNotNull(NpvFileParser.parse(b64(npvsFile())))
    }

    @Test
    fun `npvs accepts a profile stored as a json string and array values`() {
        val inner = """{"configType":5,"server":"1.1.1.1","serverPort":"443","id":"u","alpn":["h2","http/1.1"]}"""
        val escaped = inner.replace("\"", "\\\"")
        val text = """{"configs":[{"name":"S","v2rayProfile":"$escaped"}]}"""
        val profile = NpvFileParser.parse(text)!!.single()
        assertEquals("1.1.1.1", profile.server)
        assertEquals("h2,http/1.1", profile.alpn)
    }

    @Test
    fun `diagnose explains why a file is rejected`() {
        assertEquals(NpvFileParser.Failure.EMPTY, NpvFileParser.diagnose("  "))
        assertEquals(NpvFileParser.Failure.NOT_NPV, NpvFileParser.diagnose("hello world"))
        val unsupported = """{"configs":[{"name":"x","v2rayProfile":{"configType":8,"server":"x","serverPort":"1"}}]}"""
        assertEquals(NpvFileParser.Failure.NO_SUPPORTED_ENTRIES, NpvFileParser.diagnose(unsupported))
    }
}
