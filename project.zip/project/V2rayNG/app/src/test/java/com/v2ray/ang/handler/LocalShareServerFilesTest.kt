package com.v2ray.ang.handler

import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class LocalShareServerFilesTest {

    @TempDir
    lateinit var dir: File

    private lateinit var server: LocalShareServer

    @BeforeEach
    fun setUp() {
        server = LocalShareServer(onConfigsReceived = {}, fileDir = File(dir, "store"))
        assertTrue(server.start(0))
    }

    @AfterEach
    fun tearDown() = server.stop()

    private fun upload(bytes: ByteArray, name: String = "a b.bin"): FileRef? {
        val c = URL("http://127.0.0.1:${server.port}/file?name=${java.net.URLEncoder.encode(name, "UTF-8")}&mime=application%2Fzip")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.setFixedLengthStreamingMode(bytes.size)
        c.outputStream.use { it.write(bytes) }
        return if (c.responseCode == 200) LocalProfileRules.parseFileRef(c.inputStream.bufferedReader().readText()) else null
    }

    @Test
    fun `an uploaded file can be downloaded back unchanged`() {
        val bytes = ByteArray(300_000) { (it % 251).toByte() }
        val ref = upload(bytes)
        assertNotNull(ref)
        assertEquals(bytes.size.toLong(), ref!!.size)
        assertEquals("a b.bin", ref.name)
        val c = URL("http://127.0.0.1:${server.port}/file/${ref.id}").openConnection() as HttpURLConnection
        assertEquals(200, c.responseCode)
        assertArrayEquals(bytes, c.inputStream.readBytes())
    }

    @Test
    fun `an unknown file id is not found`() {
        val c = URL("http://127.0.0.1:${server.port}/file/${"0".repeat(32)}").openConnection() as HttpURLConnection
        assertEquals(404, c.responseCode)
    }

    @Test
    fun `an upload over the limit is refused`() {
        val c = URL("http://127.0.0.1:${server.port}/file?name=x").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.setFixedLengthStreamingMode(LocalProfileRules.MAX_FILE_BYTES + 1)
        // The server answers from the headers alone, before the body is sent.
        val code = try {
            c.outputStream.use { it.write(ByteArray(1024)) }
            c.responseCode
        } catch (e: java.io.IOException) {
            413
        }
        assertEquals(413, code)
    }

    @Test
    fun `a server-owned file is registered and fetched by id`() {
        val source = File(dir, "src.txt").apply { writeText("hello") }
        val ref = server.registerFile(source, "../src.txt", "text/plain")
        assertNotNull(ref)
        assertEquals("src.txt", ref!!.name)
        assertEquals("hello", server.storedFile(ref.id)?.readText())
    }

    @Test
    fun `an empty file is not registered and stopping clears the store`() {
        val empty = File(dir, "empty").apply { createNewFile() }
        assertNull(server.registerFile(empty, "empty", "a/b"))
        val source = File(dir, "x").apply { writeText("data") }
        val ref = server.registerFile(source, "x", "a/b")!!
        server.stop()
        assertNull(server.storedFile(ref.id))
    }
}
