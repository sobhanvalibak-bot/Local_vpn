package com.v2ray.ang.handler

import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

class AppLockManagerTest {

    @BeforeEach
    fun setUp() {
        AppLockManager.resetForTest()
    }

    @Test
    fun startsLocked() {
        assertFalse(AppLockManager.unlocked.value)
    }

    @Test
    fun returningWithinGrace_keepsUnlocked() {
        AppLockManager.markUnlocked()
        AppLockManager.onLeftForeground(nowMs = 1_000L)

        AppLockManager.onEnteredForeground(nowMs = 1_000L + AppLockManager.RELOCK_GRACE_MS)

        assertTrue(AppLockManager.unlocked.value)
    }

    @Test
    fun returningAfterGrace_locksAgain() {
        AppLockManager.markUnlocked()
        AppLockManager.onLeftForeground(nowMs = 1_000L)

        AppLockManager.onEnteredForeground(nowMs = 1_000L + AppLockManager.RELOCK_GRACE_MS + 1)

        assertFalse(AppLockManager.unlocked.value)
    }

    @Test
    fun enteringWithoutHavingLeft_doesNotChangeState() {
        AppLockManager.markUnlocked()

        AppLockManager.onEnteredForeground(nowMs = 10_000_000L)

        assertTrue(AppLockManager.unlocked.value)
    }
}
