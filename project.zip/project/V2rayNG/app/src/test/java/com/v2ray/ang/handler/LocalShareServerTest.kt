package com.v2ray.ang.handler

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress

class LocalShareServerTest {

    @Test
    fun parseLinks_keepsOnlyUniqueShareLinks() {
        val text = "vless://a@h:1\n  \nhello world\nvless://a@h:1\ntrojan://p@h:2\n"
        assertEquals(listOf("vless://a@h:1", "trojan://p@h:2"), LocalShareServer.parseLinks(text))
    }

    @Test
    fun parseLinks_emptyInputGivesEmptyList() {
        assertTrue(LocalShareServer.parseLinks("").isEmpty())
    }

    @Test
    fun isLocalClient_acceptsLanAndRejectsPublic() {
        assertTrue(LocalShareServer.isLocalClient(InetAddress.getByName("192.168.1.20")))
        assertTrue(LocalShareServer.isLocalClient(InetAddress.getByName("127.0.0.1")))
        assertFalse(LocalShareServer.isLocalClient(InetAddress.getByName("8.8.8.8")))
    }

    @Test
    fun buildConfigsUrl_validAndInvalid() {
        assertEquals("http://192.168.1.5:8765/configs", LocalTestManager.buildConfigsUrl("192.168.1.5:8765"))
        assertEquals("http://192.168.1.5:8765/configs", LocalTestManager.buildConfigsUrl("http://192.168.1.5/"))
        assertNull(LocalTestManager.buildConfigsUrl(""))
        assertNull(LocalTestManager.buildConfigsUrl("192.168.1.5:99999"))
        assertNull(LocalTestManager.buildConfigsUrl("https://host:1"))
        assertNull(LocalTestManager.buildConfigsUrl("host/path"))
    }
}
