package com.v2ray.ang.handler

import com.v2ray.ang.dto.entities.ServerAffiliationInfo
import com.v2ray.ang.enums.DefaultTabSort
import com.v2ray.ang.util.JsonUtil
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test

class ServerRankingTest {

    private fun s(guid: String, ping: Long, download: Long) = RankedServer(guid, ping, download)
    private fun order(items: List<RankedServer>, mode: DefaultTabSort) = ServerRanking.sort(items, mode).map { it.guid }

    private val sample = listOf(
        s("untested", 0, 0),
        s("slow", 300, 1_000),
        s("failed", -1, 0),
        s("fast", 50, 9_000),
        s("mid", 100, 5_000),
    )

    @Test
    fun `time keeps the stored order`() {
        assertEquals(sample.map { it.guid }, order(sample, DefaultTabSort.TIME))
    }

    @Test
    fun `download puts the highest speed first and unmeasured last`() {
        assertEquals(listOf("fast", "mid", "slow", "untested", "failed"), order(sample, DefaultTabSort.DOWNLOAD))
    }

    @Test
    fun `download ties are broken by lower ping`() {
        val items = listOf(s("a", 200, 5_000), s("b", 80, 5_000))
        assertEquals(listOf("b", "a"), order(items, DefaultTabSort.DOWNLOAD))
    }

    @Test
    fun `ping puts the lowest ping first then untested then failed`() {
        assertEquals(listOf("fast", "mid", "slow", "untested", "failed"), order(sample, DefaultTabSort.PING))
    }

    @Test
    fun `sort is stable for equal results and handles an empty list`() {
        val items = listOf(s("x", 0, 0), s("y", 0, 0), s("z", 0, 0))
        assertEquals(listOf("x", "y", "z"), order(items, DefaultTabSort.DOWNLOAD))
        assertEquals(emptyList<String>(), order(emptyList(), DefaultTabSort.PING))
    }

    @Test
    fun `best download is the fastest measured profile`() {
        assertEquals("fast", ServerRanking.bestDownload(sample))
    }

    @Test
    fun `best download prefers lower ping on equal speed`() {
        assertEquals("b", ServerRanking.bestDownload(listOf(s("a", 200, 5_000), s("b", 80, 5_000))))
    }

    @Test
    fun `best download is null when nothing was measured`() {
        assertNull(ServerRanking.bestDownload(listOf(s("a", 100, 0), s("b", -1, 0))))
        assertNull(ServerRanking.bestDownload(emptyList()))
    }

    @Test
    fun `stored sort value round-trips and unknown values fall back to time`() {
        DefaultTabSort.entries.forEach { assertEquals(it, DefaultTabSort.fromStorage(it.storageValue)) }
        assertEquals(DefaultTabSort.TIME, DefaultTabSort.fromStorage(null))
        assertEquals(DefaultTabSort.TIME, DefaultTabSort.fromStorage("nonsense"))
    }

    @Test
    fun `affiliation info stored by an older version still loads with no download speed`() {
        val old = JsonUtil.fromJsonSafe("{\"testDelayMillis\":120}", ServerAffiliationInfo::class.java)
        assertEquals(120L, old?.testDelayMillis)
        assertEquals(0L, old?.testDownloadBytesPerSec)
    }

    @Test
    fun `bytes per second handles empty and zero-time downloads`() {
        assertEquals(0L, SpeedtestManager.bytesPerSecond(0, 1000))
        assertEquals(0L, SpeedtestManager.bytesPerSecond(5000, 0))
        assertEquals(2_500L, SpeedtestManager.bytesPerSecond(5_000, 2_000))
    }
}
