package com.v2ray.ang.handler

import com.v2ray.ang.handler.TelegramProxyManager.SecretMode
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class TelegramProxyManagerTest {
    private val sample = """
        https://t.me/proxy?server=uujjjh.ir.ir.ir.meli-n12.info&port=8443&secret=dd104462821249bd7ac519130220c25d09

        https://t.me/proxy?server=pnj.anotelinopalk.co.uk&port=8880&secret=eeNEgYdJvXrFGRMCIMJdCQ

        https://t.me/proxy?server=char.anotelinopalk.co.uk&port=8880&secret=eeNEgYdJvXrFGRMCIMJdCQ
        https://t.me/proxy?server=do.anotelinopalk.co.uk&port=8880&secret=eeNEgYdJvXrFGRMCIMJdCQ
    """.trimIndent()

    @Test
    fun parsesAllFourSampleLinks() {
        val proxies = TelegramProxyManager.parse(sample)
        assertEquals(4, proxies.size)
        assertEquals("uujjjh.ir.ir.ir.meli-n12.info", proxies[0].server)
        assertEquals(8443, proxies[0].port)
        assertEquals(8880, proxies[1].port)
        assertEquals("do.anotelinopalk.co.uk", proxies[3].server)
    }

    @Test
    fun classifiesSecrets() {
        val proxies = TelegramProxyManager.parse(sample)
        // dd + 16 bytes in hex
        assertEquals(SecretMode.PADDED, proxies[0].mode)
        // 22-char base64url = 16 raw bytes; the leading "ee" is not a type prefix here
        assertEquals(SecretMode.PLAIN, proxies[1].mode)
    }

    @Test
    fun fakeTlsSecretWithDomain() {
        val secret = "ee" + "00".repeat(16) + "676f6f676c652e636f6d"
        val p = TelegramProxyManager.parseLink("https://t.me/proxy?server=a.example.com&port=443&secret=$secret")!!
        assertEquals(SecretMode.FAKE_TLS, p.mode)
    }

    @Test
    fun acceptsTgSchemeAndSchemelessLinks() {
        val text = "tg://proxy?server=1.2.3.4&port=443&secret=" + "ab".repeat(16) +
            "\nt.me/proxy?server=5.6.7.8&port=80&secret=" + "cd".repeat(16)
        val proxies = TelegramProxyManager.parse(text)
        assertEquals(2, proxies.size)
        assertEquals("https://t.me/proxy?server=5.6.7.8&port=80&secret=" + "cd".repeat(16), proxies[1].link)
    }

    @Test
    fun deduplicatesAndIgnoresTrailingPunctuation() {
        val link = "https://t.me/proxy?server=a.example.com&port=443&secret=" + "ab".repeat(16)
        val proxies = TelegramProxyManager.parse("($link), again $link.")
        assertEquals(1, proxies.size)
        assertEquals(link, proxies[0].link)
    }

    @Test
    fun rejectsMalformedLinks() {
        val secret = "ab".repeat(16)
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?port=443&secret=$secret"))
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?server=a.com&secret=$secret"))
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?server=a.com&port=0&secret=$secret"))
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?server=a.com&port=70000&secret=$secret"))
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?server=a.com&port=443"))
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?server=a%20b.com&port=443&secret=$secret"))
        assertNull(TelegramProxyManager.parseLink("https://t.me/proxy?server=a.com&port=443&secret=abc"))
    }

    @Test
    fun emptyAndUnrelatedTextGivesNothing() {
        assertTrue(TelegramProxyManager.parse(null).isEmpty())
        assertTrue(TelegramProxyManager.parse("").isEmpty())
        assertFalse(TelegramProxyManager.containsProxy("vless://abc@host:443?type=tcp#x"))
        assertTrue(TelegramProxyManager.containsProxy(sample))
    }

    @Test
    fun decodesHexAndBase64Url() {
        assertEquals(listOf<Byte>(0xDD.toByte(), 0x10), TelegramProxyManager.decodeSecret("dd10")!!.toList())
        assertEquals(16, TelegramProxyManager.decodeSecret("eeNEgYdJvXrFGRMCIMJdCQ")!!.size)
        assertNull(TelegramProxyManager.decodeSecret("not*base64"))
    }
}
