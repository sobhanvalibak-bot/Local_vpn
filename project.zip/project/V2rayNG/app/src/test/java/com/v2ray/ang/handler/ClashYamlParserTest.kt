package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.enums.EConfigType
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class ClashYamlParserTest {

    private val sample = """
        port: 7890
        # comment line
        proxies:
          - name: "DE reality"
            type: vless
            server: 1.2.3.4
            port: 443
            uuid: 11111111-1111-1111-1111-111111111111
            network: tcp
            tls: true
            flow: xtls-rprx-vision
            servername: example.com
            client-fingerprint: chrome
            reality-opts:
              public-key: PUBKEY
              short-id: abcd
          - { name: ws-node, type: vmess, server: v.example.com, port: 8443, uuid: 22222222-2222-2222-2222-222222222222, alterId: 0, cipher: auto, tls: true, network: ws, ws-opts: { path: /ws, headers: { Host: cdn.example.com } }, servername: cdn.example.com, skip-cert-verify: true }
          - name: tuic-node
            type: tuic
            server: t.example.com
            port: 443
        proxy-groups:
          - name: auto
            type: select
            proxies: [DE reality, ws-node]
        rules:
          - MATCH,auto
    """.trimIndent()

    @Test
    fun parse_blockVlessReality_mapsFields() {
        val profile = ClashYamlParser.parse(sample)!!.first()

        assertEquals(EConfigType.VLESS, profile.configType)
        assertEquals("DE reality", profile.remarks)
        assertEquals("1.2.3.4", profile.server)
        assertEquals("443", profile.serverPort)
        assertEquals("11111111-1111-1111-1111-111111111111", profile.password)
        assertEquals("xtls-rprx-vision", profile.flow)
        assertEquals(AppConfig.REALITY, profile.security)
        assertEquals("PUBKEY", profile.publicKey)
        assertEquals("abcd", profile.shortId)
        assertEquals("example.com", profile.sni)
        assertEquals("chrome", profile.fingerPrint)
    }

    @Test
    fun parse_flowVmessWebSocket_mapsFields() {
        val profile = ClashYamlParser.parse(sample)!![1]

        assertEquals(EConfigType.VMESS, profile.configType)
        assertEquals("ws", profile.network)
        assertEquals("/ws", profile.path)
        assertEquals("cdn.example.com", profile.host)
        assertEquals(AppConfig.TLS, profile.security)
        assertEquals(true, profile.insecure)
        assertEquals("cdn.example.com", profile.sni)
    }

    @Test
    fun parse_skipsUnsupportedTypesAndOtherSections() {
        assertEquals(2, ClashYamlParser.parse(sample)!!.size)
    }

    @Test
    fun parse_trojanGrpc_alwaysUsesTls() {
        val yaml = """
            proxies:
              - name: tr
                type: trojan
                server: tr.example.com
                port: 443
                password: secret
                sni: tr.example.com
                network: grpc
                grpc-opts:
                  grpc-service-name: svc
        """.trimIndent()

        val profile = ClashYamlParser.parse(yaml)!!.single()

        assertEquals(EConfigType.TROJAN, profile.configType)
        assertEquals(AppConfig.TLS, profile.security)
        assertEquals("grpc", profile.network)
        assertEquals("svc", profile.serviceName)
        assertEquals("secret", profile.password)
    }

    @Test
    fun parse_shadowsocksWithObfsHttp_andWithoutPlugin() {
        val yaml = """
            proxies:
            - { name: ss1, type: ss, server: s.example.com, port: 8388, cipher: aes-128-gcm, password: pw }
            - { name: ss2, type: ss, server: s2.example.com, port: 8388, cipher: aes-128-gcm, password: pw, plugin: obfs, plugin-opts: { mode: http, host: bing.com } }
            - { name: ss3, type: ss, server: s3.example.com, port: 8388, cipher: aes-128-gcm, password: pw, plugin: shadow-tls }
        """.trimIndent()

        val profiles = ClashYamlParser.parse(yaml)!!

        assertEquals(2, profiles.size)
        assertEquals("aes-128-gcm", profiles[0].method)
        assertEquals("http", profiles[1].headerType)
        assertEquals("bing.com", profiles[1].host)
    }

    @Test
    fun parse_hysteria2_mapsObfsAndPorts() {
        val yaml = """
            proxies:
              - name: hy
                type: hysteria2
                server: h.example.com
                port: 443
                ports: 20000-30000
                password: pw
                obfs: salamander
                obfs-password: op
                sni: h.example.com
        """.trimIndent()

        val profile = ClashYamlParser.parse(yaml)!!.single()

        assertEquals(EConfigType.HYSTERIA2, profile.configType)
        assertEquals("op", profile.obfsPassword)
        assertEquals("20000-30000", profile.portHopping)
        assertEquals(AppConfig.TLS, profile.security)
    }

    @Test
    fun parse_notClash_returnsNull() {
        assertNull(ClashYamlParser.parse(null))
        assertNull(ClashYamlParser.parse(""))
        assertNull(ClashYamlParser.parse("vless://uuid@1.2.3.4:443?security=tls#a"))
        assertNull(ClashYamlParser.parse("{\"proxies\": []}"))
    }

    @Test
    fun parse_invalidEntries_areSkipped() {
        val yaml = """
            proxies:
              - { name: no-port, type: trojan, server: a.example.com, password: p }
              - { name: bad-port, type: trojan, server: a.example.com, port: 99999, password: p }
              - { name: ok, type: trojan, server: a.example.com, port: 443, password: p }
        """.trimIndent()

        val profiles = ClashYamlParser.parse(yaml)
        assertNotNull(profiles)
        assertTrue(profiles!!.size == 1 && profiles[0].remarks == "ok")
    }
}
