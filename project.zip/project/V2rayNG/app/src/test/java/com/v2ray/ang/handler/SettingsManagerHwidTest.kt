package com.v2ray.ang.handler

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class SettingsManagerHwidTest {

    @Test
    fun buildHwidHeaders_containsDeviceFields() {
        val headers = SettingsManager.buildHwidHeaders("abc-123", "14", "Pixel 8")

        assertEquals("abc-123", headers["x-hwid"])
        assertEquals("Android", headers["x-device-os"])
        assertEquals("14", headers["x-ver-os"])
        assertEquals("Pixel 8", headers["x-device-model"])
    }

    @Test
    fun toHeaderValue_replacesNonAsciiAndTrims() {
        assertEquals("Galaxy ?? 5", SettingsManager.toHeaderValue("  Galaxy \u00e9\u00e8 5 "))
        assertEquals("", SettingsManager.toHeaderValue(""))
    }

    @Test
    fun buildHwidHeaders_nullPartsBecomeEmpty() {
        val headers = SettingsManager.buildHwidHeaders("id", null, null)

        assertEquals("", headers["x-ver-os"])
        assertEquals("", headers["x-device-model"])
    }
}
