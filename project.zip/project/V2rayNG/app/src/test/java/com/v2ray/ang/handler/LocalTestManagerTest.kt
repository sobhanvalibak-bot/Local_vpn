package com.v2ray.ang.handler

import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.enums.EConfigType
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class LocalTestManagerTest {

    private fun vless(remarks: String, server: String, port: String = "443", password: String = "id") =
        ProfileItem(
            configType = EConfigType.VLESS,
            remarks = remarks,
            server = server,
            serverPort = port,
            password = password,
        )

    @Test
    fun `nothing is duplicate when both lists are empty`() {
        assertEquals(emptyList<String>(), LocalTestManager.findDuplicateGuids(emptyList(), emptyList()))
    }

    @Test
    fun `new profile with different server is kept`() {
        val result = LocalTestManager.findDuplicateGuids(
            existing = listOf(vless("a", "1.1.1.1")),
            added = listOf("new" to vless("b", "2.2.2.2")),
        )
        assertEquals(emptyList<String>(), result)
    }

    @Test
    fun `profile already in the list is duplicate even with another remark`() {
        val result = LocalTestManager.findDuplicateGuids(
            existing = listOf(vless("old name", "1.1.1.1")),
            added = listOf("new" to vless("new name", "1.1.1.1")),
        )
        assertEquals(listOf("new"), result)
    }

    @Test
    fun `repeat inside the fetched batch keeps the first and drops the rest`() {
        val result = LocalTestManager.findDuplicateGuids(
            existing = emptyList(),
            added = listOf(
                "first" to vless("a", "3.3.3.3"),
                "second" to vless("b", "3.3.3.3"),
            ),
        )
        assertEquals(listOf("second"), result)
    }

    @Test
    fun `complex profiles are never treated as duplicates`() {
        val group = ProfileItem(configType = EConfigType.POLICYGROUP, remarks = "g")
        val result = LocalTestManager.findDuplicateGuids(
            existing = listOf(group),
            added = listOf("new" to group.copy()),
        )
        assertEquals(emptyList<String>(), result)
    }

    @Test
    fun `pickGreen keeps only positive pings in order`() {
        val configs = listOf(
            OwnerConfig("a", "a", 120L),
            OwnerConfig("b", "b", -1L),
            OwnerConfig("c", "c", 0L),
            OwnerConfig("d", "d", 45L),
        )
        assertEquals(listOf("a", "d"), LocalTestManager.pickGreen(configs))
    }

    @Test
    fun `pickGreen is empty when nothing was tested`() {
        assertEquals(emptyList<String>(), LocalTestManager.pickGreen(emptyList()))
    }
}
