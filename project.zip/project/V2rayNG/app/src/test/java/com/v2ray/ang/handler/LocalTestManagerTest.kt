package com.v2ray.ang.handler

import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.enums.EConfigType
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test

class LocalTestManagerTest {

    private fun vless(remarks: String, server: String, port: String = "443", password: String = "id") =
        ProfileItem(
            configType = EConfigType.VLESS,
            remarks = remarks,
            server = server,
            serverPort = port,
            password = password,
        )

    @Test
    fun `nothing is duplicate when both lists are empty`() {
        assertEquals(emptyList<String>(), LocalTestManager.findDuplicateGuids(emptyList(), emptyList()))
    }

    @Test
    fun `new profile with different server is kept`() {
        val result = LocalTestManager.findDuplicateGuids(
            existing = listOf(vless("a", "1.1.1.1")),
            added = listOf("new" to vless("b", "2.2.2.2")),
        )
        assertEquals(emptyList<String>(), result)
    }

    @Test
    fun `profile already in the list is duplicate even with another remark`() {
        val result = LocalTestManager.findDuplicateGuids(
            existing = listOf(vless("old name", "1.1.1.1")),
            added = listOf("new" to vless("new name", "1.1.1.1")),
        )
        assertEquals(listOf("new"), result)
    }

    @Test
    fun `repeat inside the fetched batch keeps the first and drops the rest`() {
        val result = LocalTestManager.findDuplicateGuids(
            existing = emptyList(),
            added = listOf(
                "first" to vless("a", "3.3.3.3"),
                "second" to vless("b", "3.3.3.3"),
            ),
        )
        assertEquals(listOf("second"), result)
    }

    @Test
    fun `complex profiles are never treated as duplicates`() {
        val group = ProfileItem(configType = EConfigType.POLICYGROUP, remarks = "g")
        val result = LocalTestManager.findDuplicateGuids(
            existing = listOf(group),
            added = listOf("new" to group.copy()),
        )
        assertEquals(emptyList<String>(), result)
    }

    @Test
    fun `pickGreen keeps only positive pings in order`() {
        val configs = listOf(
            OwnerConfig("a", "a", 120L),
            OwnerConfig("b", "b", -1L),
            OwnerConfig("c", "c", 0L),
            OwnerConfig("d", "d", 45L),
        )
        assertEquals(listOf("a", "d"), LocalTestManager.pickGreen(configs))
    }

    @Test
    fun `pickGreen is empty when nothing was tested`() {
        assertEquals(emptyList<String>(), LocalTestManager.pickGreen(emptyList()))
    }

    @Test
    fun `update plan replaces an existing profile and keeps new ones`() {
        val plan = LocalTestManager.planUpdate(
            existing = listOf("old" to vless("old name", "1.1.1.1")),
            added = listOf(
                "same" to vless("new name", "1.1.1.1"),
                "other" to vless("x", "2.2.2.2"),
            ),
        )
        assertEquals(mapOf("same" to "old"), plan.replacements)
        assertEquals(listOf("other"), plan.fresh)
        assertEquals(emptyList<String>(), plan.repeatedInBatch)
        assertEquals(1, plan.duplicateCount)
    }

    @Test
    fun `update plan counts a repeat inside the fetched batch once`() {
        val plan = LocalTestManager.planUpdate(
            existing = emptyList(),
            added = listOf("first" to vless("a", "3.3.3.3"), "second" to vless("b", "3.3.3.3")),
        )
        assertEquals(listOf("first"), plan.fresh)
        assertEquals(listOf("second"), plan.repeatedInBatch)
        assertEquals(1, plan.duplicateCount)
    }

    @Test
    fun `update plan never replaces complex profiles`() {
        val group = ProfileItem(configType = EConfigType.POLICYGROUP, remarks = "g")
        val plan = LocalTestManager.planUpdate(listOf("old" to group), listOf("new" to group.copy()))
        assertEquals(listOf("new"), plan.fresh)
        assertEquals(0, plan.duplicateCount)
    }

    @Test
    fun `update plan with nothing fetched is empty`() {
        val plan = LocalTestManager.planUpdate(listOf("old" to vless("a", "1.1.1.1")), emptyList())
        assertEquals(0, plan.duplicateCount)
        assertEquals(emptyList<String>(), plan.fresh)
    }

    @Test
    fun `address with only an ip gets the default port`() {
        assertEquals("192.168.1.5:8765", LocalTestManager.normalizeAddress(" 192.168.1.5 "))
        assertEquals("192.168.1.5:9000", LocalTestManager.normalizeAddress("http://192.168.1.5:9000/"))
    }

    @Test
    fun `invalid address is rejected`() {
        assertNull(LocalTestManager.normalizeAddress(""))
        assertNull(LocalTestManager.normalizeAddress("192.168.1.5:99999"))
        assertNull(LocalTestManager.normalizeAddress("bad host"))
    }

    @Test
    fun `subnet hosts cover the whole network except this device`() {
        val hosts = LocalTestManager.subnetHosts("192.168.1.5")
        assertEquals(253, hosts.size)
        assertEquals("192.168.1.1", hosts.first())
        assertEquals("192.168.1.254", hosts.last())
        assertEquals(false, "192.168.1.5" in hosts)
    }

    @Test
    fun `subnet hosts of a malformed ip is empty`() {
        assertEquals(emptyList<String>(), LocalTestManager.subnetHosts("not-an-ip"))
        assertEquals(emptyList<String>(), LocalTestManager.subnetHosts("192.168.1.300"))
    }
}
