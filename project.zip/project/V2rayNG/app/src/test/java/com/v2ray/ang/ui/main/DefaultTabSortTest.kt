package com.v2ray.ang.ui.main

import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.ServersCache
import com.v2ray.ang.enums.DefaultTabSort
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertSame
import org.junit.jupiter.api.Test

class DefaultTabSortTest {

    private fun cache(guid: String, ping: Long, download: Long) =
        ServersCache(guid, ProfileItem.create(com.v2ray.ang.enums.EConfigType.VMESS), ping, download)

    private val servers = listOf(cache("a", 300, 1_000), cache("b", 50, 9_000), cache("c", 0, 0))

    @Test
    fun `time returns the same list`() {
        assertSame(servers, sortForDefaultTab(servers, DefaultTabSort.TIME))
    }

    @Test
    fun `download and ping reorder by guid and keep every server`() {
        assertEquals(listOf("b", "a", "c"), sortForDefaultTab(servers, DefaultTabSort.DOWNLOAD).map { it.guid })
        assertEquals(listOf("b", "a", "c"), sortForDefaultTab(servers, DefaultTabSort.PING).map { it.guid })
    }

    @Test
    fun `empty list stays empty`() {
        assertEquals(emptyList<ServersCache>(), sortForDefaultTab(emptyList(), DefaultTabSort.DOWNLOAD))
    }
}
