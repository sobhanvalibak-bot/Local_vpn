package com.v2ray.ang.ui.telegramproxy

import android.app.Application
import androidx.lifecycle.viewModelScope
import com.v2ray.ang.handler.TelegramProxyManager
import com.v2ray.ang.handler.TelegramProxyManager.TelegramProxy
import com.v2ray.ang.ui.base.BaseViewModel
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class TelegramProxyViewModel(application: Application) : BaseViewModel(application) {

    private val _uiState = MutableStateFlow(TelegramProxyUiState())
    val uiState: StateFlow<TelegramProxyUiState> = _uiState.asStateFlow()

    private var testJob: Job? = null

    fun onAction(action: TelegramProxyAction) {
        when (action) {
            is TelegramProxyAction.SetInput ->
                _uiState.update { it.copy(input = action.text.take(MAX_INPUT_LENGTH)) }

            is TelegramProxyAction.Test -> startTest(action.text ?: _uiState.value.input)

            TelegramProxyAction.PasteAndTest -> startTest(Utils.getClipboard(app))
        }
    }

    private fun startTest(rawText: String) {
        val text = rawText.take(MAX_INPUT_LENGTH)
        testJob?.cancel()
        testJob = viewModelScope.launch {
            val proxies = withContext(Dispatchers.Default) { TelegramProxyManager.parse(text) }
            _uiState.update {
                it.copy(
                    input = text,
                    hasTested = true,
                    isTesting = proxies.isNotEmpty(),
                    rows = proxies.map { p -> TelegramProxyRow(p, PingStatus.Testing) },
                )
            }
            if (proxies.isEmpty()) return@launch
            pingAll(proxies)
            _uiState.update { it.copy(isTesting = false, rows = sortByLatency(it.rows)) }
        }
    }

    private suspend fun pingAll(proxies: List<TelegramProxy>) = coroutineScope {
        val limiter = Semaphore(CONCURRENCY)
        proxies.map { proxy ->
            async(Dispatchers.IO) {
                val ms = limiter.withPermit { TelegramProxyManager.ping(proxy) }
                // A newer test run cancels this one; never publish a superseded result.
                ensureActive()
                val status = if (ms >= 0) PingStatus.Done(ms) else PingStatus.Failed
                _uiState.update { s ->
                    s.copy(rows = s.rows.map { if (it.proxy.id == proxy.id) it.copy(status = status) else it })
                }
            }
        }.awaitAll()
    }

    companion object {
        private const val CONCURRENCY = 8
        internal const val MAX_INPUT_LENGTH = 100_000

        /** Reachable proxies first, fastest to slowest; unreachable ones last. Stable for ties. */
        internal fun sortByLatency(rows: List<TelegramProxyRow>): List<TelegramProxyRow> =
            rows.sortedBy { (it.status as? PingStatus.Done)?.millis ?: Long.MAX_VALUE }
    }
}
