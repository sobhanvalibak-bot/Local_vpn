package com.v2ray.ang.handler

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.view.Window
import android.view.WindowManager
import com.v2ray.ang.AppConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Optional app lock that asks for the device screen lock (PIN, pattern, password or biometrics).
 *
 * The app counts as left once no activity of this process is on screen (see [AppForegroundTracker]);
 * coming back after more than [RELOCK_GRACE_MS] locks it again. The short grace period keeps the lock
 * from firing while the user picks a file or scans a QR code in another app.
 *
 * Foreground tracking is plain state so it can be unit tested without MMKV or Android.
 */
object AppLockManager {
    internal const val RELOCK_GRACE_MS = 60_000L

    private val enabledFlow: MutableStateFlow<Boolean> by lazy {
        MutableStateFlow(MmkvManager.decodeSettingsBool(AppConfig.PREF_APP_LOCK, false))
    }
    private val unlockedFlow = MutableStateFlow(false)

    @Volatile
    private var leftForegroundAtMs = 0L

    /** Whether the user turned the lock on. */
    val enabled: StateFlow<Boolean> get() = enabledFlow.asStateFlow()

    /** Whether the lock was passed since the app last left the screen for longer than the grace period. */
    val unlocked: StateFlow<Boolean> = unlockedFlow.asStateFlow()

    fun setEnabled(value: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_APP_LOCK, value)
        enabledFlow.value = value
        // Turning the lock on from inside the app must not lock the person out of the screen they are using.
        if (value) unlockedFlow.value = true
    }

    fun markUnlocked() {
        unlockedFlow.value = true
    }

    internal fun onLeftForeground(nowMs: Long = System.currentTimeMillis()) {
        leftForegroundAtMs = nowMs
    }

    internal fun onEnteredForeground(nowMs: Long = System.currentTimeMillis()) {
        val left = leftForegroundAtMs
        leftForegroundAtMs = 0L
        if (left != 0L && nowMs - left > RELOCK_GRACE_MS) {
            unlockedFlow.value = false
        }
    }

    /** Test hook: back to a freshly started process. */
    internal fun resetForTest() {
        unlockedFlow.value = false
        leftForegroundAtMs = 0L
    }

    /** True when the device has a PIN, pattern, password or biometric the lock can ask for. */
    fun isDeviceSecure(context: Context): Boolean =
        context.getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true

    /**
     * Intent of the system "confirm your screen lock" screen, or null when the device has no secure lock
     * any more. A null result means there is nothing to ask for, so the caller must not keep the person out.
     */
    fun createCredentialIntent(context: Context, title: CharSequence, description: CharSequence?): Intent? {
        val keyguard = context.getSystemService(KeyguardManager::class.java) ?: return null
        if (!keyguard.isDeviceSecure) return null
        return keyguard.createConfirmDeviceCredentialIntent(title, description)
    }

    /** Applies the "hide content in recents and screenshots" preference to a window. */
    fun applySecureScreen(window: Window) {
        if (MmkvManager.decodeSettingsBool(AppConfig.PREF_SECURE_SCREEN, false)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
}
