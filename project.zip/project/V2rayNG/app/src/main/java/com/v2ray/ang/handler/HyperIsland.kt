package com.v2ray.ang.handler

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.graphics.drawable.Icon
import android.os.Bundle
import android.provider.Settings
import androidx.core.graphics.drawable.toBitmap
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.extension.toSpeedString
import com.v2ray.ang.util.LogUtil
import org.json.JSONArray
import org.json.JSONObject

/**
 * Xiaomi HyperOS 3 "Super Island" support.
 *
 * The island is not a separate API: it is the regular foreground notification with extra
 * `miui.focus.*` extras attached. On every other device the extras are never added, so the
 * notification behaves exactly as before.
 *
 * Layout:
 *  - small island: app icon
 *  - big island:   app icon + config name
 *  - expanded:     config name, exit IP (and download speed) below it, a "Stop · <ping>" button
 *                  and a "Change" button that switches to the config with the best download speed
 */
object HyperIsland {

    /** What the island shows. [pingMs]: null = measuring, negative = failed. */
    data class State(
        val name: String,
        val pingMs: Long? = null,
        val ip: String? = null,
        /** Download speed of the active config from the last test, bytes per second; 0 when not measured. */
        val downloadBytesPerSec: Long = 0L,
        /** Profile details of the active config, shown instead of the IP when the user picks them. */
        val protocol: String? = null,
        val subscription: String? = null,
    )

    private const val KEY_PARAM = "miui.focus.param"
    private const val KEY_PICS = "miui.focus.pics"
    private const val KEY_ACTIONS = "miui.focus.actions"
    private const val PIC_APP = "miui.focus.pic_app"
    private const val ACTION_STOP = "miui.focus.action_stop"
    private const val ACTION_CHANGE = "miui.focus.action_change"

    private const val FOCUS_PROTOCOL_KEY = "notification_focus_protocol"
    private const val ISLAND_PROTOCOL_VERSION = 3
    private const val ICON_SIZE_PX = 128
    private const val MAX_NAME_LENGTH = 14

    @Volatile
    private var supported: Boolean? = null

    @Volatile
    private var appIcon: Icon? = null

    /** True only on HyperOS 3+, the first version that has the island. */
    fun isSupported(context: Context): Boolean {
        supported?.let { return it }
        val result = try {
            Settings.System.getInt(context.contentResolver, FOCUS_PROTOCOL_KEY, 0) >= ISLAND_PROTOCOL_VERSION
        } catch (e: Exception) {
            LogUtil.w("HyperIsland", "Cannot read focus protocol: ${e.message}")
            false
        }
        supported = result
        return result
    }

    /**
     * Attaches the island payload to an already built notification.
     * Called on every update, so only the text parts and the button label change.
     */
    fun apply(
        context: Context,
        notification: Notification,
        state: State,
        stopIntent: PendingIntent,
        changeIntent: PendingIntent,
    ) {
        try {
            val icon = getAppIcon(context)

            val pics = Bundle()
            if (icon != null) pics.putParcelable(PIC_APP, icon)

            val stopAction = Notification.Action.Builder(
                Icon.createWithResource(context, R.drawable.ic_delete_24dp),
                "${context.getString(R.string.notification_action_stop_v2ray)} · ${formatPing(state.pingMs)}",
                stopIntent
            ).build()
            val changeAction = Notification.Action.Builder(
                Icon.createWithResource(context, R.drawable.ic_restore_24dp),
                context.getString(R.string.notification_action_change),
                changeIntent
            ).build()
            val actions = Bundle().apply {
                putParcelable(ACTION_STOP, stopAction)
                putParcelable(ACTION_CHANGE, changeAction)
            }

            notification.extras.putBundle(KEY_PICS, pics)
            notification.extras.putBundle(KEY_ACTIONS, actions)
            notification.extras.putString(KEY_PARAM, buildParam(state, icon != null))
        } catch (e: Exception) {
            // Never let a cosmetic feature break the foreground notification.
            LogUtil.e("HyperIsland", "Failed to attach island data", e)
        }
    }

    private fun buildParam(state: State, hasIcon: Boolean): String {
        val customTitle = MmkvManager.decodeSettingsString(AppConfig.PREF_ISLAND_TITLE)?.trim()?.takeIf { it.isNotEmpty() }
        val shortName = (customTitle ?: state.name).ellipsize(MAX_NAME_LENGTH)

        fun picInfo() = JSONObject().put("type", 1).put("pic", PIC_APP)

        val bigIsland = JSONObject().put(
            "imageTextInfoLeft",
            JSONObject().apply {
                put("type", 1)
                if (hasIcon) put("picInfo", picInfo())
                put("textInfo", JSONObject().put("title", shortName))
            }
        )

        val smallIsland = JSONObject().apply {
            if (hasIcon) put("picInfo", picInfo())
        }

        val island = JSONObject()
            .put("islandProperty", 1)
            .put("bigIslandArea", bigIsland)
            .put("smallIslandArea", smallIsland)

        val param = JSONObject()
            .put("protocol", 1)
            .put("business", "vpn")
            // Start as the compact island and never pop open by itself on updates.
            .put("islandFirstFloat", false)
            .put("enableFloat", false)
            .put("updatable", true)
            .put("aodTitle", shortName)
            .put("param_island", island)
            // Expanded state: name on top, IP under it. The ping lives on the Stop button.
            .put(
                "baseInfo",
                JSONObject()
                    .put("type", 1)
                    .put("title", customTitle ?: state.name)
                    .put("content", formatContent(state))
            )
            .put(
                "actions",
                JSONArray()
                    .put(JSONObject().put("action", ACTION_STOP))
                    .put(JSONObject().put("action", ACTION_CHANGE))
            )

        if (hasIcon) param.put("aodPic", PIC_APP)

        return JSONObject().put("param_v2", param).toString()
    }

    /** Exit IP, followed by the download speed of the last test when there is one. */
    private fun formatContent(state: State): String {
        val customText = MmkvManager.decodeSettingsString(AppConfig.PREF_ISLAND_TEXT)?.trim()?.takeIf { it.isNotEmpty() }
        // Text saved before the choice existed (no choice stored) keeps replacing the IP.
        val choice = MmkvManager.decodeSettingsString(AppConfig.PREF_ISLAND_CONTENT)
            ?: if (customText != null) AppConfig.ISLAND_CONTENT_CUSTOM else AppConfig.ISLAND_CONTENT_IP
        val ip = when (choice) {
            AppConfig.ISLAND_CONTENT_PROTOCOL -> state.protocol
            AppConfig.ISLAND_CONTENT_SUBSCRIPTION -> state.subscription
            AppConfig.ISLAND_CONTENT_CUSTOM -> customText
            else -> state.ip
        }?.takeIf { it.isNotBlank() } ?: state.ip ?: "…"
        return if (state.downloadBytesPerSec > 0L) "$ip · ↓ ${state.downloadBytesPerSec.toSpeedString()}" else ip
    }

    private fun formatPing(pingMs: Long?): String = when {
        pingMs == null -> "…"
        pingMs < 0 -> "—"
        else -> "$pingMs ms"
    }

    private fun String.ellipsize(max: Int): String =
        if (length <= max) this else take(max - 1) + "…"

    @Volatile
    private var pictureStamp = 0L

    /** The user's own picture when one was chosen, else the app icon. Re-read only when the picture file changes. */
    private fun getAppIcon(context: Context): Icon? {
        val file = java.io.File(context.filesDir, AppConfig.ISLAND_PICTURE_FILE)
        val stamp = if (file.exists()) file.lastModified() else 0L
        if (stamp != pictureStamp) {
            pictureStamp = stamp
            appIcon = null
        }
        appIcon?.let { return it }
        if (stamp != 0L) {
            try {
                android.graphics.BitmapFactory.decodeFile(file.path)?.let { bitmap ->
                    return Icon.createWithBitmap(bitmap).also { appIcon = it }
                }
            } catch (e: Exception) {
                LogUtil.w("HyperIsland", "Cannot load custom picture: ${e.message}")
            }
        }
        return try {
            val drawable = context.packageManager.getApplicationIcon(context.packageName)
            Icon.createWithBitmap(drawable.toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)).also { appIcon = it }
        } catch (e: Exception) {
            LogUtil.w("HyperIsland", "Cannot load app icon: ${e.message}")
            null
        }
    }
}
