package com.v2ray.ang.ui.compose

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R

/** Shared look of every popup menu: frosted iOS-style panel, thin row dividers, large corners. */
object GlassMenuDefaults {
    val Shape = RoundedCornerShape(26.dp)
    val ItemHeight = 50.dp
    val MenuMinWidth = 220.dp

    @Composable
    fun containerColor(): Color =
        // Almost opaque: the page behind the menu is only faintly visible.
        if (LocalDarkTheme.current) Color(0xFF323238).copy(alpha = 0.97f)
        else Color(0xFFEBEBF0).copy(alpha = 0.97f)

    @Composable
    fun dividerColor(): Color =
        if (LocalDarkTheme.current) Color.White.copy(alpha = 0.14f)
        else Color.Black.copy(alpha = 0.12f)
}

@Composable
fun GlassDropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    offset: DpOffset = DpOffset(0.dp, 0.dp),
    scrollState: ScrollState = rememberScrollState(),
    content: @Composable ColumnScope.() -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismissRequest,
        modifier = modifier.widthIn(min = GlassMenuDefaults.MenuMinWidth),
        offset = offset,
        scrollState = scrollState,
        shape = GlassMenuDefaults.Shape,
        containerColor = GlassMenuDefaults.containerColor(),
        tonalElevation = 0.dp,
        shadowElevation = 12.dp,
        content = content
    )
}

@Composable
fun GlassMenuItem(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    destructive: Boolean = false,
    showDivider: Boolean = true,
) {
    Column {
        if (showDivider) {
            HorizontalDivider(thickness = 0.5.dp, color = GlassMenuDefaults.dividerColor())
        }
        DropdownMenuItem(
            text = {
                Text(
                    text = text,
                    color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal
                )
            },
            onClick = onClick,
            trailingIcon = if (selected) {
                {
                    Icon(
                        painter = painterResource(R.drawable.ic_action_done),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else null,
            contentPadding = PaddingValues(horizontal = 20.dp),
            modifier = modifier.heightIn(min = GlassMenuDefaults.ItemHeight)
        )
    }
}

@Composable
fun <T> AppDropdownMenuItems(
    items: List<T>,
    labelRes: (T) -> Int,
    destructive: (T) -> Boolean = { false },
    onSelected: (T) -> Unit
) {
    items.forEachIndexed { index, item ->
        GlassMenuItem(
            text = stringResource(labelRes(item)),
            onClick = { onSelected(item) },
            destructive = destructive(item),
            showDivider = index > 0
        )
    }
}
