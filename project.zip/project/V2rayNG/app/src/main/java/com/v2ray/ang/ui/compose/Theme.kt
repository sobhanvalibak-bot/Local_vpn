package com.v2ray.ang.ui.compose

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.handler.MmkvManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private val LightColor = lightColorScheme(
    primary = Color(0xFF000000), // Black
    onPrimary = Color(0xFFFFFFFF), // White
    primaryContainer = Color(0xFFE0E0E0), // Light Gray
    onPrimaryContainer = Color(0xFF000000), // Black
    secondary = Color(0xFFf97910), // Orange
    onSecondary = Color(0xFFFFFFFF), // White
    secondaryContainer = Color(0xFFFFE8D6), // Pale Orange
    onSecondaryContainer = Color(0xFF2B1700), // Dark Brown
    tertiary = Color(0xFF009966), // Green
    onTertiary = Color(0xFFFFFFFF), // White
    tertiaryContainer = Color(0xFFA0F2D0), // Light Green
    onTertiaryContainer = Color(0xFF00201A), // Dark Teal
    error = Color(0xFFBA1A1A), // Red
    errorContainer = Color(0xFFFFDAD6), // Light Red
    onError = Color(0xFFFFFFFF), // White
    onErrorContainer = Color(0xFF410002), // Dark Red
    background = Color(0xFFFFFFFF), // White
    onBackground = Color(0xFF1C1B1F), // Near Black
    surface = Color(0xFFFFFFFF), // White
    onSurface = Color(0xFF1C1B1F), // Near Black
    surfaceVariant = Color(0xFFE7E0EC), // Light Purple Gray
    onSurfaceVariant = Color(0xFF49454F), // Dark Gray
    outline = Color(0xFF79747E), // Medium Gray
    outlineVariant = Color(0xFFCAC4D0), // Light Gray
    inverseSurface = Color(0xFF313033), // Dark Gray
    inverseOnSurface = Color(0xFFF4EFF4), // Very Light Gray
    inversePrimary = Color(0xFFC0C0C0), // Silver Gray
    scrim = Color(0xFF000000), // Black
    surfaceTint = Color(0xFF000000), // Black
    surfaceContainerLowest = Color(0xFFFFFFFF), // White
    surfaceContainerLow = Color(0xFFF7F7F7), // Very Light Gray
    surfaceContainer = Color(0xFFF1F1F1), // Light Gray
    surfaceContainerHigh = Color(0xFFEBEBEB), // Light Gray
    surfaceContainerHighest = Color(0xFFE5E5E5), // Light Gray
)

private val DarkColor = darkColorScheme(
    primary = Color(0xFFC0C0C0), // Silver Gray
    onPrimary = Color(0xFF303030), // Dark Gray
    primaryContainer = Color(0xFF474747), // Gray
    onPrimaryContainer = Color(0xFFE0E0E0), // Light Gray
    secondary = Color(0xFFf97910), // Orange
    onSecondary = Color(0xFF4E2600), // Dark Brown
    secondaryContainer = Color(0xFF6F3800), // Brown
    onSecondaryContainer = Color(0xFFFFE8D6), // Pale Orange
    tertiary = Color(0xFF83D6B5), // Mint Green
    onTertiary = Color(0xFF00382E), // Dark Teal
    tertiaryContainer = Color(0xFF005143), // Teal
    onTertiaryContainer = Color(0xFFA0F2D0), // Light Green
    error = Color(0xFFFFB4AB), // Light Red
    errorContainer = Color(0xFF93000A), // Dark Red
    onError = Color(0xFF690005), // Deep Red
    onErrorContainer = Color(0xFFFFDAD6), // Light Red
    background = Color(0xFF1C1B1F), // Near Black
    onBackground = Color(0xFFE6E1E5), // Light Gray
    surface = Color(0xFF1C1B1F), // Near Black
    onSurface = Color(0xFFE6E1E5), // Light Gray
    surfaceVariant = Color(0xFF49454F), // Dark Gray
    onSurfaceVariant = Color(0xFFCAC4D0), // Light Gray
    outline = Color(0xFF938F99), // Grayish Purple
    outlineVariant = Color(0xFF49454F), // Dark Gray
    inverseSurface = Color(0xFFE6E1E5), // Light Gray
    inverseOnSurface = Color(0xFF1C1B1F), // Near Black
    inversePrimary = Color(0xFF000000), // Black
    scrim = Color(0xFF000000), // Black
    surfaceTint = Color(0xFFC0C0C0), // Silver Gray
    surfaceContainerLowest = Color(0xFF0F0F12), // Near Black
    surfaceContainerLow = Color(0xFF1A191D), // Dark Gray
    surfaceContainer = Color(0xFF1E1D21), // Dark Gray
    surfaceContainerHigh = Color(0xFF282729), // Dark Gray
    surfaceContainerHighest = Color(0xFF333234), // Dark Gray
)

/** User-selectable color themes. [DEFAULT] keeps the original monochrome scheme (and dynamic color). */
enum class AppColorTheme(val value: String) {
    DEFAULT("default"),
    PINK("pink"),
    PURPLE("purple"),
    GREEN("green"),
    BLUE("blue"),
    RED("red"),
    MONO("mono");

    companion object {
        /** Unknown or missing stored values fall back to [DEFAULT]. */
        fun fromValue(value: String?): AppColorTheme = values().firstOrNull { it.value == value } ?: DEFAULT
    }
}

/**
 * Compact description of one themed light or dark scheme. Accent roles (secondary, tertiary) reuse the
 * primary hue so the connect button, switches and cursors all follow the chosen theme.
 */
private class ThemePalette(
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val secondaryContainer: Color,
    val surface: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val outline: Color,
)

private fun ThemePalette.toColorScheme(dark: Boolean): ColorScheme {
    val base = if (dark) darkColorScheme() else lightColorScheme()
    fun tone(fraction: Float) = lerp(surface, onSurface, fraction)
    return base.copy(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primaryContainer,
        onPrimaryContainer = onPrimaryContainer,
        secondary = primary,
        onSecondary = onPrimary,
        secondaryContainer = secondaryContainer,
        onSecondaryContainer = onPrimaryContainer,
        tertiary = primary,
        onTertiary = onPrimary,
        tertiaryContainer = primaryContainer,
        onTertiaryContainer = onPrimaryContainer,
        background = surface,
        onBackground = onSurface,
        surface = surface,
        onSurface = onSurface,
        surfaceVariant = tone(0.10f),
        onSurfaceVariant = onSurfaceVariant,
        outline = outline,
        outlineVariant = lerp(surface, outline, 0.5f),
        inverseSurface = onSurface,
        inverseOnSurface = surface,
        inversePrimary = primaryContainer,
        surfaceTint = primary,
        surfaceContainerLowest = if (dark) lerp(surface, Color.Black, 0.4f) else Color.White,
        surfaceContainerLow = tone(0.03f),
        surfaceContainer = tone(0.06f),
        surfaceContainerHigh = tone(0.09f),
        surfaceContainerHighest = tone(0.12f),
    )
}

private val White = Color(0xFFFFFFFF)

private val themedLight = mapOf(
    AppColorTheme.PINK to ThemePalette(Color(0xFFBC1A6E), White, Color(0xFFFFD8E8), Color(0xFF3E0022), Color(0xFFF6DDE5), Color(0xFFFFF8F9), Color(0xFF201A1C), Color(0xFF514347), Color(0xFF847377)),
    AppColorTheme.PURPLE to ThemePalette(Color(0xFF6A40C8), White, Color(0xFFE9DDFF), Color(0xFF22005D), Color(0xFFE8DEF8), Color(0xFFFEF7FF), Color(0xFF1D1B20), Color(0xFF49454F), Color(0xFF7A757F)),
    AppColorTheme.GREEN to ThemePalette(Color(0xFF1B7A43), White, Color(0xFFA6F4BE), Color(0xFF00210E), Color(0xFFD4E8D7), Color(0xFFF6FBF4), Color(0xFF181D18), Color(0xFF414941), Color(0xFF717971)),
    AppColorTheme.BLUE to ThemePalette(Color(0xFF0B5FC4), White, Color(0xFFD6E3FF), Color(0xFF001B3E), Color(0xFFDCE3F2), Color(0xFFF9F9FF), Color(0xFF191C20), Color(0xFF43474E), Color(0xFF74777F)),
    AppColorTheme.RED to ThemePalette(Color(0xFFBF1E2E), White, Color(0xFFFFDAD6), Color(0xFF410006), Color(0xFFF7DCDA), Color(0xFFFFF8F7), Color(0xFF231918), Color(0xFF534341), Color(0xFF857371)),
    AppColorTheme.MONO to ThemePalette(Color(0xFF000000), White, Color(0xFFE0E0E0), Color(0xFF000000), Color(0xFFEEEEEE), White, Color(0xFF111111), Color(0xFF444444), Color(0xFF777777)),
)

private val themedDark = mapOf(
    AppColorTheme.PINK to ThemePalette(Color(0xFFFFB0D0), Color(0xFF640039), Color(0xFF8E0052), Color(0xFFFFD8E8), Color(0xFF594048), Color(0xFF1F1A1C), Color(0xFFEAE0E2), Color(0xFFD5C2C7), Color(0xFF9E8C91)),
    AppColorTheme.PURPLE to ThemePalette(Color(0xFFD0BCFF), Color(0xFF381E72), Color(0xFF4F378B), Color(0xFFEADDFF), Color(0xFF4A4458), Color(0xFF141218), Color(0xFFE6E0E9), Color(0xFFCAC4D0), Color(0xFF938F99)),
    AppColorTheme.GREEN to ThemePalette(Color(0xFF8ADA9F), Color(0xFF00391B), Color(0xFF00522A), Color(0xFFA6F4BE), Color(0xFF3B4B3E), Color(0xFF101410), Color(0xFFE0E4DD), Color(0xFFC1C9BF), Color(0xFF8B938A)),
    AppColorTheme.BLUE to ThemePalette(Color(0xFFAAC7FF), Color(0xFF002F65), Color(0xFF00468C), Color(0xFFD6E3FF), Color(0xFF3E4758), Color(0xFF111318), Color(0xFFE2E2E9), Color(0xFFC3C6CF), Color(0xFF8D9199)),
    AppColorTheme.RED to ThemePalette(Color(0xFFFFB3AD), Color(0xFF680010), Color(0xFF930019), Color(0xFFFFDAD6), Color(0xFF5C3F3D), Color(0xFF201A19), Color(0xFFEDE0DE), Color(0xFFD8C2BF), Color(0xFFA08C8A)),
    AppColorTheme.MONO to ThemePalette(Color(0xFFFFFFFF), Color(0xFF000000), Color(0xFF2A2A2A), Color(0xFFFFFFFF), Color(0xFF1F1F1F), Color(0xFF000000), Color(0xFFF2F2F2), Color(0xFFBDBDBD), Color(0xFF7A7A7A)),
)

/** Returns the scheme for a themed color theme, or null for [AppColorTheme.DEFAULT]. */
internal fun themedColorScheme(theme: AppColorTheme, dark: Boolean): ColorScheme? =
    (if (dark) themedDark else themedLight)[theme]?.toColorScheme(dark)

// Semantic Colors
val colorPing = Color(0xFF009966) // Green
val colorPingRed = Color(0xFFFF0099) // Pink Red

// Ping badge colors shared by the server list and the Telegram page
val pingBadgeGreen = Color(0xFF9DF0B4) // Light Green
val pingBadgeRed = Color(0xFFFFB3D1) // Light Pink
val pingBadgeSlow = Color(0xFFFFE08A) // Light Amber
val colorConfigType = Color(0xFFf97910) // Orange
val colorFabActive = Color(0xFFf97910) // Orange
val colorFabInactiveLight = Color(0xFF9C9C9C) // Gray
val colorFabInactiveDark = Color(0xFF646464) // Dark Gray
val dividerColorLight = Color(0xFFE0E0E0) // Light Gray
val dividerColorDark = Color(0xFF424242) // Dark Gray

// Toast Colors 85%
val toastNormalBgLight = Color(0xD9353A3E) // Dark Gray
val toastNormalBgDark = Color(0xD94A4F54) // Darker Gray
val toastSuccessBg = Color(0xD9388E3C) // Green
val toastErrorBg = Color(0xD9D50000) // Red
val toastInfoBg = Color(0xD93F51B5) // Indigo Blue
val toastIconCircleBg = Color(0x33FFFFFF) // Semi-transparent White
val toastTextColor = Color.White // White

object ThemeManager {
    private val _themeMode = MutableStateFlow(
        MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "0") ?: "0"
    )
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _dynamicColorEnabled = MutableStateFlow(
        MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, true)
    )
    val dynamicColorEnabled: StateFlow<Boolean> = _dynamicColorEnabled.asStateFlow()

    private val _colorTheme = MutableStateFlow(
        AppColorTheme.fromValue(MmkvManager.decodeSettingsString(AppConfig.PREF_COLOR_THEME, AppColorTheme.DEFAULT.value))
    )
    val colorTheme: StateFlow<AppColorTheme> = _colorTheme.asStateFlow()

    fun setColorTheme(value: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_COLOR_THEME, value)
        _colorTheme.value = AppColorTheme.fromValue(value)
    }

    fun setThemeMode(mode: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_UI_MODE_NIGHT, mode)
        _themeMode.value = mode
    }

    fun setDynamicColorEnabled(enabled: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_DYNAMIC_COLOR, enabled)
        _dynamicColorEnabled.value = enabled
    }

    fun refresh() {
        _themeMode.value =
            MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "0") ?: "0"
        _dynamicColorEnabled.value =
            MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, true)
        _colorTheme.value = AppColorTheme.fromValue(
            MmkvManager.decodeSettingsString(AppConfig.PREF_COLOR_THEME, AppColorTheme.DEFAULT.value)
        )
    }
}

@Composable
fun resolveDarkTheme(): Boolean {
    val mode by ThemeManager.themeMode.collectAsState()
    return when (mode) {
        "1" -> false
        "2" -> true
        else -> isSystemInDarkTheme()
    }
}

val LocalDarkTheme = compositionLocalOf { false }

@Composable
fun AppTheme(
    darkTheme: Boolean = resolveDarkTheme(),
    content: @Composable () -> Unit
) {
    val dynamicColor by ThemeManager.dynamicColorEnabled.collectAsState()
    val colorTheme by ThemeManager.colorTheme.collectAsState()
    val context = LocalContext.current
    val themedScheme = themedColorScheme(colorTheme, darkTheme)
    val colorScheme = when {
        // A chosen color theme takes precedence over dynamic color.
        themedScheme != null -> themedScheme

        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColor
        else -> LightColor
    }
    val snackbarController = rememberAppSnackbarController()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity ?: return@SideEffect
            val window = activity.window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalDarkTheme provides darkTheme,
        LocalAppSnackbar provides snackbarController
    ) {
        MaterialTheme(
            colorScheme = colorScheme
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AppSnackbarBridge(controller = snackbarController)
                content()
                AppSnackbarHost(hostState = snackbarController.hostState)
            }
        }
    }
}
