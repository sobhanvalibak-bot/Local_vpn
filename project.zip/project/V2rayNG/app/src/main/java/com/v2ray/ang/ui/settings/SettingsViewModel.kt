package com.v2ray.ang.ui.settings

import android.app.Application
import android.content.Intent
import android.provider.Settings
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.root.RootManager
import com.v2ray.ang.ui.base.BaseViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class SettingsViewModel(application: Application) : BaseViewModel(application) {

    private val _systemVpnSettingsAvailable = MutableStateFlow(false)
    val systemVpnSettingsAvailable = _systemVpnSettingsAvailable.asStateFlow()

    suspend fun refreshSystemVpnSettingsAvailability() {
        _systemVpnSettingsAvailable.value = withContext(Dispatchers.IO) {
            // Android exposes the VPN page, not a direct link to the Always-on VPN switch.
            Intent(Settings.ACTION_VPN_SETTINGS).resolveActivity(getApplication<Application>().packageManager) != null
        }
    }

    /**
     * Saves the picture chosen for the Xiaomi island: cropped to a square and scaled, off the main thread.
     * The island reads it from the app files dir, so a failed save leaves the previous picture untouched.
     */
    fun saveIslandPicture(uri: android.net.Uri) {
        launchLoading {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val app = getApplication<Application>()
                    val source = app.contentResolver.openInputStream(uri)?.use {
                        android.graphics.BitmapFactory.decodeStream(it)
                    } ?: return@withContext false
                    val side = minOf(source.width, source.height)
                    val square = android.graphics.Bitmap.createBitmap(
                        source, (source.width - side) / 2, (source.height - side) / 2, side, side
                    )
                    val scaled = android.graphics.Bitmap.createScaledBitmap(square, ISLAND_PICTURE_SIZE_PX, ISLAND_PICTURE_SIZE_PX, true)
                    val target = java.io.File(app.filesDir, AppConfig.ISLAND_PICTURE_FILE)
                    val temp = java.io.File(app.filesDir, AppConfig.ISLAND_PICTURE_FILE + ".tmp")
                    temp.outputStream().use { scaled.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    temp.renameTo(target)
                } catch (e: Exception) {
                    com.v2ray.ang.util.LogUtil.e(AppConfig.TAG, "Failed to save island picture", e)
                    false
                }
            }
            if (ok) toast(R.string.island_picture_saved) else toastError(R.string.toast_failure)
        }
    }

    fun clearIslandPicture() {
        launchLoading {
            withContext(Dispatchers.IO) {
                java.io.File(getApplication<Application>().filesDir, AppConfig.ISLAND_PICTURE_FILE).delete()
            }
            toast(R.string.island_picture_cleared)
        }
    }

    private companion object {
        const val ISLAND_PICTURE_SIZE_PX = 128
    }

    /**
     * Checks for root access and requests it if necessary.
     * Updates [isLoading] during the process.
     */
    fun checkAndRequestRoot(onSuccess: () -> Unit) {
        launchLoading {
            val hasRoot = withContext(Dispatchers.IO) {
                RootManager.refresh()
            }
            if (hasRoot) {
                onSuccess()
            } else {
                toastError(R.string.toast_root_required)
            }
        }
    }

    /**
     * Validates if the given string is a valid observatory duration.
     * Shows error toast if invalid.
     * @return The trimmed value if valid, null otherwise.
     */
    fun validateObservatoryDuration(value: String): String? {
        val duration = value.trim()
        return if (AppConfig.OBSERVATORY_DURATION_PATTERN.matches(duration)) {
            duration
        } else {
            toastError(R.string.toast_invalid_observatory_duration)
            null
        }
    }

    /**
     * Validates if the given string is a valid observatory sampling value.
     * Shows error toast if invalid.
     * @return The value if valid, null otherwise.
     */
    fun validateObservatorySampling(value: String): String? {
        val sampling = value.trim().toIntOrNull()?.takeIf { it > 0 }
        return if (sampling != null) {
            sampling.toString()
        } else {
            toastError(R.string.toast_invalid_observatory_sampling)
            null
        }
    }
}
