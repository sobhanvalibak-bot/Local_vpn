package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.UrlContentRequest
import com.v2ray.ang.util.HttpUtil
import com.v2ray.ang.util.LogUtil
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Finds the country of a server (by the IP its host resolves to) and turns it into a flag emoji.
 * Results are cached in memory and persisted, so each host is looked up only once.
 */
object ServerCountryResolver {
    private const val KEY_PREFIX = "pref_server_country_"
    private const val RETRY_AFTER_MS = 10 * 60 * 1000L

    private val memory = ConcurrentHashMap<String, String>()
    private val failedAt = ConcurrentHashMap<String, Long>()
    private val limiter = Semaphore(4)

    /** Country code ("DE") if already known, without any network access. */
    fun cached(host: String): String? {
        memory[host]?.let { return it }
        val stored = MmkvManager.decodeSettingsString(KEY_PREFIX + host)
        if (!stored.isNullOrEmpty()) {
            memory[host] = stored
            return stored
        }
        return null
    }

    /** Returns the country code for [host], looking it up if needed. Null when unknown. */
    suspend fun resolve(host: String): String? {
        cached(host)?.let { return it }
        val last = failedAt[host]
        if (last != null && System.currentTimeMillis() - last < RETRY_AFTER_MS) return null

        return limiter.withPermit {
            // Another row with the same host may have finished while we waited.
            cached(host)?.let { return@withPermit it }
            val code = withContext(Dispatchers.IO) { lookup(host) }
            if (code != null) {
                memory[host] = code
                MmkvManager.encodeSettings(KEY_PREFIX + host, code)
                failedAt.remove(host)
            } else {
                failedAt[host] = System.currentTimeMillis()
            }
            code
        }
    }

    private fun lookup(host: String): String? {
        val ip = if (Utils.isPureIpAddress(host)) host else HttpUtil.resolveHostToIP(host)?.firstOrNull()
        if (ip.isNullOrEmpty() || isLocalAddress(ip)) return null

        for (source in SOURCES) {
            val body = HttpUtil.getUrlContent(UrlContentRequest(url = source.url(ip), timeout = 6000))
            val code = body?.let { source.parse(it) }?.uppercase()
            if (code != null && code.length == 2 && code.all { it in 'A'..'Z' }) return code
        }
        LogUtil.w(AppConfig.TAG, "Country lookup failed for $host ($ip)")
        return null
    }

    private fun isLocalAddress(ip: String): Boolean = runCatching {
        val addr = InetAddress.getByName(ip)
        addr.isLoopbackAddress || addr.isAnyLocalAddress || addr.isSiteLocalAddress || addr.isLinkLocalAddress
    }.getOrDefault(false)

    private class Source(val url: (String) -> String, val parse: (String) -> String?)

    private val SOURCES = listOf(
        Source({ "https://api.country.is/$it" }) { runCatching { JSONObject(it).optString("country") }.getOrNull() },
        Source({ "https://ipwho.is/$it" }) { runCatching { JSONObject(it).optString("country_code") }.getOrNull() },
        Source({ "https://ipapi.co/$it/country/" }) { it.trim() },
    )

    /** "DE" -> flag emoji. Null for anything that is not a two-letter code. */
    fun flagEmoji(code: String?): String? {
        if (code == null || code.length != 2) return null
        val upper = code.uppercase()
        if (!upper.all { it in 'A'..'Z' }) return null
        return upper.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
    }
}
