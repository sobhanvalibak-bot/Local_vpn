package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.util.LogUtil
import java.net.URLDecoder
import java.util.Locale

/**
 * Parses Telegram MTProto proxy links (`https://t.me/proxy?...`, `tg://proxy?...`) out of free text
 * and measures TCP connect latency to each of them.
 *
 * These proxies are not v2ray profiles: they are never stored in MMKV and never start the core.
 */
object TelegramProxyManager {

    /** Secret flavours defined by the MTProto proxy protocol. */
    enum class SecretMode { PLAIN, PADDED, FAKE_TLS, UNKNOWN }

    data class TelegramProxy(
        val server: String,
        val port: Int,
        val secret: String,
        val mode: SecretMode,
        val link: String,
    ) {
        /** Stable identity used for list keys and async results; never a list position. */
        val id: String get() = "${server.lowercase(Locale.ROOT)}|$port|$secret"
    }

    /** Latency in milliseconds, or [FAILED] when the proxy did not accept a TCP connection. */
    const val FAILED = -1L

    private const val MAX_PROXIES = 200
    private const val MAX_SECRET_LENGTH = 512
    private const val PING_TIMEOUT_MS = 3000

    private val LINK_REGEX = Regex(
        """(?:https?://)?(?:t\.me|telegram\.me|telegram\.dog)/proxy\?[^\s<>"']+|tg://proxy\?[^\s<>"']+""",
        RegexOption.IGNORE_CASE
    )
    private val HOST_REGEX = Regex("""^[A-Za-z0-9]([A-Za-z0-9.\-]*[A-Za-z0-9])?$""")
    private val HEX_REGEX = Regex("""^[0-9a-fA-F]+$""")
    private const val TRAILING_PUNCTUATION = ".,;:)]}>»"

    /** True when [text] contains at least one syntactically valid Telegram proxy link. */
    fun containsProxy(text: String?): Boolean = !text.isNullOrBlank() && parse(text).isNotEmpty()

    /** Extracts every valid, de-duplicated proxy from [text], preserving the order of appearance. */
    fun parse(text: String?): List<TelegramProxy> {
        if (text.isNullOrBlank()) return emptyList()
        val result = LinkedHashMap<String, TelegramProxy>()
        for (match in LINK_REGEX.findAll(text)) {
            val raw = match.value.trimEnd { it in TRAILING_PUNCTUATION }
            // Links pasted without a scheme ("t.me/proxy?...") still need one to be openable.
            val link = if (raw.startsWith("tg://", true) || raw.startsWith("http", true)) raw else "https://$raw"
            val proxy = parseLink(link) ?: continue
            result.putIfAbsent(proxy.id, proxy)
            if (result.size >= MAX_PROXIES) break
        }
        return result.values.toList()
    }

    /** Parses one link; returns null when server, port, or secret is missing or malformed. */
    fun parseLink(link: String): TelegramProxy? {
        val query = link.substringAfter('?', "").substringBefore('#')
        if (query.isEmpty()) return null
        val params = HashMap<String, String>()
        for (part in query.replace("&amp;", "&").split('&')) {
            val key = part.substringBefore('=').lowercase(Locale.ROOT)
            val value = part.substringAfter('=', "")
            if (key.isEmpty()) continue
            val decoded = try {
                URLDecoder.decode(value, "UTF-8")
            } catch (e: IllegalArgumentException) {
                continue
            }
            params.putIfAbsent(key, decoded.trim())
        }

        val server = params["server"].orEmpty()
        val port = params["port"]?.toIntOrNull() ?: return null
        val secret = params["secret"].orEmpty()
        if (server.length > 253 || !HOST_REGEX.matches(server)) return null
        if (port !in 1..65535) return null
        if (secret.isEmpty() || secret.length > MAX_SECRET_LENGTH) return null

        val bytes = decodeSecret(secret) ?: return null
        return TelegramProxy(server, port, secret, classify(bytes), link)
    }

    /** Hex or base64url, as accepted by official Telegram clients. */
    internal fun decodeSecret(secret: String): ByteArray? {
        if (HEX_REGEX.matches(secret)) {
            if (secret.length % 2 != 0) return null
            return ByteArray(secret.length / 2) { i ->
                secret.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
        }
        return decodeBase64Url(secret)
    }

    // Hand-written so the same code runs in JVM unit tests and on minSdk 24 without java.util.Base64.
    private fun decodeBase64Url(input: String): ByteArray? {
        val clean = input.trimEnd('=')
        var buffer = 0
        var bits = 0
        val out = ArrayList<Byte>(clean.length * 3 / 4)
        for (c in clean) {
            val v = when (c) {
                in 'A'..'Z' -> c - 'A'
                in 'a'..'z' -> c - 'a' + 26
                in '0'..'9' -> c - '0' + 52
                '-', '+' -> 62
                '_', '/' -> 63
                else -> return null
            }
            buffer = (buffer shl 6) or v
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out.add(((buffer shr bits) and 0xFF).toByte())
            }
        }
        return out.toByteArray()
    }

    private fun classify(bytes: ByteArray): SecretMode = when {
        bytes.size == 16 -> SecretMode.PLAIN
        bytes.size == 17 && bytes[0] == 0xDD.toByte() -> SecretMode.PADDED
        bytes.size > 17 && bytes[0] == 0xEE.toByte() -> SecretMode.FAKE_TLS
        else -> SecretMode.UNKNOWN
    }

    /**
     * TCP connect latency (DNS lookup included) to the proxy endpoint.
     * Blocking: call from Dispatchers.IO only.
     */
    fun ping(proxy: TelegramProxy): Long {
        return try {
            SpeedtestManager.socketConnectTime(proxy.server, proxy.port, PING_TIMEOUT_MS)
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "Telegram proxy ping failed: ${proxy.server}:${proxy.port}", e)
            FAILED
        }
    }
}
