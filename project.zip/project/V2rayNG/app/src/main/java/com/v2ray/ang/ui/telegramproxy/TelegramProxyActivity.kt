package com.v2ray.ang.ui.telegramproxy

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.handler.SubscriptionInfoParser
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.ItemDivider
import com.v2ray.ang.ui.compose.NavigationBarsBottomPadding
import com.v2ray.ang.ui.compose.colorPing
import com.v2ray.ang.ui.compose.colorPingRed
import com.v2ray.ang.ui.compose.colorConfigType
import com.v2ray.ang.util.Utils

class TelegramProxyActivity : BaseComponentActivity() {
    private val viewModel: TelegramProxyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Only on first creation; after recreation the ViewModel already holds the results.
        if (savedInstanceState == null) {
            intent.getStringExtra(EXTRA_TEXT)?.takeIf { it.isNotBlank() }?.let {
                viewModel.onAction(TelegramProxyAction.Test(it))
            }
        }
    }

    @Composable
    override fun ScreenContent() {
        TelegramProxyScreen(viewModel = viewModel, onBackClick = { finish() })
    }

    companion object {
        private const val EXTRA_TEXT = "telegram_proxy_text"

        fun newIntent(context: Context, text: String? = null): Intent =
            Intent(context, TelegramProxyActivity::class.java).apply {
                // Keeps the Binder transaction far below its 1 MB limit.
                if (text != null) putExtra(EXTRA_TEXT, text.take(TelegramProxyViewModel.MAX_INPUT_LENGTH))
            }
    }
}

@Composable
fun TelegramProxyScreen(
    viewModel: TelegramProxyViewModel,
    onBackClick: () -> Unit,
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            AppTopBar(
                title = stringResource(R.string.title_telegram_proxy),
                onBackClick = onBackClick,
                isLoading = state.isTesting,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
                .imePadding(),
            contentPadding = NavigationBarsBottomPadding(),
        ) {
            item(key = "input") {
                Column {
                    FormTextField(
                        label = stringResource(R.string.telegram_proxy_hint),
                        value = state.input,
                        onValueChange = { viewModel.onAction(TelegramProxyAction.SetInput(it)) },
                        maxLines = 8,
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.onAction(TelegramProxyAction.PasteAndTest) },
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.telegram_proxy_paste)) }
                        Button(
                            onClick = { viewModel.onAction(TelegramProxyAction.Test()) },
                            enabled = state.input.isNotBlank() && !state.isTesting,
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.telegram_proxy_test)) }
                    }
                }
            }
            if (state.hasTested && state.rows.isEmpty()) {
                item(key = "empty") {
                    Text(
                        text = stringResource(R.string.telegram_proxy_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
            items(state.rows, key = { it.proxy.id }) { row ->
                TelegramProxyRowItem(
                    row = row,
                    onOpen = {
                        SubscriptionInfoParser.sanitizeLink(row.proxy.link)?.let { Utils.openUri(context, it) }
                    },
                )
                ItemDivider()
            }
        }
    }
}

@Composable
private fun TelegramProxyRowItem(row: TelegramProxyRow, onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // One merged node (address + latency) so TalkBack reads the row once; the button stays separate.
        Column(
            modifier = Modifier
                .weight(1f)
                .semantics(mergeDescendants = true) {},
        ) {
            Text(
                text = "${row.proxy.server}:${row.proxy.port}",
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = statusText(row.status),
                style = MaterialTheme.typography.bodyMedium,
                color = statusColor(row.status),
            )
        }
        TextButton(onClick = onOpen) { Text(stringResource(R.string.telegram_proxy_open)) }
    }
}

@Composable
private fun statusText(status: PingStatus): String = when (status) {
    PingStatus.Testing -> stringResource(R.string.telegram_proxy_testing)
    is PingStatus.Done -> stringResource(R.string.telegram_proxy_ping_ms, status.millis)
    PingStatus.Failed -> stringResource(R.string.telegram_proxy_timeout)
}

private fun statusColor(status: PingStatus): Color = when {
    status is PingStatus.Done && status.millis < SLOW_PING_MS -> colorPing
    status is PingStatus.Done -> colorConfigType
    status is PingStatus.Failed -> colorPingRed
    else -> Color.Unspecified
}

private const val SLOW_PING_MS = 800L
