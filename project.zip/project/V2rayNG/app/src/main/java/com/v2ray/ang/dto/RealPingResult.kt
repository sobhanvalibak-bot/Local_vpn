package com.v2ray.ang.dto

import java.io.Serializable

/** One persisted delay-test result delivered from the task process to the UI. */
data class RealPingResult(
    val guid: String,
    val delayMillis: Long,
    /** Measured download speed in bytes per second; 0 when it was not measured or failed. */
    val downloadBytesPerSec: Long = 0L,
) : Serializable
