package com.v2ray.ang.dto

import java.io.Serializable

/** Proxy throughput in bytes per second, sent from the daemon process to the UI. */
data class TrafficSpeed(
    val downlinkBytesPerSec: Long = 0L,
    val uplinkBytesPerSec: Long = 0L,
) : Serializable
