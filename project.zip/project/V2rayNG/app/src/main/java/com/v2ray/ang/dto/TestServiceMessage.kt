package com.v2ray.ang.dto

import java.io.Serializable

data class TestServiceMessage(
    val key: Int,
    val subscriptionId: String = "",
    val serverGuids: List<String> = emptyList(),
    val onlyTcp: Boolean = false,
    /** Also measure the download speed of every profile whose ping succeeded (real-ping tests only). */
    val measureDownload: Boolean = false
) : Serializable

