package com.v2ray.ang.ui.main

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.ChatImageCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Full-screen chat with one device of the Local test list, picked by IP. Sends text, photos and configs;
 * a received config card can be added to the config list with one tap.
 */
@Composable
fun LocalChatScreen(
    state: LocalTestUiState,
    onAction: (MainAction) -> Unit,
) {
    val peerIp = state.chatPeer ?: return
    val peer = state.peers.firstOrNull { it.ip == peerIp }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    BackHandler { onAction(MainAction.LocalTestCloseChat) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val encoded = withContext(Dispatchers.IO) { ChatImageCodec.encodeUri(context, uri) }
                if (encoded != null) onAction(MainAction.LocalTestSendImage(encoded))
            }
        }
    }

    LaunchedEffect(state.chatMessages.size) {
        if (state.chatMessages.isNotEmpty()) listState.animateScrollToItem(state.chatMessages.lastIndex)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            // Swallow touches so nothing underneath the chat reacts.
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding()
            .imePadding()
    ) {
        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                TextButton(onClick = { onAction(MainAction.LocalTestCloseChat) }) {
                    Text(stringResource(R.string.local_test_chat_back))
                }
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = peerIp.substringAfterLast('.'),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = peerIp,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                        fontWeight = FontWeight.SemiBold,
                    )
                    val online = peer?.online == true
                    Text(
                        text = stringResource(if (online) R.string.local_test_online else R.string.local_test_offline),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (online) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(state.chatMessages, key = { it.id }) { message ->
                ChatBubble(message = message, onAction = onAction)
            }
        }

        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                TextButton(onClick = { photoPicker.launch("image/*") }) {
                    Text(stringResource(R.string.local_test_chat_photo), maxLines = 1)
                }
                TextButton(onClick = { onAction(MainAction.LocalTestPickConfig) }) {
                    Text(stringResource(R.string.local_test_chat_config), maxLines = 1)
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    shape = RoundedCornerShape(24.dp),
                    placeholder = { Text(stringResource(R.string.local_test_chat_hint)) },
                )
                FilledIconButton(
                    onClick = {
                        val toSend = text.trim()
                        if (toSend.isNotEmpty()) {
                            onAction(MainAction.LocalTestSendText(toSend))
                            text = ""
                        }
                    },
                    enabled = text.isNotBlank(),
                ) {
                    Text(stringResource(R.string.local_test_chat_send), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    state.configPicker?.let { configs ->
        AlertDialog(
            onDismissRequest = { onAction(MainAction.LocalTestPickConfigDismiss) },
            title = { Text(stringResource(R.string.local_test_chat_pick_config)) },
            text = {
                LazyColumn {
                    items(configs, key = { it.guid }) { config ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onAction(MainAction.LocalTestSendConfig(config.guid)) }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = config.remarks,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (config.delayMillis > 0L) {
                                Text(
                                    text = "${config.delayMillis} ms",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(start = 8.dp),
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { onAction(MainAction.LocalTestPickConfigDismiss) }) {
                    Text(stringResource(android.R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun ChatBubble(message: ChatMessageUi, onAction: (MainAction) -> Unit) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.mine) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = if (message.mine) colors.primaryContainer else colors.surfaceContainerHigh,
            contentColor = if (message.mine) colors.onPrimaryContainer else colors.onSurface,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 280.dp),
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (message.kind) {
                    "image" -> {
                        val bitmap = remember(message.id) {
                            message.image?.let { ChatImageCodec.decode(it) }?.asImageBitmap()
                        }
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap,
                                contentDescription = stringResource(R.string.local_test_chat_photo),
                                contentScale = ContentScale.FillWidth,
                                modifier = Modifier
                                    .width(220.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                            )
                        } else {
                            Text(stringResource(R.string.local_test_chat_photo))
                        }
                    }

                    "config" -> {
                        val lines = message.text.lines().filter { it.isNotBlank() }
                        Text(
                            text = stringResource(R.string.local_test_chat_config),
                            style = MaterialTheme.typography.labelMedium,
                        )
                        Text(
                            text = lines.firstOrNull().orEmpty(),
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.width(220.dp),
                        )
                        if (!message.mine) {
                            Button(
                                onClick = { onAction(MainAction.LocalTestAddReceived(message.text)) },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(stringResource(R.string.local_test_chat_add))
                            }
                        }
                    }

                    else -> Text(text = message.text, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
