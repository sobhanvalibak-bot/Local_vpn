package com.v2ray.ang.handler

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.v2ray.ang.AppConfig
import com.v2ray.ang.util.LogUtil
import java.io.File
import java.util.UUID

/** A picked file copied into the app's cache, ready to be uploaded. */
data class StagedFile(val file: File, val name: String, val mime: String)

sealed interface StageResult {
    data class Ok(val staged: StagedFile) : StageResult
    data object TooLarge : StageResult
    data object Failed : StageResult
}

/** Copies a file picked by the user into the cache (up to 25 MB, streamed) so it can be sent. Blocking: use Dispatchers.IO. */
object LocalFileStaging {

    fun stage(context: Context, uri: Uri): StageResult {
        val dir = File(context.cacheDir, "outgoing").apply { mkdirs() }
        val temp = File(dir, UUID.randomUUID().toString())
        return try {
            val (name, declaredSize) = describe(context, uri)
            if (declaredSize != null && declaredSize > LocalProfileRules.MAX_FILE_BYTES) return StageResult.TooLarge
            var total = 0L
            val input = context.contentResolver.openInputStream(uri) ?: return StageResult.Failed
            input.use { source ->
                temp.outputStream().use { out ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val read = source.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > LocalProfileRules.MAX_FILE_BYTES) {
                            temp.delete()
                            return StageResult.TooLarge
                        }
                        out.write(buffer, 0, read)
                    }
                }
            }
            if (total == 0L) {
                temp.delete()
                StageResult.Failed
            } else {
                val mime = context.contentResolver.getType(uri)?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
                StageResult.Ok(StagedFile(temp, LocalProfileRules.sanitizeFileName(name), mime))
            }
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "LocalTest: failed to stage file", e)
            temp.delete()
            StageResult.Failed
        }
    }

    private fun describe(context: Context, uri: Uri): Pair<String, Long?> {
        var name = uri.lastPathSegment.orEmpty()
        var size: Long? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { c.getString(it)?.let { n -> name = n } }
                c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 && !c.isNull(it) }?.let { size = c.getLong(it) }
            }
        }
        return name to size
    }
}
