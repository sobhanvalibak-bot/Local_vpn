package com.v2ray.ang.ui.main

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R
import com.v2ray.ang.handler.ServerCountryResolver
import com.v2ray.ang.handler.SubscriptionInfoParser
import com.v2ray.ang.ui.compose.SelectListDialog
import com.v2ray.ang.ui.compose.pingBadgeGreen
import com.v2ray.ang.ui.compose.pingBadgeRed
import com.v2ray.ang.ui.compose.pingBadgeSlow
import com.v2ray.ang.util.Utils

private const val SLOW_PING_MS = 800L

private enum class ProxyMenuAction(val labelRes: Int) {
    Copy(R.string.share_method_clipboard),
    QRCode(R.string.share_method_qrcode),
    ShareAsLocal(R.string.share_as_local),
    Open(R.string.telegram_proxy_open),
    Delete(R.string.menu_item_del_config),
}

/**
 * Content of the "Telegram" tab: the saved MTProto proxies as cards that look like the config cards
 * (protocol tab, card with the country flag above the ping badge, action panel). The share button
 * opens a menu: copy link, QR code, share as local, open in Telegram, delete.
 */
@Composable
fun TelegramProxyPage(
    state: TelegramTabUiState,
    onAction: (MainAction) -> Unit,
    contentPadding: PaddingValues,
) {
    val context = LocalContext.current
    var menuFor by remember { mutableStateOf<TelegramRow?>(null) }
    if (state.rows.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(R.string.telegram_tab_empty),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        return
    }
    val openProxy: (TelegramRow) -> Unit = { row ->
        SubscriptionInfoParser.sanitizeLink(row.proxy.link)?.let { Utils.openUri(context, it) }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = contentPadding,
    ) {
        items(state.rows, key = { it.proxy.id }) { row ->
            TelegramProxyCard(
                row = row,
                onOpen = { openProxy(row) },
                onShare = { menuFor = row },
            )
        }
    }
    menuFor?.let { row ->
        SelectListDialog(
            options = ProxyMenuAction.entries,
            optionText = { stringResource(it.labelRes) },
            onSelected = { action ->
                menuFor = null
                when (action) {
                    ProxyMenuAction.Copy -> {
                        Utils.setClipboard(context, row.proxy.link)
                        Toast.makeText(context, R.string.toast_success, Toast.LENGTH_SHORT).show()
                    }
                    ProxyMenuAction.QRCode -> onAction(MainAction.TelegramShowQRCode(row.proxy.link))
                    ProxyMenuAction.ShareAsLocal -> onAction(MainAction.TelegramShareAsLocal(row.proxy.id))
                    ProxyMenuAction.Open -> openProxy(row)
                    ProxyMenuAction.Delete -> onAction(MainAction.TelegramRemove(row.proxy.id))
                }
            },
            onDismiss = { menuFor = null },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun TelegramProxyCard(
    row: TelegramRow,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    checked: Boolean = false,
    onClick: () -> Unit = onOpen,
    onLongClick: () -> Unit = onShare,
) {
    val flag = ServerCountryResolver.flagEmoji(row.countryCode)
    val panelColor = MaterialTheme.colorScheme.surfaceContainerHighest
    val inkColor = MaterialTheme.colorScheme.onSurface
    val ping = row.ping
    val pingText = when (ping) {
        TelegramPing.Testing -> stringResource(R.string.telegram_proxy_testing)
        is TelegramPing.Done -> stringResource(R.string.telegram_proxy_ping_ms, ping.millis)
        TelegramPing.Failed -> stringResource(R.string.telegram_proxy_timeout)
    }
    val pingColor = when (ping) {
        is TelegramPing.Done -> if (ping.millis < SLOW_PING_MS) pingBadgeGreen else pingBadgeSlow
        TelegramPing.Failed -> pingBadgeRed
        TelegramPing.Testing -> MaterialTheme.colorScheme.surfaceVariant
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .height(IntrinsicSize.Min),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Protocol tab, reading bottom-to-top like the config cards.
        Box(
            modifier = Modifier
                .width(40.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(14.dp))
                .background(panelColor),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "MTPROTO",
                modifier = Modifier
                    .wrapContentWidth(unbounded = true)
                    .rotate(-90f),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                softWrap = false,
            )
        }

        Surface(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(14.dp),
            color = if (checked) {
                androidx.compose.ui.graphics.lerp(
                    MaterialTheme.colorScheme.surfaceContainerLowest,
                    MaterialTheme.colorScheme.primary,
                    0.14f,
                )
            } else MaterialTheme.colorScheme.surfaceContainerLowest,
            border = if (checked) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null,
        ) {
            Column(
                modifier = Modifier
                    .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .semantics(mergeDescendants = true) {},
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (checked) {
                        Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        "${row.proxy.server}:${row.proxy.port}",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        row.proxy.mode.name,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        // Country first, the ping badge right under it.
                        if (flag != null) {
                            Text(flag, fontSize = 16.sp)
                            Spacer(Modifier.height(4.dp))
                        }
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(pingColor)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                pingText.replace(" ", ""),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (ping == TelegramPing.Testing) MaterialTheme.colorScheme.onSurfaceVariant else Color.Black,
                                maxLines = 1,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }

        // Action panel: open in Telegram (filled) + share (outlined).
        Row(
            modifier = Modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(14.dp))
                .background(panelColor)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(inkColor)
                    .clickable(onClick = onOpen),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painterResource(R.drawable.ic_telegram_24dp),
                    stringResource(R.string.telegram_proxy_open),
                    Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.surface,
                )
            }
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .border(2.dp, inkColor, CircleShape)
                    .clickable(onClick = onShare),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painterResource(R.drawable.ic_share_24dp),
                    stringResource(R.string.title_configuration_share),
                    Modifier.size(18.dp),
                    tint = inkColor,
                )
            }
        }
    }
}
