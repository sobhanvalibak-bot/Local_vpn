package com.v2ray.ang.ui.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.ServerCountryResolver
import com.v2ray.ang.handler.SubscriptionInfoParser
import com.v2ray.ang.ui.compose.ItemDivider
import com.v2ray.ang.ui.compose.colorConfigType
import com.v2ray.ang.ui.compose.colorPing
import com.v2ray.ang.ui.compose.colorPingRed
import com.v2ray.ang.util.Utils

private const val SLOW_PING_MS = 800L

/**
 * Content of the "Telegram" tab: the saved MTProto proxies with their ping and the flag of the
 * country their server is in. Tapping a row (or "Open") hands the link to Telegram.
 */
@Composable
fun TelegramProxyPage(
    state: TelegramTabUiState,
    onAction: (MainAction) -> Unit,
    contentPadding: PaddingValues,
) {
    val context = LocalContext.current
    if (state.rows.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(R.string.telegram_tab_empty),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = contentPadding,
    ) {
        items(state.rows, key = { it.proxy.id }) { row ->
            val open = {
                SubscriptionInfoParser.sanitizeLink(row.proxy.link)?.let { Utils.openUri(context, it) }
                Unit
            }
            TelegramProxyRowItem(
                row = row,
                onOpen = open,
                onRemove = { onAction(MainAction.TelegramRemove(row.proxy.id)) },
            )
            ItemDivider()
        }
    }
}

@Composable
private fun TelegramProxyRowItem(row: TelegramRow, onOpen: () -> Unit, onRemove: () -> Unit) {
    val flag = ServerCountryResolver.flagEmoji(row.countryCode)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .semantics(mergeDescendants = true) {},
        ) {
            Text(
                text = listOfNotNull(flag, row.countryCode, "${row.proxy.server}:${row.proxy.port}").joinToString(" "),
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = when (val p = row.ping) {
                    TelegramPing.Testing -> stringResource(R.string.telegram_proxy_testing)
                    is TelegramPing.Done -> stringResource(R.string.telegram_proxy_ping_ms, p.millis)
                    TelegramPing.Failed -> stringResource(R.string.telegram_proxy_timeout)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = when (val p = row.ping) {
                    is TelegramPing.Done -> if (p.millis < SLOW_PING_MS) colorPing else colorConfigType
                    TelegramPing.Failed -> colorPingRed
                    TelegramPing.Testing -> Color.Unspecified
                },
            )
        }
        TextButton(onClick = onOpen) { Text(stringResource(R.string.telegram_proxy_open)) }
        IconButton(onClick = onRemove, modifier = Modifier.size(40.dp)) {
            Icon(
                painterResource(R.drawable.ic_delete_24dp),
                stringResource(R.string.menu_item_del_config),
                Modifier.size(22.dp),
            )
        }
    }
}
