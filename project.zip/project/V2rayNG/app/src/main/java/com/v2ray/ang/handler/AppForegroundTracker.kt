package com.v2ray.ang.handler

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tells whether any of the app's activities is on screen in this process, so notifications that only
 * make sense while the user is away (see [LocalTestNotifier]) can be skipped while the app is open.
 *
 * Counts started activities: a rotation stops and starts the same activity in one main-thread turn,
 * so the count never stays at zero for it, and the count reaches zero only when the app leaves the screen.
 */
object AppForegroundTracker {
    private val startedActivities = AtomicInteger(0)

    val isInForeground: Boolean
        get() = startedActivities.get() > 0

    internal fun onActivityStarted() {
        if (startedActivities.incrementAndGet() == 1) {
            AppLockManager.onEnteredForeground()
        }
    }

    internal fun onActivityStopped() {
        if (startedActivities.updateAndGet { count -> if (count > 0) count - 1 else 0 } == 0) {
            AppLockManager.onLeftForeground()
        }
    }

    /** Starts tracking; call once from [Application.onCreate]. */
    fun register(application: Application) {
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) = this@AppForegroundTracker.onActivityStarted()
            override fun onActivityStopped(activity: Activity) = this@AppForegroundTracker.onActivityStopped()
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityResumed(activity: Activity) = Unit
            override fun onActivityPaused(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }

    /** Test hook: forgets all started activities. */
    internal fun resetForTest() {
        startedActivities.set(0)
    }
}
