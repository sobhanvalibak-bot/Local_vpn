package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.enums.NetworkType

/**
 * Reads the `proxies:` list of a Clash / Mihomo YAML profile and turns each supported entry into a regular
 * [ProfileItem]: vless, vmess, trojan, ss (plain or simple-obfs) and hysteria2.
 *
 * Only the proxy list is used; rules, groups and DNS sections are ignored. Entries of other types (tuic,
 * wireguard, anytls, ssr, ...) are skipped. The parser is pure Kotlin (no Android types) so it can be unit tested
 * on the JVM. It understands the YAML subset Clash profiles use: block maps and lists, one-line `{}` / `[]`
 * collections, quoted and plain scalars and `#` comments. Anchors, multi-line flow collections and block
 * scalars are not supported.
 */
object ClashYamlParser {
    private val PROXIES_KEY = Regex("^proxies\\s*:", RegexOption.MULTILINE)

    /** Returns the supported profiles, or null when [text] is not a Clash profile or holds none. */
    fun parse(text: String?): List<ProfileItem>? {
        if (text.isNullOrBlank() || !PROXIES_KEY.containsMatchIn(text)) return null
        val root = runCatching { MiniYaml(text).read() }.getOrNull() as? Map<*, *> ?: return null
        val proxies = root["proxies"] as? List<*> ?: return null
        val profiles = proxies.mapNotNull { (it as? Map<*, *>)?.let(::toProfile) }
        return profiles.ifEmpty { null }
    }

    private fun toProfile(p: Map<*, *>): ProfileItem? {
        val type = str(p["type"])?.lowercase() ?: return null
        val server = str(p["server"]) ?: return null
        val port = str(p["port"])?.toIntOrNull()?.takeIf { it in 1..65535 } ?: return null

        val config = when (type) {
            "vless" -> ProfileItem.create(EConfigType.VLESS).also {
                it.password = str(p["uuid"]) ?: return null
                it.method = str(p["encryption"]) ?: "none"
                it.flow = str(p["flow"])
            }

            "vmess" -> ProfileItem.create(EConfigType.VMESS).also {
                it.password = str(p["uuid"]) ?: return null
                it.method = str(p["cipher"]) ?: AppConfig.DEFAULT_SECURITY
            }

            "trojan" -> ProfileItem.create(EConfigType.TROJAN).also {
                it.password = str(p["password"]) ?: return null
            }

            "ss" -> ProfileItem.create(EConfigType.SHADOWSOCKS).also {
                it.method = str(p["cipher"]) ?: return null
                it.password = str(p["password"]) ?: return null
            }

            "hysteria2", "hy2" -> ProfileItem.create(EConfigType.HYSTERIA2).also {
                it.password = str(p["password"]) ?: return null
            }

            else -> return null
        }

        config.remarks = str(p["name"]) ?: server
        config.server = server
        config.serverPort = port.toString()

        when (config.configType) {
            EConfigType.SHADOWSOCKS -> if (!applyShadowsocksPlugin(config, p)) return null
            EConfigType.HYSTERIA2 -> applyHysteria2(config, p)
            else -> {
                applyTransport(config, p)
                applySecurity(config, p, alwaysTls = config.configType == EConfigType.TROJAN)
            }
        }
        return config
    }

    private fun applyTransport(config: ProfileItem, p: Map<*, *>) {
        when (str(p["network"])?.lowercase()) {
            "ws" -> {
                config.network = NetworkType.WS.type
                val opts = p["ws-opts"] as? Map<*, *>
                config.path = str(opts?.get("path"))
                config.host = headerValue(opts?.get("headers"), "host")
            }

            "grpc" -> {
                config.network = NetworkType.GRPC.type
                config.serviceName = str((p["grpc-opts"] as? Map<*, *>)?.get("grpc-service-name"))
            }

            "h2" -> {
                config.network = NetworkType.H2.type
                val opts = p["h2-opts"] as? Map<*, *>
                config.host = joined(opts?.get("host"))
                config.path = str(opts?.get("path"))
            }

            "http" -> {
                config.network = NetworkType.TCP.type
                config.headerType = "http"
                val opts = p["http-opts"] as? Map<*, *>
                config.path = joined(opts?.get("path"))
                config.host = headerValue(opts?.get("headers"), "host")
            }

            "xhttp" -> {
                config.network = NetworkType.XHTTP.type
                val opts = p["xhttp-opts"] as? Map<*, *>
                config.path = str(opts?.get("path"))
                config.host = str(opts?.get("host"))
                config.xhttpMode = str(opts?.get("mode"))
            }

            else -> config.network = NetworkType.TCP.type
        }
    }

    private fun applySecurity(config: ProfileItem, p: Map<*, *>, alwaysTls: Boolean) {
        val reality = p["reality-opts"] as? Map<*, *>
        val tls = bool(p["tls"]) || alwaysTls
        config.sni = str(p["servername"]) ?: str(p["sni"])
        config.fingerPrint = str(p["client-fingerprint"])
        config.alpn = joined(p["alpn"])
        when {
            reality != null -> {
                config.security = AppConfig.REALITY
                config.publicKey = str(reality["public-key"])
                config.shortId = str(reality["short-id"])
            }

            tls -> {
                config.security = AppConfig.TLS
                config.insecure = bool(p["skip-cert-verify"])
            }

            else -> config.security = null
        }
    }

    private fun applyHysteria2(config: ProfileItem, p: Map<*, *>) {
        config.network = NetworkType.HYSTERIA.type
        config.security = AppConfig.TLS
        config.sni = str(p["sni"]) ?: str(p["servername"])
        config.alpn = joined(p["alpn"])
        config.insecure = bool(p["skip-cert-verify"])
        if (str(p["obfs"])?.lowercase() == "salamander") {
            config.obfsPassword = str(p["obfs-password"])
        }
        config.portHopping = str(p["ports"])
    }

    /** Plain Shadowsocks and simple-obfs (http) are supported; other plugins make the entry unusable. */
    private fun applyShadowsocksPlugin(config: ProfileItem, p: Map<*, *>): Boolean {
        val plugin = str(p["plugin"]) ?: return true
        if (plugin != "obfs") return false
        val opts = p["plugin-opts"] as? Map<*, *>
        if (str(opts?.get("mode"))?.lowercase() != "http") return false
        config.network = NetworkType.TCP.type
        config.headerType = "http"
        config.host = str(opts?.get("host"))
        return true
    }

    private fun str(value: Any?): String? = (value as? String)?.trim()?.takeIf { it.isNotEmpty() }

    private fun bool(value: Any?): Boolean = str(value)?.lowercase() == "true"

    private fun joined(value: Any?): String? = when (value) {
        is List<*> -> value.mapNotNull { str(it) }.joinToString(",").takeIf { it.isNotEmpty() }
        else -> str(value)
    }

    /** Looks a header up by name, ignoring case; a header may hold one value or a list of them. */
    private fun headerValue(headers: Any?, name: String): String? {
        val map = headers as? Map<*, *> ?: return null
        val entry = map.entries.firstOrNull { (it.key as? String)?.equals(name, ignoreCase = true) == true }
        return joined(entry?.value)
    }

    private class Line(val indent: Int, val text: String)

    /** The small YAML subset Clash profiles use; scalars are always returned as strings. */
    private class MiniYaml(source: String) {
        private val lines: MutableList<Line> = source.lineSequence()
            .map { stripComment(it).trimEnd() }
            .filter { it.isNotBlank() && it.trim() != "---" }
            .map { Line(it.length - it.trimStart().length, it.trim()) }
            .toMutableList()
        private var pos = 0

        fun read(): Any? = if (lines.isEmpty()) null else readBlock(lines[0].indent)

        private fun readBlock(indent: Int): Any? {
            if (pos >= lines.size) return null
            return if (isListItem(lines[pos].text)) readList(indent) else readMap(indent)
        }

        private fun readList(indent: Int): List<Any?> {
            val out = mutableListOf<Any?>()
            while (pos < lines.size && lines[pos].indent == indent && isListItem(lines[pos].text)) {
                val text = lines[pos].text
                val rest = text.removePrefix("-").trim()
                when {
                    rest.isEmpty() -> {
                        pos++
                        out += if (pos < lines.size && lines[pos].indent > indent) readBlock(lines[pos].indent) else null
                    }

                    isListItem(rest) -> pos++
                    rest.startsWith("{") || rest.startsWith("[") -> {
                        pos++
                        out += FlowReader(rest).read()
                    }

                    findKeyColon(rest) >= 0 -> {
                        // "- key: value" opens a map whose other keys line up with this first key.
                        val keyIndent = indent + (text.length - rest.length)
                        lines[pos] = Line(keyIndent, rest)
                        out += readMap(keyIndent)
                    }

                    else -> {
                        pos++
                        out += unquote(rest)
                    }
                }
            }
            return out
        }

        private fun readMap(indent: Int): Map<String, Any?> {
            val out = linkedMapOf<String, Any?>()
            while (pos < lines.size && lines[pos].indent == indent && !isListItem(lines[pos].text)) {
                val text = lines[pos].text
                val colon = findKeyColon(text)
                pos++
                if (colon < 0) continue
                val key = unquote(text.substring(0, colon).trim())
                val rest = text.substring(colon + 1).trim()
                out[key] = when {
                    rest.isEmpty() -> when {
                        pos < lines.size && lines[pos].indent > indent -> readBlock(lines[pos].indent)
                        pos < lines.size && lines[pos].indent == indent && isListItem(lines[pos].text) -> readList(indent)
                        else -> null
                    }

                    rest.startsWith("{") || rest.startsWith("[") -> FlowReader(rest).read()
                    else -> unquote(rest)
                }
            }
            return out
        }

        private fun isListItem(text: String) = text == "-" || text.startsWith("- ")

        /** Index of the `:` that ends a key (outside quotes, followed by a space or the line end), or -1. */
        private fun findKeyColon(text: String): Int {
            var quote = '\u0000'
            for (i in text.indices) {
                val c = text[i]
                when {
                    quote != '\u0000' -> if (c == quote) quote = '\u0000'
                    (c == '"' || c == '\'') && (i == 0 || text[i - 1] == ' ') -> quote = c
                    c == ':' && (i == text.length - 1 || text[i + 1] == ' ') -> return i
                }
            }
            return -1
        }

        private fun stripComment(line: String): String {
            var quote = '\u0000'
            for (i in line.indices) {
                val c = line[i]
                when {
                    quote != '\u0000' -> if (c == quote) quote = '\u0000'
                    (c == '"' || c == '\'') && (i == 0 || line[i - 1] == ' ' || line[i - 1] == '{' || line[i - 1] == '[' || line[i - 1] == ',') -> quote = c
                    c == '#' && (i == 0 || line[i - 1] == ' ' || line[i - 1] == '\t') -> return line.substring(0, i)
                }
            }
            return line
        }
    }

    /** Reads a one-line `{...}` or `[...]` collection. */
    private class FlowReader(private val s: String) {
        private var i = 0

        fun read(): Any? = value()

        private fun value(): Any? {
            skipSpaces()
            if (i >= s.length) return null
            return when (s[i]) {
                '{' -> map()
                '[' -> list()
                '"', '\'' -> quoted()
                else -> plain()
            }
        }

        private fun map(): Map<String, Any?> {
            val out = linkedMapOf<String, Any?>()
            i++
            while (true) {
                skipSpaces()
                if (i >= s.length) break
                if (s[i] == '}') {
                    i++
                    break
                }
                if (s[i] == ',') {
                    i++
                    continue
                }
                val key = key()
                skipSpaces()
                if (i < s.length && s[i] == ':') i++
                out[key] = value()
            }
            return out
        }

        private fun list(): List<Any?> {
            val out = mutableListOf<Any?>()
            i++
            while (true) {
                skipSpaces()
                if (i >= s.length) break
                if (s[i] == ']') {
                    i++
                    break
                }
                if (s[i] == ',' || s[i] == '}') {
                    i++
                    continue
                }
                out += value()
            }
            return out
        }

        private fun key(): String {
            if (i < s.length && (s[i] == '"' || s[i] == '\'')) return quoted()
            val start = i
            while (i < s.length && s[i] != ':' && s[i] != ',' && s[i] != '}') i++
            return s.substring(start, i).trim()
        }

        private fun plain(): String {
            val start = i
            while (i < s.length && s[i] != ',' && s[i] != '}' && s[i] != ']') i++
            return s.substring(start, i).trim()
        }

        private fun quoted(): String {
            val quote = s[i++]
            val out = StringBuilder()
            while (i < s.length) {
                val c = s[i++]
                when {
                    c == quote && quote == '\'' && i < s.length && s[i] == '\'' -> {
                        out.append('\'')
                        i++
                    }

                    c == quote -> return out.toString()
                    c == '\\' && quote == '"' && i < s.length -> out.append(s[i++])
                    else -> out.append(c)
                }
            }
            return out.toString()
        }

        private fun skipSpaces() {
            while (i < s.length && s[i].isWhitespace()) i++
        }
    }

    private fun unquote(raw: String): String {
        if (raw.length >= 2) {
            val first = raw.first()
            if ((first == '"' || first == '\'') && raw.last() == first) {
                val inner = raw.substring(1, raw.length - 1)
                return if (first == '\'') inner.replace("''", "'") else inner.replace("\\\"", "\"").replace("\\\\", "\\")
            }
        }
        return raw
    }
}
