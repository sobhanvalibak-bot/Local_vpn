package com.v2ray.ang.ui.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R

/**
 * Controls shown at the top of the "Local test" tab. Holds only the uncommitted address input;
 * every operation goes through [MainAction] to [MainViewModel].
 */
@Composable
fun LocalTestPanel(
    state: LocalTestUiState,
    onAction: (MainAction) -> Unit,
) {
    var address by rememberSaveable { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = stringResource(R.string.local_test_share_title),
                style = MaterialTheme.typography.titleSmall,
            )
            if (state.serverRunning) {
                Text(
                    text = stringResource(R.string.local_test_server_on, state.serverAddress),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            OutlinedButton(
                onClick = { onAction(MainAction.LocalTestToggleServer) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    stringResource(
                        if (state.serverRunning) R.string.local_test_stop_server
                        else R.string.local_test_start_server
                    )
                )
            }

            Text(
                text = stringResource(R.string.local_test_fetch_title),
                style = MaterialTheme.typography.titleSmall,
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(stringResource(R.string.local_test_address_hint)) },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onAction(MainAction.LocalTestFetch(address)) },
                    enabled = !state.busy && address.isNotBlank(),
                ) {
                    Text(stringResource(R.string.local_test_fetch_and_test))
                }
                OutlinedButton(
                    onClick = { onAction(MainAction.LocalTestMoveGreenToMain) },
                    enabled = !state.busy,
                ) {
                    Text(stringResource(R.string.local_test_move_to_main))
                }
            }
        }
    }
}
