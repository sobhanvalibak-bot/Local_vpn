package com.v2ray.ang.ui.telegramproxy

import com.v2ray.ang.handler.TelegramProxyManager.TelegramProxy

sealed interface PingStatus {
    data object Testing : PingStatus
    data class Done(val millis: Long) : PingStatus
    data object Failed : PingStatus
}

data class TelegramProxyRow(
    val proxy: TelegramProxy,
    val status: PingStatus,
)

data class TelegramProxyUiState(
    val input: String = "",
    val rows: List<TelegramProxyRow> = emptyList(),
    /** True once a test run has been requested, so "no proxy found" is not shown before that. */
    val hasTested: Boolean = false,
    val isTesting: Boolean = false,
)

sealed interface TelegramProxyAction {
    data class SetInput(val text: String) : TelegramProxyAction
    /** Parse [text] (or the current input when null) and ping every proxy found. */
    data class Test(val text: String? = null) : TelegramProxyAction
    data object PasteAndTest : TelegramProxyAction
}
