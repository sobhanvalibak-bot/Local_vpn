package com.v2ray.ang.ui.compose

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.AppLockManager

/**
 * Shows [content] only while the app lock is off or has been passed. The protected screen is removed from
 * composition while locked, so nothing behind the lock screen can be read or focused.
 */
@Composable
fun AppLockGate(content: @Composable () -> Unit) {
    val enabled by AppLockManager.enabled.collectAsState()
    val unlocked by AppLockManager.unlocked.collectAsState()
    if (!enabled || unlocked) {
        content()
    } else {
        AppLockScreen()
    }
}

@Composable
private fun AppLockScreen() {
    val context = LocalContext.current
    val title = stringResource(R.string.app_lock_prompt_title)
    val description = stringResource(R.string.app_lock_prompt_description)
    var prompted by rememberSaveable { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) AppLockManager.markUnlocked()
    }
    val requestUnlock = {
        val intent = AppLockManager.createCredentialIntent(context, title, description)
        if (intent == null) {
            // The device has no screen lock any more, so there is nothing to ask for.
            AppLockManager.markUnlocked()
        } else {
            launcher.launch(intent)
        }
    }
    LaunchedEffect(Unit) {
        if (!prompted) {
            prompted = true
            requestUnlock()
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(R.string.app_lock_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { requestUnlock() }) {
            Text(stringResource(R.string.app_lock_unlock))
        }
    }
}
