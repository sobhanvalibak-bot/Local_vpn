package com.v2ray.ang.handler

import android.content.Context
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.CoreServiceManager
import com.v2ray.ang.dto.OutboundTrafficStat
import com.v2ray.ang.dto.TrafficSpeed
import com.v2ray.ang.helper.MessageHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Bytes moved through the proxy and direct outbounds during one sampling window.
 * Core counters are reset by every query, so this is a delta, not a running total.
 */
data class TrafficWindow(
    val proxyUplink: Long = 0L,
    val proxyDownlink: Long = 0L,
    val directUplink: Long = 0L,
    val directDownlink: Long = 0L,
    val elapsedMs: Long = 0L,
) {
    operator fun plus(other: TrafficWindow) = TrafficWindow(
        proxyUplink + other.proxyUplink,
        proxyDownlink + other.proxyDownlink,
        directUplink + other.directUplink,
        directDownlink + other.directDownlink,
        elapsedMs + other.elapsedMs,
    )
}

/**
 * Only caller of the core's reset-on-read traffic counters, running in the daemon process.
 *
 * Two consumers read it: the speed notification (every few seconds, via [drainNotificationWindow])
 * and the Home screen (every second, via [MessageHelper] broadcasts while the UI subscribed).
 * A second reader of the counters would steal bytes from the first, which is why both go through
 * this object. It samples only while somebody needs the numbers and the screen is on.
 */
object TrafficSampler {
    private const val SAMPLE_INTERVAL_MS = 1000L

    private val lock = Any()
    private var scope: CoroutineScope? = null
    private var job: Job? = null

    @Volatile
    private var uiSubscribed = false

    @Volatile
    private var screenOn = true

    private var notificationWindow = TrafficWindow()

    /** Starts sampling for the core that just started. Safe to call twice. */
    fun start(context: Context) {
        synchronized(lock) {
            if (job?.isActive == true) return
            notificationWindow = TrafficWindow()
            val newScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            scope = newScope
            job = newScope.launch { sampleLoop(context.applicationContext) }
        }
    }

    /** Stops sampling and drops pending counters. Safe to call twice. */
    fun stop() {
        synchronized(lock) {
            scope?.cancel()
            scope = null
            job = null
            notificationWindow = TrafficWindow()
        }
        uiSubscribed = false
    }

    fun setUiSubscribed(subscribed: Boolean) {
        uiSubscribed = subscribed
    }

    fun setScreenOn(on: Boolean) {
        screenOn = on
    }

    /** Returns what accumulated since the previous call and starts a new window. */
    fun drainNotificationWindow(): TrafficWindow = synchronized(lock) {
        val drained = notificationWindow
        notificationWindow = TrafficWindow()
        drained
    }

    private suspend fun sampleLoop(context: Context) {
        var primed = false
        var lastSampleMs = 0L
        while (currentCoroutineContext().isActive) {
            delay(SAMPLE_INTERVAL_MS)
            val needed = screenOn && (uiSubscribed || notificationWanted())
            if (!needed) {
                // Counters keep growing while nobody reads them; the next read starts from a clean baseline.
                primed = false
                continue
            }
            val stats = CoreServiceManager.queryAllOutboundTrafficStats()
            val now = System.currentTimeMillis()
            if (!primed) {
                primed = true
                lastSampleMs = now
                continue
            }
            val window = summarize(stats, now - lastSampleMs)
            lastSampleMs = now
            synchronized(lock) { notificationWindow += window }
            if (uiSubscribed) {
                MessageHelper.sendMsg2UI(context, AppConfig.MSG_SPEED_UPDATE, speedOf(window))
            }
        }
    }

    private fun notificationWanted() = MmkvManager.decodeSettingsBool(AppConfig.PREF_SPEED_ENABLED) == true

    /** Sums the proxy outbounds (every tag except direct and blocked) and the direct outbound. */
    internal fun summarize(stats: List<OutboundTrafficStat>, elapsedMs: Long): TrafficWindow {
        var proxyUp = 0L
        var proxyDown = 0L
        var directUp = 0L
        var directDown = 0L
        stats.forEach { stat ->
            when {
                stat.tag == AppConfig.TAG_DIRECT -> when (stat.direction) {
                    AppConfig.UPLINK -> directUp += stat.value
                    AppConfig.DOWNLINK -> directDown += stat.value
                }

                stat.tag != AppConfig.TAG_BLOCKED -> when (stat.direction) {
                    AppConfig.UPLINK -> proxyUp += stat.value
                    AppConfig.DOWNLINK -> proxyDown += stat.value
                }
            }
        }
        return TrafficWindow(proxyUp, proxyDown, directUp, directDown, elapsedMs)
    }

    internal fun speedOf(window: TrafficWindow): TrafficSpeed {
        if (window.elapsedMs <= 0L) return TrafficSpeed()
        val seconds = window.elapsedMs / 1000.0
        return TrafficSpeed(
            downlinkBytesPerSec = (window.proxyDownlink / seconds).toLong(),
            uplinkBytesPerSec = (window.proxyUplink / seconds).toLong(),
        )
    }
}
