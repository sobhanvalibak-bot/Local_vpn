package com.v2ray.ang.handler

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.enums.EConfigType
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Reads NapsternetV-style `.npvs` and `.npvt` files and turns each entry into a regular [ProfileItem].
 *
 * - `.npvs`: a JSON document `{"configs":[{"name":..., "v2rayProfile":{...}}]}`, optionally preceded by an
 *   `NPV...` header line. Profile values prefixed with `npvs1:` are Base64 encoded.
 * - `.npvt`: one entry per line, `<base64 name>,<base64 JSON profile>`, optionally preceded by an `NPVT` header.
 *
 * Only these plain formats are read. Encrypted/locked variants are not recognised and yield `null`.
 * The parser is pure Kotlin (no Android types) so it can be unit tested on the JVM.
 */
object NpvFileParser {
    const val SOURCE_NPVS = "NPVS"
    const val SOURCE_NPVT = "NPVT"

    private const val FIELD_PREFIX = "npvs1:"
    private val SUPPORTED_EXTENSIONS = setOf("npvs", "npvt")
    private val NPVT_LINE = Regex("^[A-Za-z0-9+/=_-]+,[A-Za-z0-9+/=_-]+$")

    /** NapsternetV `configType` ids mapped to the protocols this app can connect with. */
    private val TYPE_BY_NPV_ID = mapOf(
        1 to EConfigType.VMESS,
        3 to EConfigType.SHADOWSOCKS,
        4 to EConfigType.SOCKS,
        5 to EConfigType.VLESS,
        6 to EConfigType.TROJAN,
        7 to EConfigType.HYSTERIA2,
        9 to EConfigType.WIREGUARD,
        10 to EConfigType.HTTP,
    )

    /** True when [fileName] ends with `.npvs` or `.npvt` (case-insensitive). */
    fun hasSupportedExtension(fileName: String?): Boolean {
        val extension = fileName?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return extension in SUPPORTED_EXTENSIONS
    }

    /**
     * Parses [text] as an `.npvs` or `.npvt` file.
     *
     * @return the usable profiles (never empty), or `null` when [text] is not a readable NPV file
     * or contains no protocol this app supports.
     */
    fun parse(text: String?): List<ProfileItem>? {
        if (text.isNullOrBlank()) return null
        val body = text.trimStart('﻿').trim()
        val profiles = parseNpvs(body)?.let { entries -> toProfiles(entries, SOURCE_NPVS) }
            ?: parseNpvt(body)?.let { entries -> toProfiles(entries, SOURCE_NPVT) }
        return profiles?.takeIf { it.isNotEmpty() }
    }

    private class Entry(val name: String, val profile: JsonObject)

    private fun parseNpvs(body: String): List<Entry>? {
        val start = body.indexOf('{')
        if (start < 0) return null
        // Anything before the JSON must be the NPV header line, otherwise this is some other text.
        val header = body.substring(0, start).trim()
        if (header.isNotEmpty() && !header.startsWith("NPV", ignoreCase = true)) return null
        val root = try {
            JsonParser.parseString(body.substring(start)).takeIf { it.isJsonObject }?.asJsonObject
        } catch (e: Exception) {
            null
        } ?: return null
        val configs = root.get("configs")?.takeIf { it.isJsonArray }?.asJsonArray ?: return null
        return configs.mapNotNull { element ->
            val item = element.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val profile = item.get("v2rayProfile")?.takeIf { it.isJsonObject }?.asJsonObject
                ?: return@mapNotNull null
            Entry(item.get("name")?.takeIf { it.isJsonPrimitive }?.asString.orEmpty(), profile)
        }
    }

    private fun parseNpvt(body: String): List<Entry>? {
        val entries = body.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("NPVT", ignoreCase = true) }
            .filter { NPVT_LINE.matches(it) }
            .mapNotNull { line ->
                val name = decodeBase64(line.substringBefore(','))?.trim().orEmpty()
                val json = decodeBase64(line.substringAfter(','))?.trim() ?: return@mapNotNull null
                val profile = try {
                    JsonParser.parseString(json).takeIf { it.isJsonObject }?.asJsonObject
                } catch (e: Exception) {
                    null
                } ?: return@mapNotNull null
                Entry(name, profile)
            }
            .toList()
        return entries.takeIf { it.isNotEmpty() }
    }

    private fun toProfiles(entries: List<Entry>, source: String): List<ProfileItem> =
        entries.mapNotNull { toProfile(it, source) }

    private fun toProfile(entry: Entry, source: String): ProfileItem? {
        val fields = HashMap<String, String>()
        entry.profile.entrySet().forEach { (key, value) ->
            if (value.isJsonPrimitive) fields[key] = decodeField(value.asString)
        }

        val type = fields["configType"]?.toIntOrNull()?.let { TYPE_BY_NPV_ID[it] } ?: return null
        val server = fields["server"]?.takeIf { it.isNotBlank() } ?: return null
        val port = fields["serverPort"]?.takeIf { it.isNotBlank() } ?: return null

        val profile = ProfileItem.create(type)
        profile.npvSource = source
        profile.server = server
        profile.serverPort = port
        profile.remarks = entry.name.ifBlank { fields["remarks"].orEmpty().ifBlank { server } }
        profile.password = fields["password"] ?: fields["id"] ?: fields["uuid"]
        profile.username = fields["username"]
        profile.flow = fields["flow"]
        profile.network = fields["network"]
        profile.headerType = fields["headerType"]
        profile.host = fields["host"]
        profile.path = fields["path"]
        profile.serviceName = fields["serviceName"]
        profile.mode = fields["mode"]
        profile.sni = fields["sni"]
        profile.alpn = fields["alpn"]
        profile.fingerPrint = fields["fingerPrint"]
        profile.publicKey = fields["publicKey"]
        profile.shortId = fields["shortId"]
        profile.spiderX = fields["spiderX"]
        profile.obfsPassword = fields["obfsPassword"]
        profile.pinnedCA256 = fields["pinnedCA256"] ?: fields["pinSHA256"]
        profile.secretKey = fields["secretKey"]
        profile.preSharedKey = fields["preSharedKey"]
        profile.localAddress = fields["localAddress"]
        profile.reserved = fields["reserved"]
        profile.mtu = fields["mtu"]?.toIntOrNull()
        profile.insecure = listOf("insecure", "allowInsecure", "tlsAllowInsecure")
            .firstNotNullOfOrNull { fields[it]?.toBooleanStrictOrNull() }

        val security = fields["security"].orEmpty()
        when (type) {
            // For VMess the cipher and the transport security are separate fields in this app.
            EConfigType.VMESS -> {
                if (security.isEmpty() || security.lowercase() in TRANSPORT_SECURITIES) {
                    profile.security = security.ifEmpty { null }
                    profile.method = AppConfig.DEFAULT_SECURITY
                } else {
                    profile.method = security
                    profile.security = fields["tls"]?.takeIf { it.equals("tls", ignoreCase = true) }
                }
            }

            EConfigType.SHADOWSOCKS -> profile.method = fields["method"]
            else -> profile.security = security.ifEmpty { null }
        }
        if (profile.network.isNullOrBlank() && type in NETWORK_TYPES) profile.network = "tcp"
        return profile
    }

    private val TRANSPORT_SECURITIES = setOf("tls", "reality", "none")
    private val NETWORK_TYPES = setOf(EConfigType.VMESS, EConfigType.VLESS, EConfigType.TROJAN)

    private fun decodeField(value: String): String =
        if (value.startsWith(FIELD_PREFIX)) decodeBase64(value.removePrefix(FIELD_PREFIX)) ?: value else value

    @OptIn(ExperimentalEncodingApi::class)
    private fun decodeBase64(value: String): String? = try {
        val normalized = value.trim().replace('-', '+').replace('_', '/')
        Base64.Default.withPadding(Base64.PaddingOption.PRESENT_OPTIONAL)
            .decode(normalized)
            .toString(Charsets.UTF_8)
    } catch (e: IllegalArgumentException) {
        null
    }
}
