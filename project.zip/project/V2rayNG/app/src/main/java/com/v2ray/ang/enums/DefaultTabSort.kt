package com.v2ray.ang.enums

/** How the Default tab orders its configs. [TIME] keeps the stored order (the order they were added in). */
enum class DefaultTabSort(val storageValue: String) {
    DOWNLOAD("download"),
    PING("ping"),
    TIME("time");

    companion object {
        /** Unknown or missing stored values fall back to [TIME], the order that existed before this setting. */
        fun fromStorage(value: String?): DefaultTabSort =
            entries.firstOrNull { it.storageValue == value } ?: TIME
    }
}
