package com.v2ray.ang.ui.compose

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Shared backdrop for "liquid glass" surfaces (iOS 26 style).
 *
 * The content that should show through the glass is marked with [liquidGlassSource]; every
 * [liquidGlass] surface then draws a blurred copy of that content behind itself. The glass
 * surfaces must be drawn after (z-above) the source and must not be part of it.
 */
@Stable
class LiquidGlassState internal constructor(internal val layer: GraphicsLayer) {
    internal var sourceOrigin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberLiquidGlassState(): LiquidGlassState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { LiquidGlassState(layer) }
}

/** Marks the content that glass surfaces blur. Place it before the content's own background. */
fun Modifier.liquidGlassSource(state: LiquidGlassState): Modifier = this
    .onGloballyPositioned { state.sourceOrigin = it.positionInRoot() }
    .drawWithContent {
        state.layer.record { this@drawWithContent.drawContent() }
        drawLayer(state.layer)
    }

private val GlassBlurSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

/** Default glass tint: frosted white in light theme, smoked gray in dark theme. */
@Composable
fun liquidGlassTint(): Color =
    if (LocalDarkTheme.current) Color(0xFF3A3A3E).copy(alpha = 0.45f) else Color.White.copy(alpha = 0.42f)

/**
 * Draws a liquid-glass surface (pill or circle; [shape] must be fully rounded, e.g. CircleShape): soft shadow, blurred backdrop, tint and a light rim.
 * Below Android 12 there is no backdrop blur, so the tint becomes nearly opaque to stay legible.
 */
@Composable
fun Modifier.liquidGlass(
    state: LiquidGlassState,
    shape: Shape,
    tint: Color = liquidGlassTint(),
    blurRadius: Dp = 24.dp,
): Modifier {
    val blurLayer = rememberGraphicsLayer()
    var origin by remember { mutableStateOf(Offset.Zero) }
    val dark = LocalDarkTheme.current
    val blurPx = with(LocalDensity.current) { blurRadius.toPx() }
    val fill = if (GlassBlurSupported) tint else tint.copy(alpha = maxOf(tint.alpha, 0.92f))
    val rim = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = if (dark) 0.35f else 0.85f),
            Color.White.copy(alpha = if (dark) 0.08f else 0.30f),
        )
    )

    return this
        .shadow(
            elevation = 12.dp,
            shape = shape,
            ambientColor = Color.Black.copy(alpha = 0.2f),
            spotColor = Color.Black.copy(alpha = 0.3f),
        )
        .onGloballyPositioned { origin = it.positionInRoot() }
        .drawWithContent {
            // All glass surfaces are pills or circles, so draw them as fully rounded rectangles.
            val radius = CornerRadius(size.minDimension / 2f)
            if (GlassBlurSupported) {
                blurLayer.renderEffect = BlurEffect(blurPx, blurPx, TileMode.Clamp)
                blurLayer.record {
                    translate(state.sourceOrigin.x - origin.x, state.sourceOrigin.y - origin.y) {
                        drawLayer(state.layer)
                    }
                }
                drawLayer(blurLayer)
            }
            drawRoundRect(color = fill, cornerRadius = radius)
            drawRoundRect(brush = rim, cornerRadius = radius, style = Stroke(width = 1.dp.toPx()))
            drawContent()
        }
}
