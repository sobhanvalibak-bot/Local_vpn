package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.util.LogUtil
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Tiny HTTP server for the "Local test" tab. Anyone on the same LAN can:
 *  - GET  /          a simple web page to paste configs from a browser
 *  - GET  /configs   plain text, one share link per line
 *  - POST /configs   plain text body, one share link per line
 *
 * Only private/loopback clients are served. Request size and link count are capped.
 * Exposed as a standalone class (no Android types) so it can be unit tested on the JVM.
 */
class LocalShareServer(
    private val onConfigsReceived: (List<String>) -> Unit,
) {
    @Volatile
    private var serverSocket: ServerSocket? = null
    private var executor: ExecutorService? = null
    private val links = LinkedHashSet<String>()

    val isRunning: Boolean get() = serverSocket?.isClosed == false
    val port: Int get() = serverSocket?.localPort ?: -1

    @Synchronized
    fun start(requestedPort: Int): Boolean {
        if (isRunning) return true
        return try {
            val socket = ServerSocket()
            socket.reuseAddress = true
            socket.bind(InetSocketAddress(requestedPort))
            serverSocket = socket
            val pool = Executors.newCachedThreadPool()
            executor = pool
            pool.execute { acceptLoop(socket, pool) }
            true
        } catch (e: IOException) {
            LogUtil.e(AppConfig.TAG, "LocalShareServer: failed to start on port $requestedPort", e)
            stop()
            false
        }
    }

    @Synchronized
    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        executor?.shutdownNow()
        executor = null
    }

    /** Links currently shared by this server (also what GET /configs returns). */
    @Synchronized
    fun snapshot(): List<String> = links.toList()

    @Synchronized
    fun clear() = links.clear()

    @Synchronized
    private fun remember(newLinks: List<String>): List<String> =
        newLinks.filter { links.size < MAX_LINKS && links.add(it) }

    private fun acceptLoop(socket: ServerSocket, pool: ExecutorService) {
        while (!socket.isClosed) {
            try {
                val client = socket.accept()
                pool.execute { handle(client) }
            } catch (e: IOException) {
                if (!socket.isClosed) LogUtil.e(AppConfig.TAG, "LocalShareServer: accept failed", e)
            } catch (_: java.util.concurrent.RejectedExecutionException) {
                return
            }
        }
    }

    private fun handle(client: Socket) {
        client.use { s ->
            try {
                s.soTimeout = SOCKET_TIMEOUT_MS
                if (!isLocalClient(s.inetAddress)) {
                    respond(s, 403, "text/plain", "Forbidden")
                    return
                }
                val input = BufferedInputStream(s.getInputStream())
                val requestLine = readLine(input) ?: return
                val parts = requestLine.split(' ')
                if (parts.size < 2) {
                    respond(s, 400, "text/plain", "Bad request")
                    return
                }
                val method = parts[0]
                val path = parts[1].substringBefore('?')

                var contentLength = 0
                while (true) {
                    val header = readLine(input) ?: return
                    if (header.isEmpty()) break
                    if (header.startsWith("content-length:", ignoreCase = true)) {
                        contentLength = header.substringAfter(':').trim().toIntOrNull() ?: -1
                    }
                }

                when {
                    method == "GET" && path == "/" ->
                        respond(s, 200, "text/html; charset=utf-8", PAGE_HTML)

                    method == "GET" && path == "/configs" ->
                        respond(s, 200, "text/plain; charset=utf-8", snapshot().joinToString("\n"))

                    method == "POST" && path == "/configs" -> {
                        if (contentLength < 0 || contentLength > MAX_BODY_BYTES) {
                            respond(s, 413, "text/plain", "Too large")
                            return
                        }
                        val body = readBody(input, contentLength)
                        val accepted = remember(parseLinks(body))
                        if (accepted.isNotEmpty()) onConfigsReceived(accepted)
                        respond(s, 200, "text/plain; charset=utf-8", accepted.size.toString())
                    }

                    else -> respond(s, 404, "text/plain", "Not found")
                }
            } catch (e: IOException) {
                LogUtil.e(AppConfig.TAG, "LocalShareServer: request failed", e)
            }
        }
    }

    private fun readLine(input: BufferedInputStream): String? {
        val buffer = ByteArrayOutputStream()
        while (buffer.size() < MAX_LINE_BYTES) {
            val b = input.read()
            if (b < 0) return if (buffer.size() == 0) null else buffer.toString(Charsets.ISO_8859_1.name())
            if (b == '\n'.code) break
            if (b != '\r'.code) buffer.write(b)
        }
        return buffer.toString(Charsets.ISO_8859_1.name())
    }

    private fun readBody(input: BufferedInputStream, length: Int): String {
        val bytes = ByteArray(length)
        var read = 0
        while (read < length) {
            val n = input.read(bytes, read, length - read)
            if (n < 0) break
            read += n
        }
        return String(bytes, 0, read, Charsets.UTF_8)
    }

    private fun respond(socket: Socket, status: Int, contentType: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val reason = when (status) {
            200 -> "OK"
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            413 -> "Payload Too Large"
            else -> "Error"
        }
        val head = "HTTP/1.1 $status $reason\r\n" +
            "Content-Type: $contentType\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        val out = socket.getOutputStream()
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        out.write(bytes)
        out.flush()
    }

    companion object {
        const val DEFAULT_PORT = 8765
        private const val MAX_BODY_BYTES = 512 * 1024
        private const val MAX_LINE_BYTES = 16 * 1024
        private const val MAX_LINKS = 1000
        private const val MAX_LINK_LENGTH = 8192
        private const val SOCKET_TIMEOUT_MS = 10_000

        private val LINK_REGEX = Regex("^[a-zA-Z][a-zA-Z0-9+.-]{1,15}://\\S+$")

        /** Keeps only plausible share links (scheme://...), trimmed and de-duplicated. */
        fun parseLinks(text: String): List<String> =
            text.lineSequence()
                .map { it.trim() }
                .filter { it.length <= MAX_LINK_LENGTH && LINK_REGEX.matches(it) }
                .distinct()
                .toList()

        /** Only LAN peers are allowed: RFC1918 / link-local / loopback addresses. */
        fun isLocalClient(address: InetAddress): Boolean =
            address.isSiteLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress

        private val PAGE_HTML = """
            <!doctype html><html><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>Local test</title>
            <style>body{font-family:sans-serif;max-width:640px;margin:24px auto;padding:0 12px}
            textarea{width:100%;height:240px;box-sizing:border-box}
            button{padding:10px 18px;margin-top:8px}</style></head><body>
            <h3>Local test</h3>
            <p>Paste share links (vmess://, vless://, trojan://, ss:// ...), one per line.</p>
            <textarea id="t" dir="ltr"></textarea><br>
            <button onclick="send()">Send</button> <span id="r"></span>
            <script>
            function send(){fetch('/configs',{method:'POST',body:document.getElementById('t').value})
            .then(function(x){return x.text()}).then(function(n){document.getElementById('r').textContent='OK: '+n})
            .catch(function(){document.getElementById('r').textContent='Error'})}
            </script></body></html>
        """.trimIndent()
    }
}
