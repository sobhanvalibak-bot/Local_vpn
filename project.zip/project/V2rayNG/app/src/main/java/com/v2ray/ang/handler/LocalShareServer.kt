package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.google.gson.Gson
import com.v2ray.ang.util.LogUtil
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * A message between two devices: [kind] is "text", "image" (base64 JPEG in [image]), "config" (share links in [text]),
 * "profile" (display name in [text], base64 JPEG avatar in [image]), "file" or "banner" (a [FileRef] as JSON in [text]).
 * "profile" and "banner" are exchanged silently; they never appear in the chat.
 */
data class ChatPayload(val kind: String = "text", val text: String = "", val image: String? = null)

/** A file held by the server: [id] is what a device asks for with GET /file/<id>. */
data class FileRef(val id: String = "", val name: String = "", val size: Long = 0L, val mime: String = "")

/** A message the server holds for one client until that client polls for it. */
data class OutboxMessage(val id: Long, val kind: String, val text: String, val image: String?)

/**
 * Tiny HTTP server for the "Local test" tab. Anyone on the same LAN can:
 *  - GET  /          a simple web page to paste configs from a browser
 *  - GET  /configs   plain text, one share link per line
 *  - POST /configs   plain text body, one share link per line
 *  - POST /msg       JSON chat message from a client
 *  - POST /file      streams a file (up to 25 MB, ?name=&mime=) into the server's file store; answers with its FileRef as JSON
 *  - GET  /file/<id> streams a stored file back
 *  - GET  /poll      JSON array of the messages the server sent to the calling client (?since=lastId)
 *
 * Only private/loopback clients are served. Request size and link count are capped.
 * Exposed as a standalone class (no Android types) so it can be unit tested on the JVM.
 */
class LocalShareServer(
    /** Links of the server owner's own configs, read fresh on every GET so new ones appear automatically. */
    private val ownerLinks: () -> List<String> = { emptyList() },
    private val onConfigsReceived: (List<String>) -> Unit,
    /** Called with the IP of a LAN device each time it talks to the server (the caller throttles repeats). */
    private val onClientSeen: (String) -> Unit = {},
    /** A client sent a chat message: its IP and the message. */
    private val onChatMessage: (String, ChatPayload) -> Unit = { _, _ -> },
    /** Where files sent to or through this server are kept; null turns file transfer off. */
    private val fileDir: java.io.File? = null,
) {
    @Volatile
    private var serverSocket: ServerSocket? = null
    private var executor: ExecutorService? = null
    private val links = LinkedHashSet<String>()
    private val lastSeen = ConcurrentHashMap<String, Long>()
    private val outbox = HashMap<String, ArrayList<OutboxMessage>>()
    private var outboxCounter = 0L

    val isRunning: Boolean get() = serverSocket?.isClosed == false
    val port: Int get() = serverSocket?.localPort ?: -1

    @Synchronized
    fun start(requestedPort: Int): Boolean {
        if (isRunning) return true
        return try {
            val socket = ServerSocket()
            socket.reuseAddress = true
            socket.bind(InetSocketAddress(requestedPort))
            serverSocket = socket
            val pool = Executors.newCachedThreadPool()
            executor = pool
            pool.execute { acceptLoop(socket, pool) }
            true
        } catch (e: IOException) {
            LogUtil.e(AppConfig.TAG, "LocalShareServer: failed to start on port $requestedPort", e)
            stop()
            false
        }
    }

    // ---------- File store ----------
    private val storedFiles = LinkedHashMap<String, Pair<FileRef, java.io.File>>()

    /** Copies [source] into the store so devices can fetch it; null when file transfer is off or the file is empty or too big. */
    fun registerFile(source: java.io.File, name: String, mime: String): FileRef? {
        val dir = fileDir ?: return null
        val size = source.length()
        if (size !in 1..LocalProfileRules.MAX_FILE_BYTES) return null
        val id = java.util.UUID.randomUUID().toString().replace("-", "")
        val target = java.io.File(dir.apply { mkdirs() }, id)
        source.inputStream().use { input -> target.outputStream().use { input.copyTo(it) } }
        return addToStore(FileRef(id, LocalProfileRules.sanitizeFileName(name), size, mime), target)
    }

    /** The stored file for [id], or null when unknown. */
    fun storedFile(id: String): java.io.File? = synchronized(storedFiles) { storedFiles[id]?.second }

    private fun addToStore(ref: FileRef, file: java.io.File): FileRef = synchronized(storedFiles) {
        storedFiles[ref.id] = ref to file
        // Keep the store bounded: oldest files go first.
        var total = storedFiles.values.sumOf { it.first.size }
        val iterator = storedFiles.entries.iterator()
        while (iterator.hasNext() && (total > MAX_STORE_BYTES || storedFiles.size > MAX_STORED_FILES)) {
            val oldest = iterator.next()
            if (oldest.key == ref.id) break
            total -= oldest.value.first.size
            oldest.value.second.delete()
            iterator.remove()
        }
        ref
    }

    private fun clearStore() = synchronized(storedFiles) {
        storedFiles.values.forEach { it.second.delete() }
        storedFiles.clear()
    }

    @Synchronized
    fun stop() {
        clearStore()
        runCatching { serverSocket?.close() }
        serverSocket = null
        executor?.shutdownNow()
        executor = null
    }

    /** Owner configs plus links others posted; this is what GET /configs returns. */
    fun snapshot(): List<String> {
        val owner = try {
            ownerLinks()
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "LocalShareServer: failed to read owner configs", e)
            emptyList()
        }
        return synchronized(this) { (owner + links).distinct() }
    }

    @Synchronized
    fun clear() = links.clear()

    /** Clients that talked to this server: IP -> milliseconds since they were last heard from. */
    fun knownClients(): Map<String, Long> {
        val now = System.currentTimeMillis()
        return lastSeen.mapValues { now - it.value }
    }

    /** Queues [payload] for the client with [ip]; it receives it with its next poll. Returns the message id. */
    fun sendTo(ip: String, payload: ChatPayload): Long = synchronized(outbox) {
        val id = ++outboxCounter
        val list = outbox.getOrPut(ip) { ArrayList() }
        list.add(OutboxMessage(id, payload.kind, payload.text, payload.image))
        while (list.size > MAX_OUTBOX) list.removeAt(0)
        id
    }

    private fun pollFor(ip: String, since: Long): List<OutboxMessage> = synchronized(outbox) {
        outbox[ip].orEmpty().filter { it.id > since }
    }

    internal fun parsePayload(body: String): ChatPayload? {
        val payload = try {
            GSON.fromJson(body, ChatPayload::class.java)
        } catch (e: Exception) {
            null
        } ?: return null
        val kind = payload.kind
        if (kind !in ACCEPTED_KINDS) return null
        if (kind == "file" || kind == "banner") {
            val ref = LocalProfileRules.parseFileRef(payload.text) ?: return null
            if (kind == "banner" && !LocalProfileRules.isValidBannerMime(ref.mime)) return null
            return ChatPayload(kind, GSON.toJson(ref))
        }
        if (payload.text.length > MAX_TEXT_CHARS) return null
        if ((payload.image?.length ?: 0) > MAX_IMAGE_CHARS) return null
        if (kind == "image" && payload.image.isNullOrEmpty()) return null
        if (kind == "profile" && payload.text.isBlank() && payload.image.isNullOrEmpty()) return null
        if (kind != "image" && kind != "profile" && payload.text.isBlank()) return null
        val keepsImage = kind == "image" || kind == "profile"
        return ChatPayload(kind, payload.text, if (keepsImage) payload.image else null)
    }

    /** Stores one link ("Share as local") so GET /configs hands it out; false if invalid or full. */
    @Synchronized
    fun addLink(link: String): Boolean {
        val valid = parseLinks(link).firstOrNull() ?: return false
        return links.size < MAX_LINKS && links.add(valid)
    }

    @Synchronized
    private fun remember(newLinks: List<String>): List<String> =
        newLinks.filter { links.size < MAX_LINKS && links.add(it) }

    private fun acceptLoop(socket: ServerSocket, pool: ExecutorService) {
        while (!socket.isClosed) {
            try {
                val client = socket.accept()
                pool.execute { handle(client) }
            } catch (e: IOException) {
                if (!socket.isClosed) LogUtil.e(AppConfig.TAG, "LocalShareServer: accept failed", e)
            } catch (_: java.util.concurrent.RejectedExecutionException) {
                return
            }
        }
    }

    private fun handle(client: Socket) {
        client.use { s ->
            try {
                s.soTimeout = SOCKET_TIMEOUT_MS
                if (!isLocalClient(s.inetAddress)) {
                    respond(s, 403, "text/plain", "Forbidden")
                    return
                }
                val input = BufferedInputStream(s.getInputStream())
                val requestLine = readLine(input) ?: return
                val parts = requestLine.split(' ')
                if (parts.size < 2) {
                    respond(s, 400, "text/plain", "Bad request")
                    return
                }
                val method = parts[0]
                val path = parts[1].substringBefore('?')
                val query = parts[1].substringAfter('?', "")
                val peerIp = s.inetAddress?.hostAddress?.substringBefore('%').orEmpty()

                var contentLength = 0
                while (true) {
                    val header = readLine(input) ?: return
                    if (header.isEmpty()) break
                    if (header.startsWith("content-length:", ignoreCase = true)) {
                        contentLength = header.substringAfter(':').trim().toIntOrNull() ?: -1
                    }
                }

                if (peerIp.isNotEmpty() && (path == "/configs" || path == "/poll" || path == "/msg")) {
                    lastSeen[peerIp] = System.currentTimeMillis()
                }
                if (path == "/configs" && peerIp.isNotEmpty()) {
                    runCatching { onClientSeen(peerIp) }
                }

                when {
                    method == "GET" && path == "/" ->
                        respond(s, 200, "text/html; charset=utf-8", PAGE_HTML)

                    method == "GET" && path == "/configs" ->
                        respond(s, 200, "text/plain; charset=utf-8", snapshot().joinToString("\n"))

                    method == "POST" && path == "/configs" -> {
                        if (contentLength < 0 || contentLength > MAX_BODY_BYTES) {
                            respond(s, 413, "text/plain", "Too large")
                            return
                        }
                        val body = readBody(input, contentLength)
                        val accepted = remember(parseLinks(body))
                        if (accepted.isNotEmpty()) onConfigsReceived(accepted)
                        respond(s, 200, "text/plain; charset=utf-8", accepted.size.toString())
                    }

                    method == "GET" && path == "/poll" -> {
                        val since = query.split('&')
                            .firstOrNull { it.startsWith("since=") }
                            ?.substringAfter('=')?.toLongOrNull() ?: 0L
                        respond(s, 200, "application/json; charset=utf-8", GSON.toJson(pollFor(peerIp, since)))
                    }

                    method == "POST" && path == "/file" -> {
                        val dir = fileDir
                        if (dir == null) {
                            respond(s, 404, "text/plain", "Not found")
                            return
                        }
                        if (contentLength <= 0 || contentLength > LocalProfileRules.MAX_FILE_BYTES) {
                            respond(s, 413, "text/plain", "Too large")
                            return
                        }
                        val ref = receiveFile(s, input, dir, contentLength.toLong(), query)
                        if (ref == null) respond(s, 400, "text/plain", "Bad upload")
                        else respond(s, 200, "application/json; charset=utf-8", GSON.toJson(ref))
                    }

                    method == "GET" && path.startsWith("/file/") -> {
                        val id = path.removePrefix("/file/")
                        val entry = synchronized(storedFiles) { storedFiles[id] }
                        if (entry == null || !entry.second.exists()) respond(s, 404, "text/plain", "Not found")
                        else respondFile(s, entry.second, entry.first.mime)
                    }

                    method == "POST" && path == "/msg" -> {
                        if (contentLength < 0 || contentLength > MAX_CHAT_BODY_BYTES) {
                            respond(s, 413, "text/plain", "Too large")
                            return
                        }
                        val payload = parsePayload(readBody(input, contentLength))
                        if (payload == null) {
                            respond(s, 400, "text/plain", "Bad message")
                            return
                        }
                        runCatching { onClientSeen(peerIp) }
                        onChatMessage(peerIp, payload)
                        respond(s, 200, "text/plain; charset=utf-8", "OK")
                    }

                    else -> respond(s, 404, "text/plain", "Not found")
                }
            } catch (e: IOException) {
                LogUtil.e(AppConfig.TAG, "LocalShareServer: request failed", e)
            }
        }
    }

    /** Streams exactly [length] bytes of the request body into the store; the file never sits in memory. */
    private fun receiveFile(socket: Socket, input: BufferedInputStream, dir: java.io.File, length: Long, query: String): FileRef? {
        fun param(key: String): String = query.split('&').firstOrNull { it.startsWith("$key=") }
            ?.substringAfter('=')?.let { runCatching { java.net.URLDecoder.decode(it, "UTF-8") }.getOrDefault("") }.orEmpty()
        val id = java.util.UUID.randomUUID().toString().replace("-", "")
        val target = java.io.File(dir.apply { mkdirs() }, id)
        socket.soTimeout = FILE_SOCKET_TIMEOUT_MS
        var received = 0L
        try {
            target.outputStream().use { out ->
                val buffer = ByteArray(32 * 1024)
                while (received < length) {
                    val n = input.read(buffer, 0, minOf(buffer.size.toLong(), length - received).toInt())
                    if (n < 0) break
                    out.write(buffer, 0, n)
                    received += n
                }
            }
        } catch (e: IOException) {
            target.delete()
            return null
        }
        if (received != length) {
            target.delete()
            return null
        }
        val mime = param("mime").ifBlank { "application/octet-stream" }.take(100)
        return addToStore(FileRef(id, LocalProfileRules.sanitizeFileName(param("name")), length, mime), target)
    }

    private fun respondFile(socket: Socket, file: java.io.File, mime: String) {
        socket.soTimeout = FILE_SOCKET_TIMEOUT_MS
        val head = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: ${mime.filter { it.isLetterOrDigit() || it in "/.+-" }.ifBlank { "application/octet-stream" }}\r\n" +
            "Content-Length: ${file.length()}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        val out = socket.getOutputStream()
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        file.inputStream().use { it.copyTo(out) }
        out.flush()
    }

    private fun readLine(input: BufferedInputStream): String? {
        val buffer = ByteArrayOutputStream()
        while (buffer.size() < MAX_LINE_BYTES) {
            val b = input.read()
            if (b < 0) return if (buffer.size() == 0) null else buffer.toString(Charsets.ISO_8859_1.name())
            if (b == '\n'.code) break
            if (b != '\r'.code) buffer.write(b)
        }
        return buffer.toString(Charsets.ISO_8859_1.name())
    }

    private fun readBody(input: BufferedInputStream, length: Int): String {
        val bytes = ByteArray(length)
        var read = 0
        while (read < length) {
            val n = input.read(bytes, read, length - read)
            if (n < 0) break
            read += n
        }
        return String(bytes, 0, read, Charsets.UTF_8)
    }

    private fun respond(socket: Socket, status: Int, contentType: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val reason = when (status) {
            200 -> "OK"
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            413 -> "Payload Too Large"
            else -> "Error"
        }
        val head = "HTTP/1.1 $status $reason\r\n" +
            "Content-Type: $contentType\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        val out = socket.getOutputStream()
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        out.write(bytes)
        out.flush()
    }

    companion object {
        const val DEFAULT_PORT = 8765
        private const val MAX_BODY_BYTES = 512 * 1024
        private const val MAX_LINE_BYTES = 16 * 1024
        private const val MAX_LINKS = 1000
        private const val MAX_CHAT_BODY_BYTES = 3 * 1024 * 1024
        private const val MAX_IMAGE_CHARS = 2_500_000
        private const val MAX_TEXT_CHARS = 8_000
        private const val MAX_OUTBOX = 200
        private val ACCEPTED_KINDS = setOf("text", "image", "config", "profile", "banner", "file")
        private const val MAX_STORE_BYTES = 200L * 1024 * 1024
        private const val MAX_STORED_FILES = 30
        private const val FILE_SOCKET_TIMEOUT_MS = 30_000
        private val GSON = Gson()
        private const val MAX_LINK_LENGTH = 8192
        private const val SOCKET_TIMEOUT_MS = 10_000

        private val LINK_REGEX = Regex("^[a-zA-Z][a-zA-Z0-9+.-]{1,15}://\\S+$")

        /** Keeps only plausible share links (scheme://...), trimmed and de-duplicated. */
        fun parseLinks(text: String): List<String> =
            text.lineSequence()
                .map { it.trim() }
                .filter { it.length <= MAX_LINK_LENGTH && LINK_REGEX.matches(it) }
                .distinct()
                .toList()

        /** Only LAN peers are allowed: RFC1918 / link-local / loopback addresses. */
        fun isLocalClient(address: InetAddress): Boolean =
            address.isSiteLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress

        private val PAGE_HTML = """
            <!doctype html><html><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>Local test</title>
            <style>body{font-family:sans-serif;max-width:640px;margin:24px auto;padding:0 12px}
            textarea{width:100%;height:240px;box-sizing:border-box}
            button{padding:10px 18px;margin-top:8px}</style></head><body>
            <h3>Local test</h3>
            <p>Paste share links (vmess://, vless://, trojan://, ss:// ...), one per line.</p>
            <textarea id="t" dir="ltr"></textarea><br>
            <button onclick="send()">Send</button> <span id="r"></span>
            <script>
            function send(){fetch('/configs',{method:'POST',body:document.getElementById('t').value})
            .then(function(x){return x.text()}).then(function(n){document.getElementById('r').textContent='OK: '+n})
            .catch(function(){document.getElementById('r').textContent='Error'})}
            </script></body></html>
        """.trimIndent()
    }
}
