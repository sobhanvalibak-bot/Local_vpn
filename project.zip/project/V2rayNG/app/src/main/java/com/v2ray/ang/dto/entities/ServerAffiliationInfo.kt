package com.v2ray.ang.dto.entities

data class ServerAffiliationInfo(
    var testDelayMillis: Long = 0L,
    /** Download speed measured through the profile in bytes per second; 0 means not measured. Absent in data stored by older versions. */
    var testDownloadBytesPerSec: Long = 0L,
)
