package com.v2ray.ang.handler

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.CoreServiceManager
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.extension.delay
import com.v2ray.ang.extension.toSpeedString
import com.v2ray.ang.helper.NotificationHelper
import com.v2ray.ang.ui.main.MainActivity
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min

object NotificationManager {
    private const val NOTIFICATION_ID = 1
    private const val NOTIFICATION_PENDING_INTENT_CONTENT = 0
    private const val NOTIFICATION_PENDING_INTENT_STOP_V2RAY = 1
    private const val NOTIFICATION_PENDING_INTENT_RESTART_V2RAY = 2
    private const val NOTIFICATION_ICON_THRESHOLD = 3000
    private const val QUERY_INTERVAL_MS = 3000L
    private const val NOTIFICATION_PENDING_INTENT_ISLAND_STOP = 3
    private const val ISLAND_PING_INTERVAL_MS = 10_000L

    private var mBuilder: NotificationCompat.Builder? = null
    private var speedNotificationJob: Job? = null
    private var mNotificationManager: NotificationManager? = null

    // Xiaomi Super Island state. Null on every device that does not support the island.
    @Volatile
    private var islandState: HyperIsland.State? = null
    private var islandStopIntent: PendingIntent? = null
    private var islandJob: Job? = null

    /**
     * Starts the speed notification.
     * @param currentConfig The current profile configuration.
     */
    fun startSpeedNotification() {
        startIslandUpdates()
        if (MmkvManager.decodeSettingsBool(AppConfig.PREF_SPEED_ENABLED) != true) return
        if (speedNotificationJob != null || CoreServiceManager.isRunning() == false) return

        var lastZeroSpeed = false

        speedNotificationJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                lastZeroSpeed = updateSpeedNotificationOnce(lastZeroSpeed)
                delay(QUERY_INTERVAL_MS)
            }
        }
    }

    /**
     * Shows the notification.
     * @param currentConfig The current profile configuration.
     */
    fun showNotification(currentConfig: ProfileItem?) {
        val service = getService() ?: return

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val startMainIntent = Intent(service, MainActivity::class.java)
        val contentPendingIntent = PendingIntent.getActivity(service, NOTIFICATION_PENDING_INTENT_CONTENT, startMainIntent, flags)

        val stopV2RayIntent = Intent(AppConfig.BROADCAST_ACTION_SERVICE)
        stopV2RayIntent.`package` = AppConfig.ANG_PACKAGE
        stopV2RayIntent.putExtra("key", AppConfig.MSG_STATE_STOP)
        val stopV2RayPendingIntent = PendingIntent.getBroadcast(service, NOTIFICATION_PENDING_INTENT_STOP_V2RAY, stopV2RayIntent, flags)

        val restartV2RayIntent = Intent(AppConfig.BROADCAST_ACTION_SERVICE)
        restartV2RayIntent.`package` = AppConfig.ANG_PACKAGE
        restartV2RayIntent.putExtra("key", AppConfig.MSG_STATE_RESTART)
        val restartV2RayPendingIntent = PendingIntent.getBroadcast(service, NOTIFICATION_PENDING_INTENT_RESTART_V2RAY, restartV2RayIntent, flags)

        val channelId =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                createNotificationChannel()
            } else {
                // If earlier version channel ID is not used
                // https://developer.android.com/reference/android/support/v4/app/NotificationCompat.Builder.html#NotificationCompat.Builder(android.content.Context)
                ""
            }

        mBuilder = NotificationCompat.Builder(service, channelId)
            .setSmallIcon(R.drawable.ic_stat_name)
            .setContentTitle(currentConfig?.remarks ?: service.getString(R.string.app_name))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentPendingIntent)
            .addAction(
                R.drawable.ic_delete_24dp,
                service.getString(R.string.notification_action_stop_v2ray),
                stopV2RayPendingIntent
            )
            .addAction(
                R.drawable.ic_restore_24dp,
                service.getString(R.string.title_service_restart),
                restartV2RayPendingIntent
            )

        //mBuilder?.setDefaults(NotificationCompat.FLAG_ONLY_ALERT_ONCE)

        if (HyperIsland.isSupported(service)) {
            // Island buttons need a foreground receiver flag, and a request code of their own so the
            // PendingIntent is not merged with the one used by the regular notification action.
            val islandStop = Intent(AppConfig.BROADCAST_ACTION_SERVICE)
                .setPackage(AppConfig.ANG_PACKAGE)
                .putExtra("key", AppConfig.MSG_STATE_STOP)
                .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            islandStopIntent = PendingIntent.getBroadcast(service, NOTIFICATION_PENDING_INTENT_ISLAND_STOP, islandStop, flags)
            // A new connection or reload starts over: ping and IP are measured again.
            islandState = HyperIsland.State(name = currentConfig?.remarks ?: service.getString(R.string.app_name))
        } else {
            islandState = null
            islandStopIntent = null
        }

        service.startForeground(NOTIFICATION_ID, buildNotification())
    }

    /**
     * Fulfills or refreshes the foreground-service contract before a start command can
     * return early. A duplicate startForegroundService call still requires the service
     * to enter foreground state promptly, even when the core is already running.
     */
    fun ensureForeground() {
        val service = getService() ?: return
        val notification = buildNotification()
        if (notification == null) showNotification(null) else service.startForeground(NOTIFICATION_ID, notification)
    }

    /**
     * Cancels the notification.
     */
    fun cancelNotification() {
        val service = getService() ?: return
        // Stop the ping loop before removing the notification so it cannot re-post it afterwards.
        stopIslandUpdates()
        islandState = null
        islandStopIntent = null
        service.stopForeground(Service.STOP_FOREGROUND_REMOVE)

        mBuilder = null
        speedNotificationJob?.cancel()
        speedNotificationJob = null
        mNotificationManager = null
    }

    /**
     * Stops the speed notification.
     */
    fun stopSpeedNotification() {
        stopIslandUpdates()
        speedNotificationJob?.let {
            it.cancel()
            speedNotificationJob = null
            updateNotification("", 0, 0)
        }
    }

    /**
     * Creates a notification channel for Android O and above.
     * @return The channel ID.
     */
    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel(): String {
        val channelId = AppConfig.RAY_NG_CHANNEL_ID
        val service = getService() ?: return channelId
        NotificationHelper.ensureNotificationChannel(
            context = service,
            channelId = channelId,
            channelNameRes = R.string.notification_channel_service,
            // Foreground-service notifications must remain visible; LOW is silent but valid.
            importance = NotificationManager.IMPORTANCE_LOW,
        ) {
            lightColor = Color.DKGRAY
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
        }
        return channelId
    }

    /**
     * Updates the notification with the given content text and traffic data.
     * @param contentText The content text.
     * @param proxyTraffic The proxy traffic.
     * @param directTraffic The direct traffic.
     */
    private fun updateNotification(contentText: String?, proxyTraffic: Long, directTraffic: Long) {
        if (mBuilder != null) {
            if (proxyTraffic < NOTIFICATION_ICON_THRESHOLD && directTraffic < NOTIFICATION_ICON_THRESHOLD) {
                mBuilder?.setSmallIcon(R.drawable.ic_stat_name)
            } else if (proxyTraffic > directTraffic) {
                mBuilder?.setSmallIcon(R.drawable.ic_stat_proxy)
            } else {
                mBuilder?.setSmallIcon(R.drawable.ic_stat_direct)
            }
            mBuilder?.setStyle(NotificationCompat.BigTextStyle().bigText(contentText))
            mBuilder?.setContentText(contentText)
            getNotificationManager()?.notify(NOTIFICATION_ID, buildNotification())
        }
    }

    /**
     * Builds the current notification and, on HyperOS 3, attaches the Super Island payload to it.
     * Every build site goes through here so the island never disappears on a speed update.
     */
    private fun buildNotification(): Notification? {
        val notification = mBuilder?.build() ?: return null
        val state = islandState
        val stopIntent = islandStopIntent
        val service = getService()
        if (state != null && stopIntent != null && service != null) {
            HyperIsland.apply(service, notification, state, stopIntent)
        }
        return notification
    }

    /**
     * Starts the background loop that keeps the island's ping and IP fresh.
     * HyperOS does not tell the app when the island is expanded, so the values are refreshed on a
     * timer while the screen is on instead of on expand.
     */
    private fun startIslandUpdates() {
        if (islandState == null || islandJob != null || CoreServiceManager.isRunning() == false) return

        islandJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                // null means the core is reloading: keep the previous values and try again later.
                val ping = CoreServiceManager.probeDelay()
                val current = islandState
                if (ping != null && current != null) {
                    // The exit IP only needs to be looked up once per connection.
                    val ip = current.ip
                        ?: if (ping >= 0) SpeedtestManager.getRemoteIPInfo()?.ipAddress else null
                    if (isActive) {
                        islandState = current.copy(pingMs = ping, ip = ip)
                        refreshIsland()
                    }
                }
                delay(ISLAND_PING_INTERVAL_MS)
            }
        }
    }

    /**
     * Stops the island loop, for example when the screen turns off.
     */
    private fun stopIslandUpdates() {
        islandJob?.cancel()
        islandJob = null
    }

    /**
     * Re-posts the notification with the latest island state.
     */
    private fun refreshIsland() {
        if (mBuilder == null) return
        val notification = buildNotification() ?: return
        getNotificationManager()?.notify(NOTIFICATION_ID, notification)
    }

    /**
     * Gets the notification manager.
     * @return The notification manager.
     */
    private fun getNotificationManager(): NotificationManager? {
        if (mNotificationManager == null) {
            val service = getService() ?: return null
            mNotificationManager = service.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        }
        return mNotificationManager
    }

    /**
     * Appends the speed string to the given text.
     * @param text The text to append to.
     * @param name The name of the tag.
     * @param up The uplink speed.
     * @param down The downlink speed.
     */
    private fun appendSpeedString(text: StringBuilder, name: String?, up: Double, down: Double) {
        var n = name ?: "no tag"
        n = n.take(min(n.length, 6))
        text.append(n)
        for (i in n.length..6 step 2) {
            text.append("\t")
        }
        text.append("•  ${up.toLong().toSpeedString()}↑  ${down.toLong().toSpeedString()}↓\n")
    }

    /**
     * Updates the speed notification once.
     * Queries traffic stats, separates proxy and direct, and updates the notification.
     * @param lastZeroSpeed The previous zero speed state.
     * @return The current zero speed state.
     */
    private fun updateSpeedNotificationOnce(lastZeroSpeed: Boolean): Boolean {
        // TrafficSampler is the only reader of the core's reset-on-read counters; it hands over the
        // bytes it saw since the previous call. An empty window means it was paused (screen off).
        val window = TrafficSampler.drainNotificationWindow()
        if (window.elapsedMs <= 0L) return lastZeroSpeed
        val windowSeconds = window.elapsedMs / 1000.0

        val proxyTotal = window.proxyUplink + window.proxyDownlink
        val directTotal = window.directUplink + window.directDownlink
        val zeroSpeed = proxyTotal + directTotal == 0L
        if (!zeroSpeed || !lastZeroSpeed) {
            val text = StringBuilder()
            appendSpeedString(
                text, AppConfig.TAG_PROXY,
                window.proxyUplink / windowSeconds,
                window.proxyDownlink / windowSeconds
            )

            appendSpeedString(
                text, AppConfig.TAG_DIRECT,
                window.directUplink / windowSeconds,
                window.directDownlink / windowSeconds
            )
            updateNotification(text.toString(), proxyTotal, directTotal)
        }
        return zeroSpeed
    }

    /**
     * Gets the service instance.
     * @return The service instance.
     */
    private fun getService(): Service? {
        return CoreServiceManager.serviceControl?.get()?.getService()
    }
}
