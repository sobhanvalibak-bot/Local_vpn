package com.v2ray.ang.handler

import java.net.URLDecoder

/** Pure rules for the Local test profile and for recognising configs in chat text. No Android types. */
object LocalProfileRules {
    const val KIND_PROFILE = "profile"
    const val KIND_BANNER = "banner"
    const val MAX_NAME_CHARS = 40

    /** Largest file (and banner) that can be sent between two devices. */
    const val MAX_FILE_BYTES = 25L * 1024 * 1024
    const val MAX_BANNER_BYTES = MAX_FILE_BYTES

    const val MIME_JPEG = "image/jpeg"
    const val MIME_MP4 = "video/mp4"

    fun isValidBannerMime(mime: String?): Boolean = mime == MIME_JPEG || mime == MIME_MP4

    fun isVideo(mime: String?): Boolean = mime == MIME_MP4

    /** Trims, collapses whitespace and caps the length; a name is shown in lists, so it stays one short line. */
    fun cleanName(raw: String): String = raw.trim().replace(Regex("\\s+"), " ").take(MAX_NAME_CHARS)

    /**
     * Recognises configs typed or pasted as plain text: a "text" message that contains share links becomes a
     * "config" message holding just those links, so it gets the config card (with its add button) on both sides.
     * Every other message is returned unchanged.
     */
    fun detectConfig(payload: ChatPayload): ChatPayload {
        if (payload.kind != "text") return payload
        val links = LocalShareServer.parseLinks(payload.text)
        return if (links.isEmpty()) payload else ChatPayload("config", links.joinToString("\n"))
    }

    private val FILE_ID_REGEX = Regex("^[0-9a-f]{32}$")

    /** Reads a [FileRef] from the JSON in a "file" or "banner" message; null when it is missing, malformed or over the limit. */
    fun parseFileRef(json: String): FileRef? {
        val ref = try {
            com.google.gson.Gson().fromJson(json, FileRef::class.java)
        } catch (e: Exception) {
            null
        } ?: return null
        if (!FILE_ID_REGEX.matches(ref.id)) return null
        if (ref.size !in 1..MAX_FILE_BYTES) return null
        if (ref.mime.isBlank() || ref.mime.length > 100) return null
        return ref.copy(name = sanitizeFileName(ref.name))
    }

    /** A file name safe to show and to write: no path parts or control characters, never empty, capped. */
    fun sanitizeFileName(raw: String): String {
        val cleaned = raw.substringAfterLast('/').substringAfterLast('\\')
            .filter { !it.isISOControl() && it !in "<>:\"|?*" }
            .trim()
            .take(100)
        return cleaned.ifBlank { "file" }
    }

    /** Readable name of a share link: its #fragment when it has one, else its protocol (vmess://... -> VMESS). */
    fun linkName(link: String): String {
        val fragment = link.substringAfter('#', "")
        if (fragment.isNotBlank()) {
            val decoded = try {
                URLDecoder.decode(fragment, "UTF-8")
            } catch (e: Exception) {
                fragment
            }
            if (decoded.isNotBlank()) return decoded.take(60)
        }
        return link.substringBefore("://").uppercase()
    }
}
