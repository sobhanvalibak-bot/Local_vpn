package com.v2ray.ang.handler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.content.ContextCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.CoreServiceManager
import com.v2ray.ang.dto.RealPingResult
import com.v2ray.ang.dto.TestServiceMessage
import com.v2ray.ang.extension.serializable
import com.v2ray.ang.helper.MessageHelper
import com.v2ray.ang.util.LogUtil
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Pure decisions of Auto connection, kept apart from Android so they can be unit tested.
 */
internal object AutoConnectSelector {
    /** Consecutive failed health checks that count as "the connection is down". */
    const val FAILURES_BEFORE_SWITCH = 2

    /** How many of the fastest profiles get a second, confirming test round. */
    const val SHORTLIST_SIZE = 3

    fun shouldSwitch(consecutiveFailures: Int): Boolean = consecutiveFailures >= FAILURES_BEFORE_SWITCH

    /** Profiles to try: everything stored, minus the failing one and the excluded groups' profiles. */
    fun candidates(all: List<String>, excluded: Set<String>): List<String> =
        all.filter { it !in excluded }.distinct()

    /** The [size] lowest successful delays of one round, fastest first. A delay of 0 or less is a failure. */
    fun shortlist(round: Map<String, Long>, size: Int = SHORTLIST_SIZE): List<String> =
        round.filterValues { it > 0L }
            .entries
            .sortedWith(compareBy({ it.value }, { it.key }))
            .take(size)
            .map { it.key }

    /**
     * The best profile across several rounds: it must have answered in every round, then the lowest
     * average delay wins, then the lowest worst-case delay, so a profile that is fast but jumpy loses.
     */
    fun pickBest(rounds: List<Map<String, Long>>, among: List<String>): String? {
        if (rounds.isEmpty()) return null
        return among
            .mapNotNull { guid ->
                val delays = rounds.map { it[guid] ?: return@mapNotNull null }
                if (delays.any { it <= 0L }) return@mapNotNull null
                Triple(guid, delays.average(), delays.max())
            }
            .minWithOrNull(compareBy({ it.second }, { it.third }, { it.first }))
            ?.first
    }

    /** Waiting time after a failover that found nothing usable: doubles up to a ceiling. */
    fun retryDelayMs(previousFailures: Int, baseMs: Long, maxMs: Long): Long {
        val shift = previousFailures.coerceIn(0, 10)
        return (baseMs shl shift).coerceAtMost(maxMs)
    }
}

/**
 * Auto connection, running in the daemon process next to the core so it works with the app closed.
 *
 * While the core runs and the user enabled [AppConfig.PREF_AUTO_CONNECTION], the active profile is
 * probed every [CHECK_INTERVAL_MS]. When the probe fails [AutoConnectSelector.FAILURES_BEFORE_SWITCH]
 * times in a row, every other stored profile is tested through `CoreTestService` (its own process, so
 * a native crash cannot take the tunnel down), the fastest few are tested again to confirm, and the
 * core is reloaded on the winner. If nothing answers, the current profile stays and the next attempt
 * waits longer.
 */
object AutoConnectManager {
    private const val CHECK_INTERVAL_MS = 10_000L
    private const val FIRST_CHECK_DELAY_MS = 15_000L
    private const val SETTLE_AFTER_SWITCH_MS = 20_000L
    private const val RETRY_BASE_MS = 30_000L
    private const val RETRY_MAX_MS = 5 * 60_000L
    private const val TEST_TIMEOUT_MS = 3 * 60_000L

    private val lock = Any()
    private var scope: CoroutineScope? = null

    /** Starts watching the core that just started. Safe to call twice. */
    fun start(context: Context) {
        synchronized(lock) {
            if (scope != null) return
            val newScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            scope = newScope
            newScope.launch { watchLoop(context.applicationContext) }
        }
    }

    /** Stops watching; a failover in flight is cancelled. Safe to call twice. */
    fun stop() {
        synchronized(lock) {
            scope?.cancel()
            scope = null
        }
    }

    fun isEnabled(): Boolean = MmkvManager.decodeSettingsBool(AppConfig.PREF_AUTO_CONNECTION, false)

    private suspend fun watchLoop(context: Context) {
        var failures = 0
        var fruitlessAttempts = 0
        delay(FIRST_CHECK_DELAY_MS)
        while (currentCoroutineContext().isActive) {
            delay(CHECK_INTERVAL_MS)
            if (!isEnabled()) {
                failures = 0
                continue
            }
            // null: no core to probe or it is being reloaded right now, which is not a failure.
            val probe = CoreServiceManager.probeDelay() ?: continue
            if (probe >= 0L) {
                failures = 0
                fruitlessAttempts = 0
                continue
            }
            failures++
            if (!AutoConnectSelector.shouldSwitch(failures)) continue
            failures = 0

            if (!hasUsableUnderlyingNetwork(context)) {
                LogUtil.i(AppConfig.TAG, "AutoConnect: probe failed but the device is offline, not switching")
                continue
            }
            val switched = failover(context)
            if (switched) {
                fruitlessAttempts = 0
                delay(SETTLE_AFTER_SWITCH_MS)
            } else {
                delay(AutoConnectSelector.retryDelayMs(fruitlessAttempts, RETRY_BASE_MS, RETRY_MAX_MS))
                fruitlessAttempts++
            }
        }
    }

    /** @return true when the core now runs on another profile. */
    private suspend fun failover(context: Context): Boolean {
        val current = MmkvManager.getSelectServer()
        val excluded = MmkvManager.decodeServerList(LocalTestManager.GROUP_ID).toHashSet().apply {
            current?.let(::add)
        }
        val candidates = AutoConnectSelector.candidates(MmkvManager.decodeAllServerList(), excluded)
        if (candidates.isEmpty()) return false

        LogUtil.i(AppConfig.TAG, "AutoConnect: failover from $current, testing ${candidates.size} profiles")
        val firstRound = runTests(context, candidates) ?: return false
        val shortlist = AutoConnectSelector.shortlist(firstRound)
        if (shortlist.isEmpty()) {
            LogUtil.w(AppConfig.TAG, "AutoConnect: no profile answered, keeping $current")
            return false
        }
        val secondRound = runTests(context, shortlist) ?: return false
        val best = AutoConnectSelector.pickBest(listOf(firstRound, secondRound), shortlist) ?: return false

        // The user may have stopped the service or picked a profile while the tests ran.
        if (!CoreServiceManager.isRunning() || !isEnabled() || MmkvManager.getSelectServer() != current) return false

        val switched = CoreServiceManager.switchToServer(best)
        LogUtil.i(AppConfig.TAG, "AutoConnect: switch $current -> $best, success=$switched")
        if (switched) {
            MessageHelper.sendMsg2UI(context, AppConfig.MSG_AUTO_SWITCHED, best)
        }
        return switched
    }

    /**
     * Runs one real-ping round through `CoreTestService` and collects its answers.
     * @return guid to delay (a delay of 0 or less is a failure), or null when the round was cancelled or timed out.
     */
    private suspend fun runTests(context: Context, guids: List<String>): Map<String, Long>? {
        val requestId = UUID.randomUUID().toString()
        val results = ConcurrentHashMap<String, Long>()
        val finished = CompletableDeferred<Boolean>()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null || intent.getStringExtra(MessageHelper.EXTRA_REQUEST_ID) != requestId) return
                when (intent.getIntExtra("key", 0)) {
                    AppConfig.MSG_MEASURE_CONFIG_SUCCESS ->
                        intent.serializable<RealPingResult>("content")?.let { results[it.guid] = it.delayMillis }

                    AppConfig.MSG_MEASURE_CONFIG_FINISH -> finished.complete(true)
                    AppConfig.MSG_MEASURE_CONFIG_CANCEL -> finished.complete(false)
                }
            }
        }
        ContextCompat.registerReceiver(
            context, receiver, IntentFilter(AppConfig.BROADCAST_ACTION_ACTIVITY), Utils.receiverFlags()
        )
        try {
            MessageHelper.sendMsg2TestService(
                context,
                TestServiceMessage(key = AppConfig.MSG_MEASURE_CONFIG_START, serverGuids = guids),
                requestId,
            )
            val completed = withTimeoutOrNull(TEST_TIMEOUT_MS) { finished.await() }
            if (completed == null) {
                LogUtil.w(AppConfig.TAG, "AutoConnect: test round of ${guids.size} profiles timed out")
                MessageHelper.sendMsg2TestService(context, TestServiceMessage(key = AppConfig.MSG_MEASURE_CONFIG_CANCEL))
                return null
            }
            return if (completed) results.toMap() else null
        } catch (cancelled: CancellationException) {
            throw cancelled
        } finally {
            runCatching { context.unregisterReceiver(receiver) }
                .onFailure { LogUtil.w(AppConfig.TAG, "AutoConnect: failed to unregister test receiver", it) }
        }
    }

    /**
     * True when some non-VPN network can reach the internet; without one every profile fails for the same reason.
     * allNetworks is deprecated from API 31 but minSdk is 24 and no replacement lists every network;
     * remove the suppression once minSdk reaches a level where one exists.
     */
    @Suppress("DEPRECATION")
    private fun hasUsableUnderlyingNetwork(context: Context): Boolean {
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return true
        return try {
            connectivity.allNetworks.any { network ->
                val caps = connectivity.getNetworkCapabilities(network) ?: return@any false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        } catch (e: Exception) {
            LogUtil.w(AppConfig.TAG, "AutoConnect: failed to inspect networks", e)
            true
        }
    }
}
