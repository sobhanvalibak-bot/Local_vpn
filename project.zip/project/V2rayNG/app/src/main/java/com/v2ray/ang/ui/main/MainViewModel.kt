package com.v2ray.ang.ui.main

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.dto.ConnectionTestResult
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.dto.LocateTarget
import com.v2ray.ang.dto.RealPingResult
import com.v2ray.ang.enums.DefaultTabSort
import com.v2ray.ang.handler.BannerResult
import com.v2ray.ang.handler.ChatImageCodec
import com.v2ray.ang.handler.LocalProfileRules
import com.v2ray.ang.handler.LocalProfileStore
import com.v2ray.ang.handler.FileRef
import com.v2ray.ang.handler.LocalFileStaging
import com.v2ray.ang.handler.StageResult
import com.v2ray.ang.handler.RankedServer
import com.v2ray.ang.handler.ServerRanking
import com.v2ray.ang.dto.TestServiceMessage
import com.v2ray.ang.dto.TrafficSpeed
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.ServersCache
import com.v2ray.ang.dto.entities.SubscriptionCache
import com.v2ray.ang.extension.delay
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.extension.matchesPattern
import com.v2ray.ang.extension.moveItem
import com.v2ray.ang.handler.LocalShareServer
import com.v2ray.ang.handler.ChatPayload
import com.v2ray.ang.handler.LocalTestManager
import com.v2ray.ang.handler.LocalTestNotifier
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.ServerCountryResolver
import com.v2ray.ang.handler.TelegramProxyManager
import com.v2ray.ang.handler.TelegramProxyStore
import com.v2ray.ang.util.QRCodeDecoder
import com.v2ray.ang.handler.SubscriptionInfoParser
import com.v2ray.ang.ui.base.BaseViewModel
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.PatternSyntaxException

private fun applyTestDelayResults(
    servers: List<ServersCache>,
    updates: Map<String, RealPingResult>,
): List<ServersCache> = servers.map { server ->
    val result = updates[server.guid]
    if (result == null ||
        (result.delayMillis == server.testDelayMillis && result.downloadBytesPerSec == server.testDownloadBytesPerSec)
    ) {
        server
    } else {
        server.copy(
            testDelayMillis = result.delayMillis,
            testDownloadBytesPerSec = result.downloadBytesPerSec,
        )
    }
}

private fun applyTestDelayResultsToRows(
    rows: List<ServerRowUiModel>,
    updates: Map<String, RealPingResult>,
): List<ServerRowUiModel> = rows.map { row ->
    val result = updates[row.guid]
    if (result == null ||
        (result.delayMillis == row.testDelayMillis && result.downloadBytesPerSec == row.testDownloadBytesPerSec)
    ) {
        row
    } else {
        row.copy(
            testDelayMillis = result.delayMillis,
            testDownloadBytesPerSec = result.downloadBytesPerSec,
        )
    }
}

/** Display order of the Default tab; other tabs keep their stored order. Stored data is never reordered. */
internal fun sortForDefaultTab(servers: List<ServersCache>, mode: DefaultTabSort): List<ServersCache> {
    if (mode == DefaultTabSort.TIME) return servers
    val byGuid = servers.associateBy { it.guid }
    return ServerRanking.sort(
        servers.map { RankedServer(it.guid, it.testDelayMillis, it.testDownloadBytesPerSec) },
        mode,
    ).mapNotNull { byGuid[it.guid] }
}

class MainViewModel(
    application: Application,
    private val dataSource: MainDataSource
) : BaseViewModel(application) {

    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.Default
    private val preloadDispatcher: CoroutineDispatcher = Dispatchers.IO.limitedParallelism(1)

    // ---------- UI state ----------
    private val _uiState = MutableStateFlow(
        MainUiState(
            // The app always opens on the Home tab.
            selectedGroupId = HOME_GROUP_ID,
            selectedGuid = dataSource.getSelectServer(),
            confirmRemove = dataSource.getConfirmRemove(),
            doubleColumnDisplay = dataSource.getDoubleColumnDisplay(),
            autoConnection = dataSource.getAutoConnection(),
            defaultTabSort = DefaultTabSort.fromStorage(dataSource.getDefaultTabSort()),
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // Live speed changes every second, so it stays out of uiState and only the Home page collects it.
    private val _trafficSpeed = MutableStateFlow(TrafficSpeed())
    val trafficSpeed: StateFlow<TrafficSpeed> = _trafficSpeed.asStateFlow()

    /** The Home page is visible, so the daemon should keep sending speed. Re-sent when the core (re)starts. */
    private var speedUpdatesWanted = false
    private var activeConfigJob: Job? = null

    // ---------- Keyword filtering ----------
    @Volatile
    private var keywordFilter: String = ""
    private var filterJob: Job? = null

    // ---------- Groups & cache ----------
    private val cacheMutex = Mutex()
    private val groupDataCache = mutableMapOf<String, List<ServersCache>>()
    private val groupUiFlows = ConcurrentHashMap<String, MutableStateFlow<ServerGroupUiState>>()
    private val groupServerFlows = ConcurrentHashMap<String, StateFlow<List<ServersCache>>>()
    private val groupLoadMutexes = ConcurrentHashMap<String, Mutex>()
    private val serverOrderPersistenceJobs = mutableMapOf<String, Job>()

    private var setupGroupJob: Job? = null
    private var preloadJob: Job? = null
    private var selectedGroupLoadJob: Job? = null
    private var reloadJob: Job? = null
    private var testResultFlushJob: Job? = null
    private val pendingTestResults = linkedMapOf<String, RealPingResult>()

    private val testRequests = MainTestRequests()
    private var bulkTestJob: Job? = null

    private val initialPageReady = CompletableDeferred<Unit>()

    // ---------- Service events ----------
    init {
        collectServiceEvents()
        setupGroupTab()
        refreshActiveConfig()
    }

    private fun collectServiceEvents() {
        viewModelScope.launch {
            dataSource.mainServiceEvent.collect { event ->
                handleServiceEvent(event)
            }
        }
    }

    private fun handleServiceEvent(event: MainServiceEvent) {
        when (event) {
            MainServiceEvent.StateRunning -> {
                updateRunningState(true, clearTestingText = false)
                resubscribeSpeed()
            }
            MainServiceEvent.StateNotRunning -> {
                updateRunningState(false, clearTestingText = false)
                _trafficSpeed.value = TrafficSpeed()
            }
            MainServiceEvent.StateStartSuccess -> {
                toastSuccess(R.string.toast_services_success)
                updateRunningState(true)
                resubscribeSpeed()
            }

            is MainServiceEvent.StateStartFailure -> {
                if (!event.message.isNullOrBlank()) {
                    toastError(event.message)
                } else {
                    toastError(R.string.toast_services_failure)
                }
                updateRunningState(false)
                _trafficSpeed.value = TrafficSpeed()
            }

            MainServiceEvent.StateStopSuccess -> {
                updateRunningState(false)
                _trafficSpeed.value = TrafficSpeed()
            }
            is MainServiceEvent.SpeedUpdate -> _trafficSpeed.value = event.speed
            is MainServiceEvent.AutoSwitched -> onAutoSwitched(event.guid)
            is MainServiceEvent.MeasureDelayResult -> {
                if (!uiState.value.isRunning || !testRequests.completeCurrent(event.requestId)) return
                _uiState.update {
                    it.copy(
                        isTesting = testRequests.isTesting,
                        status = MainStatus.ConnectionTest(event.result),
                        activeConfig = it.activeConfig?.copy(delayMillis = event.result.delayMillis),
                    )
                }
            }

            is MainServiceEvent.MeasureConfigSuccess -> {
                val request = testRequests.bulk?.takeIf { it.id == event.requestId } ?: return
                queueTestResult(event.result, request)
            }

            is MainServiceEvent.MeasureConfigNotify -> {
                if (event.requestId == testRequests.bulk?.id) {
                    _uiState.update { it.copy(status = MainStatus.TestProgress(event.progress)) }
                }
            }

            is MainServiceEvent.MeasureConfigFinish -> {
                val request = testRequests.bulk?.takeIf { it.id == event.requestId } ?: return
                val scheduledFlush = testResultFlushJob
                testResultFlushJob = viewModelScope.launch {
                    scheduledFlush?.cancelAndJoin()
                    if (testRequests.bulk?.id != request.id) return@launch
                    flushPendingTestResults(request)
                    onTestsFinished(request.id)
                }
            }

            is MainServiceEvent.MeasureDelayCancelled -> {
                if (testRequests.completeCurrent(event.requestId)) resetTestStatus()
            }

            is MainServiceEvent.MeasureConfigCancelled -> {
                if (testRequests.completeBulk(event.requestId) != null) {
                    if (autoChangePending) {
                        autoChangePending = false
                        _uiState.update { it.copy(autoChanging = false) }
                    }
                    cancelPendingTestResults()
                    resetTestStatus()
                }
            }
        }
    }

    private fun queueTestResult(result: RealPingResult, request: MainTestRequests.Bulk) {
        pendingTestResults[result.guid] = result
        if (testResultFlushJob?.isActive == true) return

        testResultFlushJob = viewModelScope.launch {
            while (pendingTestResults.isNotEmpty()) {
                delay(TEST_RESULT_FLUSH_INTERVAL_MS)
                flushPendingTestResults(request)
            }
        }
    }

    private suspend fun flushPendingTestResults(request: MainTestRequests.Bulk) {
        if (pendingTestResults.isEmpty()) return
        if (testRequests.bulk?.id != request.id) return

        val updates = cacheMutex.withLock {
            val drained = pendingTestResults.toMap()
            pendingTestResults.clear()
            groupDataCache[request.groupId]?.let { cached ->
                groupDataCache[request.groupId] = applyTestDelayResults(cached, drained)
            }
            drained
        }
        if (updates.isEmpty()) return
        if (testRequests.bulk?.id != request.id) return
        _uiState.update { state ->
            val active = state.activeConfig
            val delayMillis = active?.let { updates[it.guid]?.delayMillis }
            if (active == null || delayMillis == null) state
            else state.copy(activeConfig = active.copy(delayMillis = delayMillis))
        }
        mutableServerGroupState(request.groupId).update { current ->
            current.copy(
                servers = applyTestDelayResults(current.servers, updates),
                rows = applyTestDelayResultsToRows(current.rows, updates),
            )
        }
    }

    internal fun formatStatus(status: MainStatus): String = when (status) {
        MainStatus.Disconnected -> dataSource.getString(R.string.connection_not_connected)
        MainStatus.Connected -> dataSource.getString(R.string.connection_connected)
        MainStatus.Testing -> dataSource.getString(R.string.connection_test_testing)
        is MainStatus.TestProgress -> dataSource.getString(
            R.string.connection_running_task_left,
            status.progress
        )

        is MainStatus.ConnectionTest -> formatConnectionTestResult(status.result)
    }

    private fun formatConnectionTestResult(result: ConnectionTestResult): String {
        val status = if (result.delayMillis >= 0) {
            val delay = dataSource.getString(R.string.server_test_delay_value, result.delayMillis)
            dataSource.getString(R.string.connection_test_available, delay)
        } else {
            val detail = result.errorMessage.ifBlank {
                dataSource.getString(R.string.connection_test_empty_message)
            }
            dataSource.getString(R.string.connection_test_error, detail)
        }

        if (result.delayMillis < 0 || (result.country == null && result.ipAddress == null)) {
            return status
        }

        val unknown = dataSource.getString(R.string.value_unknown)
        return "$status\n(${result.country ?: unknown}) ${result.ipAddress ?: unknown}"
    }

    // ---------- Public state accessors ----------
    fun serversForGroup(groupId: String): StateFlow<List<ServersCache>> =
        groupServerFlows.computeIfAbsent(groupId) {
            val groupState = mutableServerGroupState(groupId)
            groupState
                .map { it.servers }
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
                    initialValue = groupState.value.servers,
                )
        }

    internal fun serverGroupState(groupId: String): StateFlow<ServerGroupUiState> =
        mutableServerGroupState(groupId).asStateFlow()

    private fun mutableServerGroupState(groupId: String): MutableStateFlow<ServerGroupUiState> =
        groupUiFlows.computeIfAbsent(groupId) { MutableStateFlow(ServerGroupUiState()) }

    private fun currentServers(): List<ServersCache> =
        mutableServerGroupState(uiState.value.selectedGroupId).value.servers

    // ---------- Action handler ----------
    fun onAction(action: MainAction) {
        when (action) {
            MainAction.Initialize -> initialize()
            MainAction.RefreshGroups -> setupGroupTab(forceRefresh = true)
            MainAction.TestAllServers ->
                if (onTelegramTab()) telegramTestAll() else testAllRealPing(true)
            MainAction.TestRealAllServers ->
                if (onTelegramTab()) telegramTestAll() else testAllRealPing()
            MainAction.CancelTesting -> cancelAllPing()
            is MainAction.SetAutoConnection -> {
                dataSource.setAutoConnection(action.enabled)
                _uiState.update { it.copy(autoConnection = action.enabled) }
            }
            is MainAction.SetDefaultTabSort -> setDefaultTabSort(action.mode)
            MainAction.AutoChange -> autoChange()
            MainAction.AutoChangeConnectHandled -> _uiState.update { it.copy(connectAfterAutoChange = false) }
            is MainAction.SpeedUpdatesWanted -> {
                speedUpdatesWanted = action.wanted
                dataSource.setSpeedUpdates(action.wanted)
            }
            MainAction.RemoveAllServers ->
                if (onTelegramTab()) telegramRemoveAll() else removeAllServerAsync()
            MainAction.RemoveDuplicateServers -> removeDuplicateServerAsync()
            MainAction.RemoveInvalidServers -> removeInvalidServerAsync()
            MainAction.SortByTestResults -> sortByTestResultsAsync()
            MainAction.UpdateSubscriptions ->
                if (onTelegramTab()) telegramTestAll() else importConfigViaSub(importTargetGroupId())
            is MainAction.UpdateGroupSubscription -> importConfigViaSub(action.groupId)
            MainAction.ExportAll -> exportAllAsync()
            is MainAction.SelectGroup -> subscriptionIdChanged(action.groupId)
            is MainAction.SelectServer -> updateSelectedGuid(action.guid)
            is MainAction.RemoveServer -> removeServerAndRefresh(action.guid)
            is MainAction.Search -> filterConfig(action.query)
            is MainAction.ImportBatchConfig -> importBatchConfig(action.configText)
            is MainAction.TelegramAdd -> telegramAdd(action.text)
            MainAction.TelegramTestAll -> telegramTestAll()
            is MainAction.TelegramRemove -> telegramRemove(action.id)
            MainAction.TelegramRemoveAll -> telegramRemoveAll()
            MainAction.LocateHandled -> consumeLocateTarget()
            MainAction.SlowSlideHandled -> _uiState.update { it.copy(slowSlide = false) }
            MainAction.AutoSelectHandled -> _uiState.update { it.copy(autoSelectGuid = null) }
            is MainAction.LocalTestSetSaveAll -> {
                LocalTestManager.setSaveAllEnabled(action.enabled)
                _uiState.update { it.copy(localTest = it.localTest.copy(saveAll = action.enabled)) }
            }
            is MainAction.LocalTestToggleSelect -> _uiState.update { st ->
                val sel = st.localTest.selectedGuids
                st.copy(localTest = st.localTest.copy(selectedGuids = if (action.guid in sel) sel - action.guid else sel + action.guid))
            }
            is MainAction.LocalTestToggleProxySelect -> _uiState.update { st ->
                val sel = st.localTest.selectedProxyIds
                st.copy(localTest = st.localTest.copy(selectedProxyIds = if (action.id in sel) sel - action.id else sel + action.id))
            }
            MainAction.LocalTestClearSelection -> clearLocalTestSelection()
            MainAction.LocalTestSaveSelected -> saveSelectedToCollection()
            is MainAction.ShareAsLocal -> viewModelScope.launch(ioDispatcher) {
                shareLinkAsLocal(AngConfigManager.shareLinks(listOf(action.guid)).firstOrNull())
            }
            is MainAction.TelegramShareAsLocal -> shareLinkAsLocal(
                TelegramProxyStore.load().firstOrNull { it.id == action.id }?.link
            )
            is MainAction.TelegramShowQRCode -> viewModelScope.launch(ioDispatcher) {
                val bitmap = runCatching { QRCodeDecoder.createQRCode(action.link) }.getOrNull()
                _uiState.update { it.copy(shareQRCodeBitmap = bitmap) }
            }
            MainAction.LocalTestToggleServer -> toggleLocalTestServer()
            is MainAction.LocalTestFetch -> localTestFetch(action.address)
            MainAction.LocalTestMoveGreenToMain -> localTestMoveGreenToMain()
            is MainAction.LocalTestOpenChat -> openChat(action.ip)
            MainAction.LocalTestCloseChat -> closeChat()
            is MainAction.LocalTestSendText -> sendChat(ChatPayload("text", action.text.trim()))
            is MainAction.LocalTestSendImage -> sendChat(ChatPayload("image", "", action.base64))
            MainAction.LocalTestPickConfig -> viewModelScope.launch(ioDispatcher) {
                val configs = LocalTestManager.ownerConfigs()
                if (configs.isEmpty()) toastError(R.string.local_test_nothing_to_share)
                else _uiState.update { it.copy(localTest = it.localTest.copy(configPicker = configs)) }
            }
            MainAction.LocalTestPickConfigDismiss ->
                _uiState.update { it.copy(localTest = it.localTest.copy(configPicker = null)) }
            is MainAction.LocalTestSendConfig -> viewModelScope.launch(ioDispatcher) {
                _uiState.update { it.copy(localTest = it.localTest.copy(configPicker = null)) }
                val link = AngConfigManager.shareLinks(listOf(action.guid)).firstOrNull()
                if (link.isNullOrBlank()) toastError(R.string.local_test_nothing_to_share)
                else sendChat(ChatPayload("config", link))
            }
            is MainAction.LocalTestAddReceived -> addReceivedConfigs(action.text)
            is MainAction.LocalTestSendFile -> sendFile(action.uri)
            is MainAction.LocalTestDownloadFile -> downloadFile(action.ref)
            is MainAction.LocalTestSaveFile -> saveFile(action.ref, action.uri)
            is MainAction.LocalTestOpenProfile -> openProfile(action.ip)
            MainAction.LocalTestCloseProfile -> closeProfile()
            is MainAction.LocalTestSaveProfileName -> updateMyProfile { LocalProfileStore.saveName(action.name); true }
            is MainAction.LocalTestSetAvatar -> updateMyProfile {
                LocalProfileStore.saveAvatar(getApplication<Application>(), action.uri).also { if (!it) toastError(R.string.toast_failure) }
            }
            MainAction.LocalTestClearAvatar -> updateMyProfile { LocalProfileStore.clearAvatar(getApplication<Application>()); true }
            is MainAction.LocalTestSetBanner -> updateMyProfile {
                when (LocalProfileStore.saveBanner(getApplication<Application>(), action.uri)) {
                    BannerResult.OK -> true
                    BannerResult.TOO_LARGE -> { toastError(R.string.local_profile_banner_too_large); false }
                    BannerResult.UNSUPPORTED -> { toastError(R.string.local_profile_banner_unsupported); false }
                    BannerResult.FAILED -> { toastError(R.string.toast_failure); false }
                }
            }
            MainAction.LocalTestClearBanner -> updateMyProfile { LocalProfileStore.clearBanner(getApplication<Application>()); true }
            MainAction.LocalTestDisconnect -> disconnectFromServer(reportLost = false)
            MainAction.UpdateConfig -> updateConfig(manualAddress = null)
            is MainAction.UpdateConfigWithAddress -> updateConfig(manualAddress = action.address)
            MainAction.UpdateConfigAddressDismissed ->
                _uiState.update { it.copy(localTest = it.localTest.copy(askServerAddress = false)) }
            is MainAction.ShareQRCode -> {
                val bitmap = dataSource.share2QRCode(action.guid)
                _uiState.update { it.copy(shareQRCodeBitmap = bitmap) }
            }

            MainAction.DismissQRCodeDialog -> {
                _uiState.update { it.copy(shareQRCodeBitmap = null) }
            }

            MainAction.ToggleService,
            MainAction.TestCurrentServer,
            MainAction.ImportQRcode,
            MainAction.ImportClipboard,
            MainAction.ImportConfigLocal,
            MainAction.ImportNpvFile,
            is MainAction.ImportManually,
            MainAction.RestartService,
            MainAction.LocateSelectedServer,
            is MainAction.EditServer,
            is MainAction.ShareClipboard,
            is MainAction.ShareFullContent,
            is MainAction.OpenSubscriptionLink -> {
                // Handled by Activity via its onAction lambda
            }
        }
    }

    // ---------- Initialization ----------
    fun initialize() {
        viewModelScope.launch(preloadDispatcher) {
            try {
                initialPageReady.await()
                delay(32)
                dataSource.initAssets()
                dataSource.syncSubscriptions()
                if (LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))) {
                    setupGroupTab(forceRefresh = true)
                }
                val savedAddress = LocalTestManager.savedAddress()
                val saveAll = LocalTestManager.saveAllEnabled()
                _uiState.update { it.copy(localTest = it.localTest.copy(savedAddress = savedAddress, saveAll = saveAll)) }
                if (TelegramProxyStore.ensureGroup(dataSource.getString(R.string.telegram_tab_title))) {
                    setupGroupTab(forceRefresh = true)
                }
                telegramLoadSaved()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Main background initialization failed", error)
            }
        }
    }

    fun refreshUiSettings() {
        _uiState.update {
            it.copy(
                confirmRemove = dataSource.getConfirmRemove(),
                doubleColumnDisplay = dataSource.getDoubleColumnDisplay()
            )
        }
    }

    // ---------- Group & server loading ----------
    private suspend fun buildServersCache(guids: List<String>): List<ServersCache> =
        guids.mapNotNull { guid ->
            currentCoroutineContext().ensureActive()
            val profile = dataSource.decodeServerConfig(guid) ?: return@mapNotNull null
            val affiliation = dataSource.decodeAffiliationInfo(guid)
            ServersCache(
                guid = guid,
                profile = profile.copy(),
                testDelayMillis = affiliation?.testDelayMillis ?: 0L,
                testDownloadBytesPerSec = affiliation?.testDownloadBytesPerSec ?: 0L,
            )
        }

    private suspend fun loadGroup(
        groupId: String,
        forceRefresh: Boolean = false
    ): List<ServersCache> {
        val loadMutex = groupLoadMutexes.computeIfAbsent(groupId) { Mutex() }
        return loadMutex.withLock {
            if (!forceRefresh) {
                cacheMutex.withLock { groupDataCache[groupId]?.let { return@withLock it } }
            }
            val servers = buildServersCache(dataSource.getServerGuidList(groupId))
            currentCoroutineContext().ensureActive()
            cacheMutex.withLock { groupDataCache[groupId] = servers }
            servers
        }
    }

    private fun applyKeywordFilter(servers: List<ServersCache>): List<ServersCache> {
        val keyword = keywordFilter.trim()
        if (keyword.isEmpty()) return servers
        val regex = try {
            Regex(keyword, RegexOption.IGNORE_CASE)
        } catch (_: PatternSyntaxException) {
            return servers
        }
        return servers.filter { cache ->
            val profile = cache.profile
            profile.remarks.matchesPattern(regex, keyword) ||
                    profile.description.orEmpty().matchesPattern(regex, keyword) ||
                    profile.server.orEmpty().matchesPattern(regex, keyword) ||
                    (profile.npvSource ?: profile.configType.name).matchesPattern(regex, keyword)
        }
    }

    private fun updateGroupUi(groupId: String, servers: List<ServersCache>) {
        val filteredServers = applyKeywordFilter(servers).let {
            if (groupId.isEmpty()) sortForDefaultTab(it, _uiState.value.defaultTabSort) else it
        }
        mutableServerGroupState(groupId).value = ServerGroupUiState(
            servers = filteredServers,
            rows = buildServerRows(groupId, filteredServers)
        )
    }

    private fun buildServerRows(groupId: String, servers: List<ServersCache>): List<ServerRowUiModel> {
        val subscriptionRemarks = if (groupId.isEmpty()) {
            servers.asSequence()
                .map { it.profile.subscriptionId }
                .filter { it.isNotEmpty() }
                .distinct()
                .associateWith { subscriptionId ->
                    dataSource.getSubscriptionItem(subscriptionId)?.remarks.orEmpty()
                }
        } else {
            emptyMap()
        }
        return servers.map { server ->
            buildServerRowUiModel(
                server = server,
                subscriptionRemarks = subscriptionRemarks[server.profile.subscriptionId].orEmpty()
            )
        }
    }

    fun getSubscriptions(): List<SubscriptionCache> = dataSource.getSubscriptions()

    private fun resolveSelectedGroup(groups: List<GroupMapItem>): String {
        val current = uiState.value.selectedGroupId
        val resolved = when {
            groups.isEmpty() -> ""
            groups.any { it.id == current } -> current
            else -> groups.first().id
        }
        if (resolved != current) {
            dataSource.setSelectedSubscriptionId(resolved)
        }
        return resolved
    }

    private fun radialPreloadOrder(groups: List<GroupMapItem>, selectedIndex: Int): List<String> {
        if (groups.isEmpty()) return emptyList()
        val result = ArrayList<String>((groups.size - 1).coerceAtLeast(0))
        for (distance in 1 until groups.size) {
            val right = selectedIndex + distance
            val left = selectedIndex - distance
            if (right in groups.indices) result += groups[right].id
            if (left in groups.indices) result += groups[left].id
        }
        return result
    }

    fun setupGroupTab(forceRefresh: Boolean = false): Job {
        setupGroupJob?.cancel()
        preloadJob?.cancel()
        selectedGroupLoadJob?.cancel()

        return viewModelScope.launch(ioDispatcher) {
            try {
                if (forceRefresh) {
                    cacheMutex.withLock { groupDataCache.clear() }
                }
                // Fixed tabs only: Home, Default (every config of every subscription in one list),
                // Telegram and Local test. Subscriptions are no longer tabs of their own.
                val storedGroups = dataSource.getSubscriptions().associateBy { it.guid }
                fun fixedGroup(id: String, fallbackRes: Int): GroupMapItem? {
                    val remarks = storedGroups[id]?.subscription?.remarks?.takeIf { it.isNotBlank() }
                        ?: dataSource.getString(fallbackRes)
                    return GroupMapItem(id = id, remarks = remarks)
                }
                val groups = listOfNotNull(
                    GroupMapItem(id = HOME_GROUP_ID, remarks = dataSource.getString(R.string.home_tab_title)),
                    GroupMapItem(id = "", remarks = dataSource.getString(R.string.default_tab_title)),
                    fixedGroup(TelegramProxyStore.GROUP_ID, R.string.telegram_tab_title),
                    fixedGroup(LocalTestManager.GROUP_ID, R.string.local_test_title),
                )
                val selectedGroup = resolveSelectedGroup(groups)
                val validIds = groups.mapTo(HashSet()) { it.id }
                groupUiFlows.keys.removeAll { it !in validIds }
                groupServerFlows.keys.removeAll { it !in validIds }
                groupLoadMutexes.keys.removeAll { it !in validIds }

                _uiState.update {
                    it.copy(
                        groups = groups,
                        selectedGroupId = selectedGroup,
                        selectedGuid = dataSource.getSelectServer(),
                    )
                }
                refreshActiveConfig()
                groups.forEach { mutableServerGroupState(it.id) }

                if (groups.isEmpty()) {
                    cacheMutex.withLock { groupDataCache.clear() }
                    return@launch
                }

                val selectedServers = loadGroup(selectedGroup, forceRefresh)
                updateGroupUi(selectedGroup, selectedServers)

                if (!initialPageReady.isCompleted) {
                    initialPageReady.complete(Unit)
                }

                val selectedIndex =
                    groups.indexOfFirst { it.id == selectedGroup }.coerceAtLeast(0)
                val preloadOrder = radialPreloadOrder(groups, selectedIndex)
                preloadJob = viewModelScope.launch(preloadDispatcher) {
                    preloadOrder.forEach { groupId ->
                        ensureActive()
                        delay(32)
                        val servers = loadGroup(groupId, forceRefresh)
                        updateGroupUi(groupId, servers)
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to set up group tabs", error)
            } finally {
                if (!initialPageReady.isCompleted) {
                    initialPageReady.complete(Unit)
                }
            }
        }.also { setupGroupJob = it }
    }

    // ---------- Business actions (coroutine-based) ----------
    private fun importBatchConfig(configText: String) {
        // Telegram MTProto links are not v2ray profiles: they go to the Telegram tab.
        if (TelegramProxyManager.containsProxy(configText)) {
            telegramAdd(configText)
            return
        }
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val (count, countSub) = dataSource.importBatchConfig(
                        configText, importTargetGroupId(), true
                    )
                    when {
                        count > 0 -> {
                            toast(dataSource.getString(R.string.title_import_config_count, count))
                            setupGroupTab(forceRefresh = true)
                        }

                        countSub > 0 -> setupGroupTab(forceRefresh = true)
                        else -> toastError(R.string.toast_failure)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Failed to import batch config", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun importConfigViaSub(subId: String) {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val result = if (subId.isEmpty()) {
                        dataSource.updateConfigViaSubAll()
                    } else {
                        val item = dataSource.getSubscriptionItem(subId) ?: return@withContext
                        dataSource.updateConfigViaSub(SubscriptionCache(subId, item))
                    }
                    when {
                        result.successCount + result.failureCount + result.skipCount == 0 ->
                            toast(R.string.title_update_subscription_no_subscription)

                        result.successCount > 0 && result.failureCount + result.skipCount == 0 ->
                            toast(
                                getQuantityString(
                                    R.plurals.title_update_config_count,
                                    result.configCount,
                                    result.configCount,
                                )
                            )

                        else ->
                            toast(dataSource.getString(R.string.title_update_subscription_result, result.configCount, result.successCount, result.failureCount, result.skipCount))
                    }
                    if (result.configCount > 0) {
                        setupGroupTab(forceRefresh = true)
                        refreshSelectedGuid()
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Subscription update failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun exportAllAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val groupId = uiState.value.selectedGroupId
                    val list = if (groupId.isEmpty() && keywordFilter.isEmpty()) {
                        dataSource.getServerGuidList("")
                    } else {
                        currentServers().map { it.guid }
                    }
                    val ret = dataSource.shareNonCustomConfigsToClipboard(list)
                    if (ret > 0) {
                        toast(dataSource.getString(R.string.title_export_config_count, ret))
                    } else {
                        toastError(R.string.toast_failure)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Export failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeAllServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val count =
                        if (uiState.value.selectedGroupId.isEmpty() && keywordFilter.isEmpty()) {
                            dataSource.removeAllServer()
                        } else {
                            val guids = currentServers().map { it.guid }
                            guids.forEach { dataSource.removeServer(it) }
                            guids.size
                        }
                    viewModelScope.launch(ioDispatcher) {
                        cacheMutex.withLock { groupDataCache.clear() }
                    }
                    setupGroupTab(forceRefresh = true)
                    toast(dataSource.getString(R.string.title_del_config_count, count))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete all failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeDuplicateServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val seen = HashSet<ProfileItem>()
                    val duplicates = ArrayList<String>()
                    currentServers().forEach { server ->
                        val profile = server.profile
                        if (!profile.configType.isComplexType()) {
                            val identity = profile.duplicateIdentity()
                            if (!seen.add(identity)) duplicates += server.guid
                        }
                    }
                    duplicates.forEach { dataSource.removeServer(it) }
                    setupGroupTab(forceRefresh = true)
                    toast(dataSource.getString(R.string.title_del_duplicate_config_count, duplicates.size))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete duplicate failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeInvalidServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val count = removeInvalidServerInternal()
                    viewModelScope.launch(ioDispatcher) {
                        cacheMutex.withLock { groupDataCache.clear() }
                        setupGroupTab(forceRefresh = true)
                    }
                    toast(dataSource.getString(R.string.title_del_config_count, count))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete invalid failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeInvalidServerInternal(): Int {
        val visibleServersOnly =
            uiState.value.selectedGroupId.isNotEmpty() || keywordFilter.isNotBlank()
        return if (visibleServersOnly) {
            currentServers().sumOf { server ->
                dataSource.removeInvalidServerByGuid(server.guid)
            }
        } else {
            dataSource.removeInvalidServersInGroup("")
        }
    }

    private fun sortByTestResultsAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    sortByTestResultsInternal()
                    cacheMutex.withLock { groupDataCache.clear() }
                    setupGroupTab(forceRefresh = true)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Sort by test results failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun sortByTestResultsInternal() {
        val subs = if (uiState.value.selectedGroupId.isEmpty()) {
            dataSource.getSubsList()
        } else {
            listOf(uiState.value.selectedGroupId)
        }
        subs.forEach { dataSource.sortByTestResultsForSub(it) }
    }

    fun subscriptionIdChanged(id: String) {
        if (_uiState.value.groups.none { it.id == id }) return
        mutableServerGroupState(id)
        if (uiState.value.selectedGroupId != id) {
            dataSource.setSelectedSubscriptionId(id)
            _uiState.update { it.copy(selectedGroupId = id) }
        }
        selectedGroupLoadJob?.cancel()
        selectedGroupLoadJob = viewModelScope.launch(ioDispatcher) {
            try {
                updateGroupUi(id, loadGroup(id))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to load selected group: $id", error)
            }
        }
    }

    fun reloadServerList() {
        val groupId = uiState.value.selectedGroupId
        selectedGroupLoadJob?.cancel()
        selectedGroupLoadJob = viewModelScope.launch(ioDispatcher) {
            updateGroupUi(groupId, loadGroup(groupId, forceRefresh = true))
        }
    }

    fun reloadAllGroups(groupIds: List<String>) {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch(preloadDispatcher) {
            val selected = uiState.value.selectedGroupId
            val order = buildList {
                if (selected in groupIds) add(selected)
                addAll(groupIds.filter { it != selected })
            }
            order.forEachIndexed { index, groupId ->
                ensureActive()
                if (index > 0) delay(32)
                updateGroupUi(groupId, loadGroup(groupId, forceRefresh = true))
            }
        }
    }

    fun filterConfig(keyword: String) {
        if (keyword == keywordFilter) return
        keywordFilter = keyword
        filterJob?.cancel()
        filterJob = viewModelScope.launch(defaultDispatcher) {
            delay(300)
            val snapshot = cacheMutex.withLock { groupDataCache.toMap() }
            ensureActive()
            snapshot.forEach { (groupId, servers) ->
                ensureActive()
                updateGroupUi(groupId, servers)
            }
        }
    }

    fun updateSelectedGuid(guid: String) {
        dataSource.setSelectServer(guid)
        _uiState.update { it.copy(selectedGuid = guid) }
        refreshActiveConfig()
    }

    fun refreshSelectedGuid() {
        _uiState.update { it.copy(selectedGuid = dataSource.getSelectServer()) }
        refreshActiveConfig()
    }

    /** Group that imported or newly created profiles go to; Home owns none, so they land in the default group. */
    fun importTargetGroupId(): String =
        uiState.value.selectedGroupId.takeUnless { it == HOME_GROUP_ID }.orEmpty()

    private fun resubscribeSpeed() {
        if (speedUpdatesWanted) dataSource.setSpeedUpdates(true)
    }

    /** The daemon moved the core to [guid] (Auto connection); mirror it without restarting anything. */
    private fun onAutoSwitched(guid: String) {
        _uiState.update { it.copy(selectedGuid = guid) }
        refreshActiveConfig()
        viewModelScope.launch(ioDispatcher) {
            val name = dataSource.decodeServerConfig(guid)?.remarks.orEmpty()
            toast(dataSource.getString(R.string.auto_connection_switched, name))
        }
    }

    /** Reloads name and last test result of the selected profile for the Home page, off the main thread. */
    private fun refreshActiveConfig() {
        activeConfigJob?.cancel()
        activeConfigJob = viewModelScope.launch(ioDispatcher) {
            val guid = dataSource.getSelectServer()
            val profile = guid?.let { dataSource.decodeServerConfig(it) }
            val active = if (guid == null || profile == null) null else ActiveConfigUi(
                guid = guid,
                name = profile.remarks,
                delayMillis = dataSource.decodeAffiliationInfo(guid)?.testDelayMillis ?: 0L,
            )
            _uiState.update { it.copy(activeConfig = active) }
        }
    }

    fun removeServerAndRefresh(guid: String) {
        if (guid == uiState.value.selectedGuid) {
            toast(R.string.toast_action_not_allowed)
            return
        }
        viewModelScope.launch(ioDispatcher) {
            dataSource.removeServer(guid)
            cacheMutex.withLock { groupDataCache.clear() }
            setupGroupTab(forceRefresh = true).join()
        }
    }

    fun moveServer(groupId: String, fromPosition: Int, toPosition: Int) {
        val groupState = mutableServerGroupState(groupId).value
        val servers = groupState.servers.toMutableList()
        if (!servers.moveItem(fromPosition, toPosition)) return
        val rows = groupState.rows.toMutableList()
        rows.moveItem(fromPosition, toPosition)
        val guids = servers.map { it.guid }
        mutableServerGroupState(groupId).value = ServerGroupUiState(servers, rows)
        // A drag emits several moves; serialize writes so an older order cannot overwrite a newer one.
        val previousPersistenceJob = serverOrderPersistenceJobs[groupId]
        serverOrderPersistenceJobs[groupId] = viewModelScope.launch(ioDispatcher) {
            previousPersistenceJob?.join()
            dataSource.encodeServerList(guids, groupId)
            cacheMutex.withLock { groupDataCache[groupId] = servers }
        }
    }

    // ---------- Testing ----------
    fun cancelAllPing() {
        if (autoChangePending) {
            autoChangePending = false
            _uiState.update { it.copy(autoChanging = false) }
        }
        bulkTestJob?.cancel()
        bulkTestJob = null
        testRequests.cancelBulk()
        testRequests.invalidateCurrent()
        cancelPendingTestResults()
        resetTestStatus()
        dataSource.cancelAllPing()
    }

    private fun resetTestStatus() {
        _uiState.update {
            it.copy(
                isTesting = testRequests.isTesting,
                status = if (testRequests.isTesting) MainStatus.Testing
                else if (it.isRunning) MainStatus.Connected else MainStatus.Disconnected
            )
        }
    }

    fun testAllRealPing(onlyTcp: Boolean = false, onlyGuids: List<String> = emptyList()) {
        cancelAllPing()
        val groupId = uiState.value.selectedGroupId
        val servers = currentServers()
        // With an explicit list the group may still be loading, so the visible list can be empty.
        if (servers.isEmpty() && onlyGuids.isEmpty()) {
            return
        }
        val serverGuids = onlyGuids.ifEmpty { servers.map { it.guid } }
        val onlyGuidSet = onlyGuids.toHashSet()
        mutableServerGroupState(groupId).update { current ->
            current.copy(
                servers = current.servers.map { server ->
                    if (server.testDelayMillis == 0L || (onlyGuidSet.isNotEmpty() && server.guid !in onlyGuidSet)) server
                    else server.copy(testDelayMillis = 0L)
                },
                rows = current.rows.map { row ->
                    if (row.testDelayMillis == 0L || (onlyGuidSet.isNotEmpty() && row.guid !in onlyGuidSet)) row
                    else row.copy(testDelayMillis = 0L)
                }
            )
        }
        val request = testRequests.beginBulk(groupId)
        val message = TestServiceMessage(
            key = AppConfig.MSG_MEASURE_CONFIG_START,
            subscriptionId = groupId,
            serverGuids = if (onlyGuids.isNotEmpty() || keywordFilter.isNotEmpty()) serverGuids else emptyList(),
            onlyTcp = onlyTcp,
            // Real-ping tests also measure download speed; the quick TCP test stays quick.
            measureDownload = !onlyTcp,
        )
        _uiState.update {
            it.copy(
                isTesting = true,
                status = MainStatus.Testing
            )
        }
        bulkTestJob = viewModelScope.launch {
            withContext(ioDispatcher) {
                dataSource.clearAllTestDelayResults(serverGuids)
                val resetGuids = serverGuids.toHashSet()
                cacheMutex.withLock {
                    groupDataCache[groupId]?.let { cached ->
                        groupDataCache[groupId] = cached.map { server ->
                            if (server.guid !in resetGuids || server.testDelayMillis == 0L) server
                            else server.copy(testDelayMillis = 0L)
                        }
                    }
                }
            }
            dataSource.sendMsg2TestService(message, request.id)
        }
    }

    /** Remembers the Default tab's order and re-applies it to the cached list, off the main thread. */
    private fun setDefaultTabSort(mode: DefaultTabSort) {
        if (mode == _uiState.value.defaultTabSort) return
        dataSource.setDefaultTabSort(mode.storageValue)
        _uiState.update { it.copy(defaultTabSort = mode) }
        viewModelScope.launch(defaultDispatcher) {
            val cached = cacheMutex.withLock { groupDataCache[""] } ?: return@launch
            updateGroupUi("", cached)
        }
    }

    // ---------- Auto change ----------
    private var autoChangeJob: Job? = null

    /** Set once the full test of Auto change is running; the finish of that test connects to the best download. */
    private var autoChangePending = false

    private fun autoChange() {
        if (_uiState.value.autoChanging) {
            cancelAutoChange()
            cancelAllPing()
            return
        }
        _uiState.update { it.copy(autoChanging = true) }
        // Ranked by download from the start, so the list the test finish reloads is already in that order.
        setDefaultTabSort(DefaultTabSort.DOWNLOAD)
        autoChangeJob = viewModelScope.launch {
            try {
                // Only when this phone is connected to a Local test server there is something to fetch.
                if (_uiState.value.localTest.connectedServer.isNotEmpty()) {
                    updateConfig(null)
                    updateConfigJob?.join()
                }
                subscriptionIdChanged("")
                testAllRealPing()
                if (testRequests.isTesting) {
                    autoChangePending = true
                } else {
                    // Nothing to test (empty list).
                    cancelAutoChange()
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "Auto change failed before the test started", e)
                cancelAutoChange()
                toastError(R.string.toast_failure)
            }
        }
    }

    private fun cancelAutoChange() {
        autoChangeJob?.cancel()
        autoChangeJob = null
        autoChangePending = false
        _uiState.update { it.copy(autoChanging = false) }
    }

    /** Called when the full test of Auto change has finished: connects to the config with the best download. */
    private fun connectBestDownload() {
        viewModelScope.launch(ioDispatcher) {
            val localTest = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).toHashSet()
            val ranked = dataSource.getServerGuidList("")
                .filter { it !in localTest }
                .distinct()
                .mapNotNull { guid ->
                    dataSource.decodeAffiliationInfo(guid)?.let {
                        RankedServer(guid, it.testDelayMillis, it.testDownloadBytesPerSec)
                    }
                }
            val best = ServerRanking.bestDownload(ranked)
            if (best == null) {
                _uiState.update { it.copy(autoChanging = false) }
                toastError(R.string.auto_change_no_result)
                return@launch
            }
            val name = dataSource.decodeServerConfig(best)?.remarks.orEmpty()
            updateSelectedGuid(best)
            _uiState.update { it.copy(autoChanging = false, connectAfterAutoChange = true) }
            toast(dataSource.getString(R.string.auto_change_connected, name))
        }
    }

    private fun cancelPendingTestResults() {
        testResultFlushJob?.cancel()
        testResultFlushJob = null
        pendingTestResults.clear()
    }

    fun testCurrentServerRealPing() {
        if (!uiState.value.isRunning) return
        val requestId = testRequests.beginCurrent()
        _uiState.update { it.copy(isTesting = true, status = MainStatus.Testing) }
        dataSource.testCurrentServerRealPing(requestId)
    }

    private fun onTestsFinished(requestId: String) {
        val finished = testRequests.completeBulk(requestId) ?: return
        resetTestStatus()
        if (autoChangePending) {
            autoChangePending = false
            connectBestDownload()
        }
        viewModelScope.launch(ioDispatcher) {
            cacheMutex.withLock { groupDataCache.clear() }
            reloadAllGroups(_uiState.value.groups.map { it.id })
        }
    }

    // ---------- Local test ----------
    // The local server always hands out every config and proxy of the owner (live, so new ones appear too).
    private val localShareServer = LocalShareServer(
        ownerLinks = { LocalTestManager.ownerAllLinks() },
        onConfigsReceived = { links -> onLocalTestLinksReceived(links) },
        onClientSeen = { ip -> onLocalClientSeen(ip) },
        onChatMessage = { ip, payload -> onChatFromClient(ip, payload) },
        fileDir = java.io.File(getApplication<Application>().cacheDir, "local_files"),
    )

    // ---------- Local chat ----------
    private val chatLock = Any()
    private val chats = HashMap<String, MutableList<ChatMessageUi>>()
    private val unread = HashMap<String, Int>()
    private var chatIdCounter = 0L
    private var lastPolledId = 0L
    private var connectedServer = ""
    private var chatJob: Job? = null

    private fun chatPreview(msg: ChatMessageUi): String = when (msg.kind) {
        "image" -> dataSource.getString(R.string.local_test_chat_photo)
        "config" -> dataSource.getString(R.string.local_test_chat_config)
        "file" -> LocalProfileRules.parseFileRef(msg.text)?.name ?: dataSource.getString(R.string.local_test_chat_file)
        else -> msg.text
    }

    private fun addChat(peer: String, kind: String, text: String, image: String?, mine: Boolean) {
        val msg: ChatMessageUi
        val open = _uiState.value.localTest.chatPeer == peer
        synchronized(chatLock) {
            msg = ChatMessageUi(++chatIdCounter, mine, kind, text, image, System.currentTimeMillis())
            val list = chats.getOrPut(peer) { ArrayList() }
            list.add(msg)
            while (list.size > MAX_CHAT_MESSAGES) list.removeAt(0)
            if (!mine && !open) unread[peer] = (unread[peer] ?: 0) + 1
        }
        if (!mine) {
            LocalTestNotifier.notify(getApplication<Application>(), "msg-$peer", peer, chatPreview(msg), chatPeer = peer)
        }
        publishChat()
    }

    /** Rebuilds the device list and the open conversation from the chat store and the server's client list. */
    private fun publishChat() {
        val serverIp = connectedServer.substringBefore(':')
        val clients = localShareServer.knownClients()
        val peers: List<ChatPeerUi>
        val open: List<ChatMessageUi>
        synchronized(chatLock) {
            val ips = LinkedHashSet<String>()
            if (serverIp.isNotEmpty()) ips.add(serverIp)
            ips.addAll(clients.keys)
            ips.addAll(chats.keys)
            peers = ips.map { ip ->
                val isServer = ip == serverIp
                val last = chats[ip]?.lastOrNull()
                ChatPeerUi(
                    ip = ip,
                    isServer = isServer,
                    online = if (isServer) true else (clients[ip]?.let { it < CLIENT_ONLINE_MS } ?: false),
                    lastText = last?.let { chatPreview(it) }.orEmpty(),
                    unread = unread[ip] ?: 0,
                    name = peerProfiles[ip]?.name.orEmpty(),
                    avatar = peerProfiles[ip]?.avatar,
                )
            }.sortedWith(compareByDescending<ChatPeerUi> { it.isServer }.thenByDescending { it.online })
            val peer = _uiState.value.localTest.chatPeer
            open = if (peer == null) emptyList() else chats[peer]?.toList().orEmpty()
        }
        _uiState.update {
            val profilePeer = it.localTest.profilePeer
            it.copy(
                localTest = it.localTest.copy(
                    connectedServer = connectedServer,
                    peers = peers,
                    chatMessages = open,
                    peerProfiles = peerProfiles.toMap(),
                    fileTransfers = receivedFiles.toMap(),
                    profileConfigs = if (profilePeer == null) emptyList() else profileConfigsOf(profilePeer, serverIp),
                )
            )
        }
    }

    /** Sends [payload] to [peer] over whichever side of the connection this phone is on. Blocking: call off the main thread. */
    private fun deliver(peer: String, payload: ChatPayload): Boolean {
        val serverIp = connectedServer.substringBefore(':')
        return when {
            connectedServer.isNotEmpty() && peer == serverIp -> LocalTestManager.postMessage(connectedServer, payload)
            localShareServer.isRunning -> {
                localShareServer.sendTo(peer, payload)
                true
            }
            else -> false
        }
    }

    // ---------- Local test profiles ----------
    /** Devices this phone already sent its profile to in this session. */
    private val profileSentTo = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val peerProfiles = java.util.concurrent.ConcurrentHashMap<String, PeerProfileUi>()

    /** Share links of the connected server, shown on its profile page. */
    @Volatile
    private var serverLinks: List<String> = emptyList()

    init {
        viewModelScope.launch(ioDispatcher) { refreshMyProfile() }
    }

    private fun refreshMyProfile() {
        val app = getApplication<Application>()
        val avatar = LocalProfileStore.avatarFile(app).takeIf { it.exists() }
            ?.let { android.graphics.BitmapFactory.decodeFile(it.path) }
        val banner = LocalProfileStore.bannerFile(app)
        val mine = MyProfileUi(LocalProfileStore.name(), avatar, banner?.let { LocalProfileStore.bannerMime() }, banner?.path, banner?.lastModified() ?: 0L)
        _uiState.update { it.copy(localTest = it.localTest.copy(myProfile = mine)) }
    }

    /** Runs a profile change off the main thread; when it succeeded, shows it and re-sends it to every known device. */
    private fun updateMyProfile(change: () -> Boolean) {
        viewModelScope.launch(ioDispatcher) {
            if (!change()) return@launch
            refreshMyProfile()
            profileSentTo.clear()
            _uiState.value.localTest.peers.forEach { peer ->
                profileSentTo.add(peer.ip)
                sendProfileTo(peer.ip)
            }
        }
    }

    /** Sends this phone's name, avatar and banner to [peer] as silent messages. */
    private fun sendProfileTo(peer: String) {
        viewModelScope.launch(ioDispatcher) {
            val app = getApplication<Application>()
            val name = LocalProfileStore.name()
            val avatar = LocalProfileStore.avatarBase64(app)
            if (name.isNotBlank() || avatar != null) {
                deliver(peer, ChatPayload(LocalProfileRules.KIND_PROFILE, name, avatar))
            }
            val mime = LocalProfileStore.bannerMime()
            val bannerFile = LocalProfileStore.bannerFile(app)
            if (mime != null && bannerFile != null) {
                bannerRefFor(peer, bannerFile, mime)?.let {
                    deliver(peer, ChatPayload(LocalProfileRules.KIND_BANNER, chatGson.toJson(it)))
                }
            }
        }
    }

    private fun receivePeerProfile(peer: String, payload: ChatPayload) {
        viewModelScope.launch(ioDispatcher) {
            val avatar = payload.image?.let { ChatImageCodec.decode(it) }
            val old = peerProfiles[peer]
            peerProfiles[peer] = (old ?: PeerProfileUi()).copy(name = LocalProfileRules.cleanName(payload.text), avatar = avatar)
            // Answer once so both devices know each other.
            if (profileSentTo.add(peer)) sendProfileTo(peer)
            publishChat()
        }
    }

    private val chatGson = com.google.gson.Gson()

    /** References to this device's banner already placed on a server, so it is uploaded once per banner version. */
    private val bannerRefs = java.util.concurrent.ConcurrentHashMap<String, FileRef>()

    /** Puts the banner where [peer] can fetch it (this phone's own server, or the server this phone is connected to). */
    private fun bannerRefFor(peer: String, file: java.io.File, mime: String): FileRef? {
        val serverIp = connectedServer.substringBefore(':')
        val viaServer = connectedServer.isNotEmpty() && peer == serverIp
        val key = "${if (viaServer) connectedServer else "own"}|${file.lastModified()}"
        bannerRefs[key]?.let { cached ->
            if (viaServer || localShareServer.storedFile(cached.id) != null) return cached
        }
        val ref = if (viaServer) LocalTestManager.uploadFile(connectedServer, file, file.name, mime)
        else localShareServer.registerFile(file, file.name, mime)
        if (ref != null) bannerRefs[key] = ref
        return ref
    }

    private fun receivePeerBanner(peer: String, payload: ChatPayload) {
        val ref = LocalProfileRules.parseFileRef(payload.text)?.takeIf { LocalProfileRules.isValidBannerMime(it.mime) } ?: return
        viewModelScope.launch(ioDispatcher) {
            try {
                val safeName = peer.filter { it.isLetterOrDigit() }
                val target = java.io.File(getApplication<Application>().cacheDir, "peer_banner_$safeName${LocalProfileStore.extensionOf(ref.mime)}")
                val stored = localShareServer.storedFile(ref.id)
                val ok = when {
                    stored != null -> { stored.copyTo(target, overwrite = true); true }
                    connectedServer.isNotEmpty() && peer == connectedServer.substringBefore(':') ->
                        LocalTestManager.downloadFile(connectedServer, ref, target)
                    else -> false
                }
                if (!ok) return@launch
                val old = peerProfiles[peer] ?: PeerProfileUi()
                // A new path every time makes the banner view reload even when the file name stays the same.
                peerProfiles[peer] = old.copy(bannerMime = ref.mime, bannerPath = target.path, bannerVersion = System.currentTimeMillis())
                publishChat()
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to store banner of $peer", e)
            }
        }
    }

    // ---------- Files ----------
    private val receivedFiles = java.util.concurrent.ConcurrentHashMap<String, FileTransferUi>()

    private fun publishTransfers() {
        _uiState.update { it.copy(localTest = it.localTest.copy(fileTransfers = receivedFiles.toMap())) }
    }

    private fun setFileSending(sending: Boolean) {
        _uiState.update { it.copy(localTest = it.localTest.copy(fileSending = sending)) }
    }

    /** Sends a picked file (up to 25 MB) to the open chat: it is uploaded to the server and announced as a file message. */
    private fun sendFile(uri: android.net.Uri) {
        val peer = _uiState.value.localTest.chatPeer ?: return
        if (_uiState.value.localTest.fileSending) return
        viewModelScope.launch(ioDispatcher) {
            setFileSending(true)
            try {
                val staged = when (val result = LocalFileStaging.stage(getApplication<Application>(), uri)) {
                    is StageResult.Ok -> result.staged
                    StageResult.TooLarge -> { toastError(R.string.local_test_file_too_large); return@launch }
                    StageResult.Failed -> { toastError(R.string.local_test_file_failed); return@launch }
                }
                val serverIp = connectedServer.substringBefore(':')
                val ref = try {
                    when {
                        connectedServer.isNotEmpty() && peer == serverIp ->
                            LocalTestManager.uploadFile(connectedServer, staged.file, staged.name, staged.mime)
                        localShareServer.isRunning -> localShareServer.registerFile(staged.file, staged.name, staged.mime)
                        else -> null
                    }
                } finally {
                    staged.file.delete()
                }
                val payload = ref?.let { ChatPayload("file", chatGson.toJson(it)) }
                if (payload != null && deliver(peer, payload)) addChat(peer, "file", payload.text, null, mine = true)
                else toastError(R.string.local_test_file_failed)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to send file", e)
                toastError(R.string.local_test_file_failed)
            } finally {
                setFileSending(false)
            }
        }
    }

    /** Fetches a received file into the cache; the chat then offers to save it somewhere. */
    private fun downloadFile(ref: FileRef) {
        val current = receivedFiles[ref.id]
        if (current?.status == FileStatus.DOWNLOADING || current?.status == FileStatus.READY) return
        receivedFiles[ref.id] = FileTransferUi(FileStatus.DOWNLOADING)
        publishTransfers()
        viewModelScope.launch(ioDispatcher) {
            val target = java.io.File(getApplication<Application>().cacheDir, "received/${ref.id}_${ref.name}")
            val ok = try {
                val stored = localShareServer.storedFile(ref.id)
                when {
                    stored != null -> { target.parentFile?.mkdirs(); stored.copyTo(target, overwrite = true); true }
                    connectedServer.isNotEmpty() -> {
                        var lastPublished = 0L
                        LocalTestManager.downloadFile(connectedServer, ref, target) { received ->
                            if (received - lastPublished >= PROGRESS_STEP_BYTES) {
                                lastPublished = received
                                receivedFiles[ref.id] = FileTransferUi(FileStatus.DOWNLOADING, received.toFloat() / ref.size)
                                publishTransfers()
                            }
                        }
                    }
                    else -> false
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to download file", e)
                false
            }
            receivedFiles[ref.id] = if (ok) FileTransferUi(FileStatus.READY, 1f, target.path) else FileTransferUi(FileStatus.FAILED)
            publishTransfers()
            if (!ok) toastError(R.string.local_test_file_failed)
        }
    }

    /** Copies the downloaded file to the place the user picked. */
    private fun saveFile(ref: FileRef, uri: android.net.Uri) {
        val path = receivedFiles[ref.id]?.path ?: return
        viewModelScope.launch(ioDispatcher) {
            try {
                val out = getApplication<Application>().contentResolver.openOutputStream(uri)
                if (out == null) {
                    toastError(R.string.toast_failure)
                    return@launch
                }
                out.use { sink -> java.io.File(path).inputStream().use { it.copyTo(sink) } }
                toast(R.string.local_test_file_saved)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to save file", e)
                toastError(R.string.toast_failure)
            }
        }
    }

    private fun openProfile(ip: String) {
        _uiState.update { it.copy(localTest = it.localTest.copy(profilePeer = ip)) }
        publishChat()
        val server = connectedServer
        if (server.isNotEmpty() && ip == server.substringBefore(':')) {
            viewModelScope.launch(ioDispatcher) {
                val text = LocalTestManager.fetchLinks(server, attempts = 1) ?: return@launch
                serverLinks = LocalShareServer.parseLinks(LocalTestManager.splitReceived(text).second)
                publishChat()
            }
        }
    }

    private fun closeProfile() {
        _uiState.update { it.copy(localTest = it.localTest.copy(profilePeer = null, profileConfigs = emptyList())) }
    }

    /** Configs [peer] shared in the chat, plus the connected server's own list when [peer] is that server. */
    private fun profileConfigsOf(peer: String, serverIp: String): List<ProfileConfigUi> {
        val shared = synchronized(chatLock) {
            chats[peer].orEmpty().filter { it.kind == "config" && !it.mine }.flatMap { LocalShareServer.parseLinks(it.text) }
        }
        val fromServer = if (peer == serverIp) serverLinks else emptyList()
        return (shared + fromServer).distinct().map { ProfileConfigUi(it, LocalProfileRules.linkName(it), it.substringBefore("://").uppercase()) }
    }

    private fun openChat(ip: String) {
        synchronized(chatLock) { unread.remove(ip) }
        if (profileSentTo.add(ip)) sendProfileTo(ip)
        _uiState.update { it.copy(localTest = it.localTest.copy(chatPeer = ip)) }
        publishChat()
    }

    private fun closeChat() {
        _uiState.update { it.copy(localTest = it.localTest.copy(chatPeer = null, chatMessages = emptyList(), configPicker = null)) }
        publishChat()
    }

    private fun onChatFromClient(ip: String, payload: ChatPayload) = handleIncoming(ip, payload)

    /** Profile and banner messages update the sender's profile silently; everything else lands in the chat. */
    private fun handleIncoming(peer: String, payload: ChatPayload) {
        when (payload.kind) {
            LocalProfileRules.KIND_PROFILE -> receivePeerProfile(peer, payload)
            LocalProfileRules.KIND_BANNER -> receivePeerBanner(peer, payload)
            else -> {
                // A config pasted as plain text gets the config card too.
                val detected = LocalProfileRules.detectConfig(payload)
                addChat(peer, detected.kind, detected.text, detected.image, mine = false)
            }
        }
    }

    /** Sends [payload] to the open chat's device: to the server by HTTP, or to a client through the server's outbox. */
    private fun sendChat(raw: ChatPayload) {
        val peer = _uiState.value.localTest.chatPeer ?: return
        if (raw.kind != "image" && raw.text.isBlank()) return
        // A config typed or pasted without the Config button is still sent, and shown, as a config.
        val payload = LocalProfileRules.detectConfig(raw)
        viewModelScope.launch(ioDispatcher) {
            val sent = deliver(peer, payload)
            if (sent) addChat(peer, payload.kind, payload.text, payload.image, mine = true)
            else toastError(dataSource.getString(R.string.local_test_server_unreachable, peer))
        }
    }

    /** Keeps polling the connected server for messages and refreshes the device list while a server or connection exists. */
    private fun ensureChatLoop() {
        if (chatJob?.isActive == true) return
        chatJob = viewModelScope.launch(ioDispatcher) {
            var failures = 0
            while (isActive) {
                val server = connectedServer
                if (server.isNotEmpty()) {
                    // Introduce this phone to the server once per connection; it answers with its own profile.
                    if (profileSentTo.add(server.substringBefore(':'))) sendProfileTo(server.substringBefore(':'))
                    val messages = LocalTestManager.pollMessages(server, lastPolledId)
                    if (messages == null) {
                        failures++
                        if (failures >= POLL_FAILURES_BEFORE_LOST) {
                            failures = 0
                            disconnectFromServer(reportLost = true)
                        }
                    } else {
                        failures = 0
                        val serverIp = server.substringBefore(':')
                        messages.forEach {
                            lastPolledId = maxOf(lastPolledId, it.id)
                            handleIncoming(serverIp, ChatPayload(it.kind, it.text, it.image))
                        }
                    }
                }
                publishChat()
                if (connectedServer.isEmpty() && !localShareServer.isRunning) break
                delay(CHAT_POLL_INTERVAL_MS)
            }
        }
    }

    private fun connectedToServer(address: String) {
        val normalized = LocalTestManager.normalizeAddress(address) ?: return
        if (connectedServer != normalized) lastPolledId = 0L
        connectedServer = normalized
        publishChat()
        ensureChatLoop()
    }

    private fun disconnectFromServer(reportLost: Boolean) {
        profileSentTo.clear()
        serverLinks = emptyList()
        val lost = connectedServer
        connectedServer = ""
        lastPolledId = 0L
        if (_uiState.value.localTest.chatPeer == lost.substringBefore(':')) closeChat()
        publishChat()
        if (reportLost && lost.isNotEmpty()) toastError(dataSource.getString(R.string.local_test_server_unreachable, lost))
    }

    /** Chat card button: imports the received links into the Default tab (Telegram proxies into the Telegram tab). */
    private fun addReceivedConfigs(text: String) {
        viewModelScope.launch(ioDispatcher) {
            try {
                val before = dataSource.getServerGuidList("").toHashSet()
                val (proxies, configText) = LocalTestManager.splitReceived(text)
                val count = if (configText.isBlank()) 0
                else dataSource.importBatchConfig(configText, "", true).first
                val proxyCount = receiveProxies(proxies)
                setupGroupTab(forceRefresh = true).join()
                if (count + proxyCount > 0) toast(dataSource.getString(R.string.title_import_config_count, count + proxyCount))
                else toastError(R.string.local_test_nothing_received)
                val added = dataSource.getServerGuidList("").filter { it !in before }
                if (added.isNotEmpty()) showNewConfigs(added)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to add received configs", e)
                toastError(R.string.toast_failure)
            }
        }
    }

    /** Leaves the chat for the Default tab, colours the new configs and scrolls to the first one. */
    private suspend fun showNewConfigs(guids: List<String>) {
        withContext(Dispatchers.Main) {
            closeProfile()
            closeChat()
            _uiState.update { it.copy(highlightGuids = guids.toHashSet(), slowSlide = true) }
            subscriptionIdChanged(DEFAULT_TAB_ID)
            _uiState.update { it.copy(locateTarget = LocateTarget(DEFAULT_TAB_ID, guids.first())) }
        }
        viewModelScope.launch {
            kotlinx.coroutines.delay(HIGHLIGHT_DURATION_MS)
            _uiState.update { it.copy(highlightGuids = emptySet()) }
        }
    }

    private val clientNotifiedAt = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** Server side: another device reached this server; tell the owner which IP it was (once per 15 s per device). */
    private fun onLocalClientSeen(ip: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        val last = clientNotifiedAt[ip]
        if (last != null && now - last < CLIENT_NOTIFY_INTERVAL_MS) return
        clientNotifiedAt[ip] = now
        val text = dataSource.getString(R.string.local_test_client_connected, ip)
        LocalTestNotifier.notify(
            getApplication<Application>(),
            "client-$ip",
            dataSource.getString(R.string.local_test_client_connected_title),
            text,
            chatPeer = ip
        )
        toast(text)
    }

    /** Client side: this device reached the server at [address]; tell the user which server and which own IP. */
    private fun notifyConnectedToServer(address: String) {
        val own = LocalTestManager.primaryLanAddress() ?: "?"
        val text = dataSource.getString(R.string.local_test_connected_to_server, address.substringBefore(':'), own)
        LocalTestNotifier.notify(
            getApplication<Application>(),
            "server",
            dataSource.getString(R.string.local_test_client_connected_title),
            text,
            chatPeer = address.substringBefore(':')
        )
        toast(text)
    }

    private fun onLocalTestLinksReceived(links: List<String>) {
        viewModelScope.launch(ioDispatcher) {
            try {
                val (proxies, configText) = LocalTestManager.splitReceived(links.joinToString("\n"))
                var added = emptyList<String>()
                if (configText.isNotBlank()) {
                    LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))
                    val before = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).toHashSet()
                    dataSource.importBatchConfig(configText, LocalTestManager.GROUP_ID, true)
                    added = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).filter { it !in before }
                }
                handleReceived(proxies, added, testConfigs = false)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to import received configs", e)
            }
        }
    }

    /**
     * Decides where received items go. With "Save all to my collection" on, configs go to the main tab
     * and proxies to the proxy tab. With it off they wait in the Local test tab until the user picks them.
     * Returns how many new items arrived.
     */
    private suspend fun handleReceived(
        proxies: List<TelegramProxyManager.TelegramProxy>,
        freshGuids: List<String>,
        testConfigs: Boolean,
    ): Int {
        if (LocalTestManager.saveAllEnabled()) {
            val proxyCount = receiveProxies(proxies)
            when {
                freshGuids.isNotEmpty() -> deliverReceivedToMain(freshGuids, testThem = testConfigs)
                proxyCount > 0 -> showTelegramTab()
                else -> setupGroupTab(forceRefresh = true).join()
            }
            return freshGuids.size + proxyCount
        }
        val staged = stagePendingProxies(proxies)
        setupGroupTab(forceRefresh = true).join()
        withContext(Dispatchers.Main) {
            // Stay on the Local test tab so the received items can be selected there.
            subscriptionIdChanged(LocalTestManager.GROUP_ID)
            if (testConfigs && freshGuids.isNotEmpty()) testAllRealPing(onlyGuids = freshGuids)
        }
        return freshGuids.size + staged
    }

    private var pendingProxyJob: Job? = null

    /** Keeps received proxies in the Local test tab (not yet saved); returns how many were new. */
    private fun stagePendingProxies(proxies: List<TelegramProxyManager.TelegramProxy>): Int {
        if (proxies.isEmpty()) return 0
        val saved = TelegramProxyStore.load().mapTo(HashSet()) { it.id }
        var added = 0
        _uiState.update { st ->
            val known = st.localTest.pendingProxies.mapTo(HashSet()) { it.proxy.id }
            val fresh = proxies.filter { it.id !in saved && known.add(it.id) }
            added = fresh.size
            st.copy(
                localTest = st.localTest.copy(
                    pendingProxies = st.localTest.pendingProxies +
                        fresh.map { TelegramRow(it, countryCode = ServerCountryResolver.cached(it.server)) }
                )
            )
        }
        if (added > 0) testPendingProxies()
        return added
    }

    private fun testPendingProxies() {
        pendingProxyJob?.cancel()
        pendingProxyJob = viewModelScope.launch(ioDispatcher) {
            val proxies = _uiState.value.localTest.pendingProxies.map { it.proxy }
            coroutineScope {
                val limiter = Semaphore(TELEGRAM_CONCURRENCY)
                proxies.map { proxy ->
                    async {
                        val ms = limiter.withPermit { TelegramProxyManager.ping(proxy) }
                        updatePendingProxy(proxy.id) {
                            it.copy(ping = if (ms >= 0) TelegramPing.Done(ms) else TelegramPing.Failed)
                        }
                        ServerCountryResolver.resolve(proxy.server)?.let { code ->
                            updatePendingProxy(proxy.id) { it.copy(countryCode = code) }
                        }
                    }
                }.awaitAll()
            }
        }
    }

    private fun updatePendingProxy(id: String, change: (TelegramRow) -> TelegramRow) {
        _uiState.update { s ->
            s.copy(localTest = s.localTest.copy(
                pendingProxies = s.localTest.pendingProxies.map { if (it.proxy.id == id) change(it) else it }
            ))
        }
    }

    private fun clearLocalTestSelection() {
        _uiState.update {
            it.copy(localTest = it.localTest.copy(selectedGuids = emptySet(), selectedProxyIds = emptySet()))
        }
    }

    /**
     * OK on the selection bar: saves the picked configs and proxies into the collection. A single config
     * glides into the main tab, becomes the selected server and glows; several are just saved.
     */
    private fun saveSelectedToCollection() {
        val state = _uiState.value.localTest
        val guids = state.selectedGuids.toList()
        val proxies = state.pendingProxies.filter { it.proxy.id in state.selectedProxyIds }.map { it.proxy }
        if (guids.isEmpty() && proxies.isEmpty()) return
        viewModelScope.launch(ioDispatcher) {
            try {
                _uiState.update { st ->
                    val picked = proxies.mapTo(HashSet()) { it.id }
                    st.copy(
                        localTest = st.localTest.copy(
                            selectedGuids = emptySet(),
                            selectedProxyIds = emptySet(),
                            pendingProxies = st.localTest.pendingProxies.filter { it.proxy.id !in picked },
                        )
                    )
                }
                val single = guids.size + proxies.size == 1
                val newGuids = if (guids.isEmpty()) emptyList() else LocalTestManager.moveGuidsToMain(guids)
                val proxyCount = receiveProxies(proxies)
                when {
                    single && newGuids.size == 1 -> {
                        deliverReceivedToMain(newGuids, testThem = false)
                        _uiState.update { it.copy(autoSelectGuid = newGuids.first()) }
                    }
                    single && proxyCount == 1 -> showTelegramTab()
                    else -> {
                        toast(dataSource.getString(R.string.local_test_moved, newGuids.size + proxyCount))
                        setupGroupTab(forceRefresh = true).join()
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to save the selection", e)
                toastError(R.string.toast_failure)
            }
        }
    }

    /** Saves received Telegram proxies into the proxy tab (without leaving the current tab). Returns how many were new. */
    private suspend fun receiveProxies(proxies: List<TelegramProxyManager.TelegramProxy>): Int {
        if (proxies.isEmpty()) return 0
        val created = TelegramProxyStore.ensureGroup(dataSource.getString(R.string.telegram_tab_title))
        val added = TelegramProxyStore.add(proxies)
        if (created) setupGroupTab(forceRefresh = true).join()
        if (added.isEmpty()) return 0
        _uiState.update { state ->
            val known = state.telegram.rows.mapTo(HashSet()) { it.proxy.id }
            val newRows = added.filter { it.id !in known }
                .map { p -> TelegramRow(p, countryCode = ServerCountryResolver.cached(p.server)) }
            state.copy(telegram = state.telegram.copy(rows = state.telegram.rows + newRows))
        }
        telegramTestAll()
        return added.size
    }

    /** Glides slowly to the proxy tab; used when only proxies were received. */
    private suspend fun showTelegramTab() {
        withContext(Dispatchers.Main) {
            _uiState.update { it.copy(slowSlide = true) }
            subscriptionIdChanged(TelegramProxyStore.GROUP_ID)
        }
    }

    /** "Share as local": keeps one config or proxy link in the server so others get it on their next fetch. */
    private fun shareLinkAsLocal(link: String?) {
        val ok = !link.isNullOrBlank() && localShareServer.addLink(link)
        if (ok) toast(dataSource.getString(R.string.share_as_local_done)) else toastError(R.string.toast_failure)
    }

    /**
     * Moves freshly received configs from "Local test" into the main group, slides the pager
     * slowly to the main page and makes the new cards glow; the glow is cleared after a few seconds.
     */
    private suspend fun deliverReceivedToMain(guids: List<String>, testThem: Boolean) {
        if (guids.isEmpty()) {
            setupGroupTab(forceRefresh = true).join()
            return
        }
        val newGuids = LocalTestManager.moveGuidsToMain(guids)
        setupGroupTab(forceRefresh = true).join()
        if (newGuids.isEmpty()) return
        val mainId = DEFAULT_TAB_ID
        withContext(Dispatchers.Main) {
            _uiState.update { it.copy(highlightGuids = newGuids.toHashSet(), slowSlide = true) }
            subscriptionIdChanged(mainId)
            if (testThem) testAllRealPing(onlyGuids = newGuids)
        }
        viewModelScope.launch {
            kotlinx.coroutines.delay(HIGHLIGHT_DURATION_MS)
            _uiState.update { it.copy(highlightGuids = emptySet()) }
        }
    }

    // ---------- Telegram tab ----------
    private var telegramJob: Job? = null

    private fun onTelegramTab() = uiState.value.selectedGroupId == TelegramProxyStore.GROUP_ID

    /** Shows saved proxies right away (country from cache) and re-pings them in the background. */
    private fun telegramLoadSaved() {
        val saved = TelegramProxyStore.load()
        if (saved.isEmpty()) return
        _uiState.update {
            it.copy(telegram = it.telegram.copy(rows = saved.map { p -> TelegramRow(p, countryCode = ServerCountryResolver.cached(p.server)) }))
        }
        telegramTestAll()
    }

    private fun telegramAdd(text: String) {
        viewModelScope.launch(ioDispatcher) {
            val found = TelegramProxyManager.parse(text)
            if (found.isEmpty()) {
                toastError(R.string.telegram_proxy_empty)
                return@launch
            }
            val created = TelegramProxyStore.ensureGroup(dataSource.getString(R.string.telegram_tab_title))
            val added = TelegramProxyStore.add(found)
            if (created) setupGroupTab(forceRefresh = true).join()
            _uiState.update { state ->
                val known = state.telegram.rows.mapTo(HashSet()) { it.proxy.id }
                val newRows = added.filter { it.id !in known }
                    .map { p -> TelegramRow(p, countryCode = ServerCountryResolver.cached(p.server)) }
                state.copy(telegram = state.telegram.copy(rows = state.telegram.rows + newRows))
            }
            toast(dataSource.getString(R.string.telegram_added_count, added.size))
            subscriptionIdChanged(TelegramProxyStore.GROUP_ID)
            telegramTestAll()
        }
    }

    /** Pings every saved proxy and looks up its country, a few at a time. */
    private fun telegramTestAll() {
        telegramJob?.cancel()
        telegramJob = viewModelScope.launch(ioDispatcher) {
            val proxies = _uiState.value.telegram.rows.map { it.proxy }
            if (proxies.isEmpty()) return@launch
            _uiState.update { s ->
                s.copy(telegram = s.telegram.copy(
                    isTesting = true,
                    rows = s.telegram.rows.map { it.copy(ping = TelegramPing.Testing) }
                ))
            }
            try {
                coroutineScope {
                    val limiter = Semaphore(TELEGRAM_CONCURRENCY)
                    proxies.map { proxy ->
                        async {
                            val ms = limiter.withPermit { TelegramProxyManager.ping(proxy) }
                            val ping = if (ms >= 0) TelegramPing.Done(ms) else TelegramPing.Failed
                            updateTelegramRow(proxy.id) { it.copy(ping = ping) }
                            // The country does not depend on the ping result, so look it up either way.
                            val code = ServerCountryResolver.resolve(proxy.server)
                            if (code != null) updateTelegramRow(proxy.id) { it.copy(countryCode = code) }
                        }
                    }.awaitAll()
                }
                _uiState.update { s ->
                    s.copy(telegram = s.telegram.copy(
                        rows = s.telegram.rows.sortedBy { (it.ping as? TelegramPing.Done)?.millis ?: Long.MAX_VALUE }
                    ))
                }
            } finally {
                _uiState.update { it.copy(telegram = it.telegram.copy(isTesting = false)) }
            }
        }
    }

    private fun updateTelegramRow(id: String, change: (TelegramRow) -> TelegramRow) {
        _uiState.update { s ->
            s.copy(telegram = s.telegram.copy(rows = s.telegram.rows.map { if (it.proxy.id == id) change(it) else it }))
        }
    }

    private fun telegramRemove(id: String) {
        viewModelScope.launch(ioDispatcher) {
            TelegramProxyStore.remove(id)
            _uiState.update { s -> s.copy(telegram = s.telegram.copy(rows = s.telegram.rows.filter { it.proxy.id != id })) }
        }
    }

    private fun telegramRemoveAll() {
        viewModelScope.launch(ioDispatcher) {
            telegramJob?.cancel()
            TelegramProxyStore.clear()
            _uiState.update { it.copy(telegram = TelegramTabUiState()) }
        }
    }

    private fun toggleLocalTestServer() {
        viewModelScope.launch(ioDispatcher) {
            if (localShareServer.isRunning) {
                localShareServer.stop()
                _uiState.update { it.copy(localTest = it.localTest.copy(serverRunning = false, serverAddress = "")) }
                publishChat()
                return@launch
            }
            if (!localShareServer.start(LocalShareServer.DEFAULT_PORT)) {
                toastError(R.string.local_test_server_failed)
                return@launch
            }
            val ip = findLanAddress()
            _uiState.update {
                it.copy(
                    localTest = it.localTest.copy(
                        serverRunning = true,
                        serverAddress = "${ip ?: "?"}:${localShareServer.port}",
                    )
                )
            }
            ensureChatLoop()
        }
    }

    /** IPv4 address of this device on the Wi-Fi/hotspot network (VPN tunnel addresses are skipped), or null. */
    private fun findLanAddress(): String? = LocalTestManager.primaryLanAddress()

    private fun localTestFetch(address: String) {
        if (LocalTestManager.buildConfigsUrl(address) == null) {
            toastError(R.string.local_test_bad_address)
            return
        }
        _uiState.update { it.copy(localTest = it.localTest.copy(busy = true)) }
        viewModelScope.launch(ioDispatcher) {
            try {
                LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))
                val text = LocalTestManager.fetchLinks(address)
                if (text == null) {
                    toastError(dataSource.getString(R.string.local_test_server_unreachable, address.trim()))
                    _uiState.update { it.copy(localTest = it.localTest.copy(busy = false)) }
                    return@launch
                }
                notifyConnectedToServer(LocalTestManager.normalizeAddress(address) ?: address.trim())
                connectedToServer(address)
                // Proxies go to the proxy tab, configs to the config tab.
                val (proxies, configText) = LocalTestManager.splitReceived(text)
                val before = dataSource.getServerGuidList(LocalTestManager.GROUP_ID)
                val count = if (configText.isBlank()) 0
                else dataSource.importBatchConfig(configText, LocalTestManager.GROUP_ID, true).first
                if (count <= 0 && proxies.isEmpty()) {
                    toastError(R.string.local_test_nothing_received)
                    _uiState.update { it.copy(localTest = it.localTest.copy(busy = false)) }
                    return@launch
                }
                // The server answered with usable configs, so remember it for the next fetch.
                LocalTestManager.saveAddress(address)
                val savedAddress = LocalTestManager.savedAddress()
                _uiState.update {
                    it.copy(localTest = it.localTest.copy(busy = false, savedAddress = savedAddress))
                }
                // A repeated fetch must not pile up copies of configs already here or already in main.
                val knownGuids = before.toHashSet()
                val addedGuids = dataSource.getServerGuidList(LocalTestManager.GROUP_ID)
                    .filter { it !in knownGuids }
                val existing = before + dataSource.getServerGuidList(AppConfig.DEFAULT_SUBSCRIPTION_ID)
                val duplicates = LocalTestManager.findDuplicateGuids(
                    existing = existing.mapNotNull { dataSource.decodeServerConfig(it) },
                    added = addedGuids.mapNotNull { guid -> dataSource.decodeServerConfig(guid)?.let { guid to it } },
                ).toHashSet()
                duplicates.forEach { dataSource.removeServer(it) }
                val freshGuids = addedGuids.filter { it !in duplicates }
                val total = handleReceived(proxies, freshGuids, testConfigs = true)
                toast(dataSource.getString(R.string.title_import_config_count, total))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: fetch flow failed", e)
                toastError(R.string.toast_failure)
                _uiState.update { it.copy(localTest = it.localTest.copy(busy = false)) }
            }
        }
    }

    // ---------- Update config ----------
    private var updateConfigJob: Job? = null

    /**
     * Menu "Update config": pulls the configs of the saved server into the main tab. A fetched config that
     * already exists replaces the old one in place; the toast reports how many arrived and how many repeated.
     * With no usable saved server it scans the network and, failing that, asks for the server's IP.
     */
    private fun updateConfig(manualAddress: String?) {
        if (updateConfigJob?.isActive == true) return
        _uiState.update { it.copy(localTest = it.localTest.copy(askServerAddress = false)) }
        updateConfigJob = viewModelScope.launch(ioDispatcher) {
            _isLoading.value = true
            try {
                runUpdateConfig(manualAddress)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "UpdateConfig: flow failed", e)
                toastError(R.string.toast_failure)
            } finally {
                _isLoading.value = false
            }
        }
    }

    private suspend fun runUpdateConfig(manualAddress: String?) {
        val (address, text) = findUpdateServer(manualAddress) ?: return
        val (proxies, configText) = LocalTestManager.splitReceived(text)
        LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))
        // Fetched configs are parsed into the Local test group first, then matched against the main group.
        val before = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).toHashSet()
        if (configText.isNotBlank()) dataSource.importBatchConfig(configText, LocalTestManager.GROUP_ID, true)
        val fetched = dataSource.getServerGuidList(LocalTestManager.GROUP_ID)
            .filter { it !in before }
            .mapNotNull { guid -> dataSource.decodeServerConfig(guid)?.let { guid to it } }
        val received = fetched.size + proxies.size
        if (received == 0) {
            toastError(R.string.local_test_nothing_received)
            return
        }
        // The server answered with usable configs, so remember it for the next update.
        LocalTestManager.saveAddress(address)
        _uiState.update { it.copy(localTest = it.localTest.copy(savedAddress = LocalTestManager.savedAddress())) }

        val existing = dataSource.getServerGuidList(AppConfig.DEFAULT_SUBSCRIPTION_ID)
            .mapNotNull { guid -> dataSource.decodeServerConfig(guid)?.let { guid to it } }
        val plan = LocalTestManager.planUpdate(existing, fetched)
        LocalTestManager.applyReplacements(plan.replacements)
        (plan.replacements.keys + plan.repeatedInBatch).forEach { dataSource.removeServer(it) }

        val newProxies = receiveProxies(proxies)
        val duplicates = plan.duplicateCount + (proxies.size - newProxies).coerceAtLeast(0)
        if (plan.fresh.isNotEmpty()) {
            deliverReceivedToMain(plan.fresh, testThem = true)
        } else {
            setupGroupTab(forceRefresh = true).join()
        }
        toast(dataSource.getString(R.string.update_config_result, received, duplicates))
    }

    /**
     * Finds the server to update from and downloads its configs: the typed [manualAddress] if given,
     * else the saved server, else a server found on the local network. Returns the address with the raw
     * text, or null after reporting the failure; when nothing was found the screen is asked for the IP.
     */
    private suspend fun findUpdateServer(manualAddress: String?): Pair<String, String>? {
        if (manualAddress != null) {
            val address = LocalTestManager.normalizeAddress(manualAddress)
            if (address == null) {
                toastError(R.string.local_test_bad_address)
                askServerAddress()
                return null
            }
            val text = LocalTestManager.fetchLinks(address)
            if (text == null) {
                toastError(dataSource.getString(R.string.local_test_server_unreachable, address))
                askServerAddress()
                return null
            }
            notifyConnectedToServer(address)
            return address to text
        }
        val saved = LocalTestManager.savedAddress()
        if (saved.isNotBlank()) {
            LocalTestManager.fetchLinks(saved)?.let {
                notifyConnectedToServer(saved)
                return saved to it
            }
        }
        val discovered = LocalTestManager.discoverServer()
        if (discovered != null) {
            LocalTestManager.fetchLinks(discovered)?.let {
                notifyConnectedToServer(discovered)
                return discovered to it
            }
        }
        askServerAddress()
        return null
    }

    private fun askServerAddress() {
        _uiState.update { it.copy(localTest = it.localTest.copy(askServerAddress = true)) }
    }

    private fun localTestMoveGreenToMain() {
        viewModelScope.launch(ioDispatcher) {
            try {
                val moved = LocalTestManager.moveGreenToMain()
                if (moved > 0) {
                    toast(dataSource.getString(R.string.local_test_moved, moved))
                    setupGroupTab(forceRefresh = true)
                } else {
                    toastError(R.string.local_test_no_green)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: move to main failed", e)
                toastError(R.string.toast_failure)
            }
        }
    }

    fun triggerLocateSelectedServer() {
        val selected = dataSource.getSelectServer() ?: return
        val profile = dataSource.decodeServerConfig(selected) ?: return
        val groupId = profile.subscriptionId
        if (_uiState.value.groups.none { it.id == groupId }) return
        viewModelScope.launch(ioDispatcher) {
            updateGroupUi(groupId, loadGroup(groupId))
            if (_uiState.value.selectedGroupId != groupId) {
                dataSource.setSelectedSubscriptionId(groupId)
            }
            val target = LocateTarget(groupId, selected)
            _uiState.update {
                it.copy(selectedGroupId = groupId, locateTarget = target)
            }
        }
    }

    private fun consumeLocateTarget() {
        _uiState.update { it.copy(locateTarget = null) }
    }

    // ---------- Running state ----------
    private fun updateRunningState(running: Boolean, clearTestingText: Boolean = true) {
        if (!running || clearTestingText) testRequests.invalidateCurrent()
        _uiState.update { state ->
            state.copy(
                isRunning = running,
                isTesting = testRequests.isTesting,
                status = if (!clearTestingText && state.isRunning == running) state.status
                else if (running) MainStatus.Connected else MainStatus.Disconnected
            )
        }
    }

    override fun onCleared() {
        localShareServer.stop()
        setupGroupJob?.cancel()
        preloadJob?.cancel()
        selectedGroupLoadJob?.cancel()
        reloadJob?.cancel()
        filterJob?.cancel()
        cancelAllPing()
        dataSource.close()
        super.onCleared()
    }

    // ---------- Factory ----------
    class Factory(private val application: Application, private val dataSource: MainDataSource) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(application, dataSource) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }

    private companion object {
        const val TEST_RESULT_FLUSH_INTERVAL_MS = 500L
        const val CLIENT_NOTIFY_INTERVAL_MS = 15_000L
        const val CLIENT_ONLINE_MS = 10_000L
        const val CHAT_POLL_INTERVAL_MS = 2_000L
        const val POLL_FAILURES_BEFORE_LOST = 4
        const val MAX_CHAT_MESSAGES = 300

        /** How long newly received configs keep their colored border before it fades away. */
        const val HIGHLIGHT_DURATION_MS = 4_000L

        /** Group id of the Default tab, which lists every config. */
        const val DEFAULT_TAB_ID = ""
        private const val PROGRESS_STEP_BYTES = 256 * 1024L

        /** ID of the user's own default config list (no subscription). */
        const val MAIN_GROUP_ID = ""
        private const val TELEGRAM_CONCURRENCY = 8
    }
}
