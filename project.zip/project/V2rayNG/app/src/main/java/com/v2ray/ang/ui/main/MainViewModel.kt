package com.v2ray.ang.ui.main

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.dto.ConnectionTestResult
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.dto.LocateTarget
import com.v2ray.ang.dto.RealPingResult
import com.v2ray.ang.dto.TestServiceMessage
import com.v2ray.ang.dto.TrafficSpeed
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.ServersCache
import com.v2ray.ang.dto.entities.SubscriptionCache
import com.v2ray.ang.extension.delay
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.extension.matchesPattern
import com.v2ray.ang.extension.moveItem
import com.v2ray.ang.handler.LocalShareServer
import com.v2ray.ang.handler.LocalTestManager
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.ServerCountryResolver
import com.v2ray.ang.handler.TelegramProxyManager
import com.v2ray.ang.handler.TelegramProxyStore
import com.v2ray.ang.util.QRCodeDecoder
import com.v2ray.ang.handler.SubscriptionInfoParser
import com.v2ray.ang.ui.base.BaseViewModel
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.PatternSyntaxException

private fun applyTestDelayResults(
    servers: List<ServersCache>,
    updates: Map<String, Long>,
): List<ServersCache> = servers.map { server ->
    val delayMillis = updates[server.guid]
    if (delayMillis == null || delayMillis == server.testDelayMillis) {
        server
    } else {
        server.copy(testDelayMillis = delayMillis)
    }
}

private fun applyTestDelayResultsToRows(
    rows: List<ServerRowUiModel>,
    updates: Map<String, Long>,
): List<ServerRowUiModel> = rows.map { row ->
    val delayMillis = updates[row.guid]
    if (delayMillis == null || delayMillis == row.testDelayMillis) {
        row
    } else {
        row.copy(testDelayMillis = delayMillis)
    }
}

class MainViewModel(
    application: Application,
    private val dataSource: MainDataSource
) : BaseViewModel(application) {

    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.Default
    private val preloadDispatcher: CoroutineDispatcher = Dispatchers.IO.limitedParallelism(1)

    // ---------- UI state ----------
    private val _uiState = MutableStateFlow(
        MainUiState(
            selectedGroupId = dataSource.getSelectedSubscriptionId(),
            selectedGuid = dataSource.getSelectServer(),
            confirmRemove = dataSource.getConfirmRemove(),
            doubleColumnDisplay = dataSource.getDoubleColumnDisplay(),
            autoConnection = dataSource.getAutoConnection(),
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // Live speed changes every second, so it stays out of uiState and only the Home page collects it.
    private val _trafficSpeed = MutableStateFlow(TrafficSpeed())
    val trafficSpeed: StateFlow<TrafficSpeed> = _trafficSpeed.asStateFlow()

    /** The Home page is visible, so the daemon should keep sending speed. Re-sent when the core (re)starts. */
    private var speedUpdatesWanted = false
    private var activeConfigJob: Job? = null

    // ---------- Keyword filtering ----------
    @Volatile
    private var keywordFilter: String = ""
    private var filterJob: Job? = null

    // ---------- Groups & cache ----------
    private val cacheMutex = Mutex()
    private val groupDataCache = mutableMapOf<String, List<ServersCache>>()
    private val groupUiFlows = ConcurrentHashMap<String, MutableStateFlow<ServerGroupUiState>>()
    private val groupServerFlows = ConcurrentHashMap<String, StateFlow<List<ServersCache>>>()
    private val groupLoadMutexes = ConcurrentHashMap<String, Mutex>()
    private val serverOrderPersistenceJobs = mutableMapOf<String, Job>()

    private var setupGroupJob: Job? = null
    private var preloadJob: Job? = null
    private var selectedGroupLoadJob: Job? = null
    private var reloadJob: Job? = null
    private var testResultFlushJob: Job? = null
    private val pendingTestResults = linkedMapOf<String, Long>()

    private val testRequests = MainTestRequests()
    private var bulkTestJob: Job? = null

    private val initialPageReady = CompletableDeferred<Unit>()

    // ---------- Service events ----------
    init {
        collectServiceEvents()
        setupGroupTab()
        refreshActiveConfig()
    }

    private fun collectServiceEvents() {
        viewModelScope.launch {
            dataSource.mainServiceEvent.collect { event ->
                handleServiceEvent(event)
            }
        }
    }

    private fun handleServiceEvent(event: MainServiceEvent) {
        when (event) {
            MainServiceEvent.StateRunning -> {
                updateRunningState(true, clearTestingText = false)
                resubscribeSpeed()
            }
            MainServiceEvent.StateNotRunning -> {
                updateRunningState(false, clearTestingText = false)
                _trafficSpeed.value = TrafficSpeed()
            }
            MainServiceEvent.StateStartSuccess -> {
                toastSuccess(R.string.toast_services_success)
                updateRunningState(true)
                resubscribeSpeed()
            }

            is MainServiceEvent.StateStartFailure -> {
                if (!event.message.isNullOrBlank()) {
                    toastError(event.message)
                } else {
                    toastError(R.string.toast_services_failure)
                }
                updateRunningState(false)
                _trafficSpeed.value = TrafficSpeed()
            }

            MainServiceEvent.StateStopSuccess -> {
                updateRunningState(false)
                _trafficSpeed.value = TrafficSpeed()
            }
            is MainServiceEvent.SpeedUpdate -> _trafficSpeed.value = event.speed
            is MainServiceEvent.AutoSwitched -> onAutoSwitched(event.guid)
            is MainServiceEvent.MeasureDelayResult -> {
                if (!uiState.value.isRunning || !testRequests.completeCurrent(event.requestId)) return
                _uiState.update {
                    it.copy(
                        isTesting = testRequests.isTesting,
                        status = MainStatus.ConnectionTest(event.result),
                        activeConfig = it.activeConfig?.copy(delayMillis = event.result.delayMillis),
                    )
                }
            }

            is MainServiceEvent.MeasureConfigSuccess -> {
                val request = testRequests.bulk?.takeIf { it.id == event.requestId } ?: return
                queueTestResult(event.result, request)
            }

            is MainServiceEvent.MeasureConfigNotify -> {
                if (event.requestId == testRequests.bulk?.id) {
                    _uiState.update { it.copy(status = MainStatus.TestProgress(event.progress)) }
                }
            }

            is MainServiceEvent.MeasureConfigFinish -> {
                val request = testRequests.bulk?.takeIf { it.id == event.requestId } ?: return
                val scheduledFlush = testResultFlushJob
                testResultFlushJob = viewModelScope.launch {
                    scheduledFlush?.cancelAndJoin()
                    if (testRequests.bulk?.id != request.id) return@launch
                    flushPendingTestResults(request)
                    onTestsFinished(request.id)
                }
            }

            is MainServiceEvent.MeasureDelayCancelled -> {
                if (testRequests.completeCurrent(event.requestId)) resetTestStatus()
            }

            is MainServiceEvent.MeasureConfigCancelled -> {
                if (testRequests.completeBulk(event.requestId) != null) {
                    cancelPendingTestResults()
                    resetTestStatus()
                }
            }
        }
    }

    private fun queueTestResult(result: RealPingResult, request: MainTestRequests.Bulk) {
        pendingTestResults[result.guid] = result.delayMillis
        if (testResultFlushJob?.isActive == true) return

        testResultFlushJob = viewModelScope.launch {
            while (pendingTestResults.isNotEmpty()) {
                delay(TEST_RESULT_FLUSH_INTERVAL_MS)
                flushPendingTestResults(request)
            }
        }
    }

    private suspend fun flushPendingTestResults(request: MainTestRequests.Bulk) {
        if (pendingTestResults.isEmpty()) return
        if (testRequests.bulk?.id != request.id) return

        val updates = cacheMutex.withLock {
            val drained = pendingTestResults.toMap()
            pendingTestResults.clear()
            groupDataCache[request.groupId]?.let { cached ->
                groupDataCache[request.groupId] = applyTestDelayResults(cached, drained)
            }
            drained
        }
        if (updates.isEmpty()) return
        if (testRequests.bulk?.id != request.id) return
        _uiState.update { state ->
            val active = state.activeConfig
            val delayMillis = active?.let { updates[it.guid] }
            if (active == null || delayMillis == null) state
            else state.copy(activeConfig = active.copy(delayMillis = delayMillis))
        }
        mutableServerGroupState(request.groupId).update { current ->
            current.copy(
                servers = applyTestDelayResults(current.servers, updates),
                rows = applyTestDelayResultsToRows(current.rows, updates),
            )
        }
    }

    internal fun formatStatus(status: MainStatus): String = when (status) {
        MainStatus.Disconnected -> dataSource.getString(R.string.connection_not_connected)
        MainStatus.Connected -> dataSource.getString(R.string.connection_connected)
        MainStatus.Testing -> dataSource.getString(R.string.connection_test_testing)
        is MainStatus.TestProgress -> dataSource.getString(
            R.string.connection_running_task_left,
            status.progress
        )

        is MainStatus.ConnectionTest -> formatConnectionTestResult(status.result)
    }

    private fun formatConnectionTestResult(result: ConnectionTestResult): String {
        val status = if (result.delayMillis >= 0) {
            val delay = dataSource.getString(R.string.server_test_delay_value, result.delayMillis)
            dataSource.getString(R.string.connection_test_available, delay)
        } else {
            val detail = result.errorMessage.ifBlank {
                dataSource.getString(R.string.connection_test_empty_message)
            }
            dataSource.getString(R.string.connection_test_error, detail)
        }

        if (result.delayMillis < 0 || (result.country == null && result.ipAddress == null)) {
            return status
        }

        val unknown = dataSource.getString(R.string.value_unknown)
        return "$status\n(${result.country ?: unknown}) ${result.ipAddress ?: unknown}"
    }

    // ---------- Public state accessors ----------
    fun serversForGroup(groupId: String): StateFlow<List<ServersCache>> =
        groupServerFlows.computeIfAbsent(groupId) {
            val groupState = mutableServerGroupState(groupId)
            groupState
                .map { it.servers }
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
                    initialValue = groupState.value.servers,
                )
        }

    internal fun serverGroupState(groupId: String): StateFlow<ServerGroupUiState> =
        mutableServerGroupState(groupId).asStateFlow()

    private fun mutableServerGroupState(groupId: String): MutableStateFlow<ServerGroupUiState> =
        groupUiFlows.computeIfAbsent(groupId) { MutableStateFlow(ServerGroupUiState()) }

    private fun currentServers(): List<ServersCache> =
        mutableServerGroupState(uiState.value.selectedGroupId).value.servers

    // ---------- Action handler ----------
    fun onAction(action: MainAction) {
        when (action) {
            MainAction.Initialize -> initialize()
            MainAction.RefreshGroups -> setupGroupTab(forceRefresh = true)
            MainAction.TestAllServers ->
                if (onTelegramTab()) telegramTestAll() else testAllRealPing(true)
            MainAction.TestRealAllServers ->
                if (onTelegramTab()) telegramTestAll() else testAllRealPing()
            MainAction.CancelTesting -> cancelAllPing()
            is MainAction.SetAutoConnection -> {
                dataSource.setAutoConnection(action.enabled)
                _uiState.update { it.copy(autoConnection = action.enabled) }
            }
            is MainAction.SpeedUpdatesWanted -> {
                speedUpdatesWanted = action.wanted
                dataSource.setSpeedUpdates(action.wanted)
            }
            MainAction.RemoveAllServers ->
                if (onTelegramTab()) telegramRemoveAll() else removeAllServerAsync()
            MainAction.RemoveDuplicateServers -> removeDuplicateServerAsync()
            MainAction.RemoveInvalidServers -> removeInvalidServerAsync()
            MainAction.SortByTestResults -> sortByTestResultsAsync()
            MainAction.UpdateSubscriptions ->
                if (onTelegramTab()) telegramTestAll() else importConfigViaSub(importTargetGroupId())
            is MainAction.UpdateGroupSubscription -> importConfigViaSub(action.groupId)
            MainAction.ExportAll -> exportAllAsync()
            is MainAction.SelectGroup -> subscriptionIdChanged(action.groupId)
            is MainAction.SelectServer -> updateSelectedGuid(action.guid)
            is MainAction.RemoveServer -> removeServerAndRefresh(action.guid)
            is MainAction.Search -> filterConfig(action.query)
            is MainAction.ImportBatchConfig -> importBatchConfig(action.configText)
            is MainAction.TelegramAdd -> telegramAdd(action.text)
            MainAction.TelegramTestAll -> telegramTestAll()
            is MainAction.TelegramRemove -> telegramRemove(action.id)
            MainAction.TelegramRemoveAll -> telegramRemoveAll()
            MainAction.LocateHandled -> consumeLocateTarget()
            MainAction.SlowSlideHandled -> _uiState.update { it.copy(slowSlide = false) }
            MainAction.AutoSelectHandled -> _uiState.update { it.copy(autoSelectGuid = null) }
            is MainAction.LocalTestSetSaveAll -> {
                LocalTestManager.setSaveAllEnabled(action.enabled)
                _uiState.update { it.copy(localTest = it.localTest.copy(saveAll = action.enabled)) }
            }
            is MainAction.LocalTestToggleSelect -> _uiState.update { st ->
                val sel = st.localTest.selectedGuids
                st.copy(localTest = st.localTest.copy(selectedGuids = if (action.guid in sel) sel - action.guid else sel + action.guid))
            }
            is MainAction.LocalTestToggleProxySelect -> _uiState.update { st ->
                val sel = st.localTest.selectedProxyIds
                st.copy(localTest = st.localTest.copy(selectedProxyIds = if (action.id in sel) sel - action.id else sel + action.id))
            }
            MainAction.LocalTestClearSelection -> clearLocalTestSelection()
            MainAction.LocalTestSaveSelected -> saveSelectedToCollection()
            is MainAction.ShareAsLocal -> viewModelScope.launch(ioDispatcher) {
                shareLinkAsLocal(AngConfigManager.shareLinks(listOf(action.guid)).firstOrNull())
            }
            is MainAction.TelegramShareAsLocal -> shareLinkAsLocal(
                TelegramProxyStore.load().firstOrNull { it.id == action.id }?.link
            )
            is MainAction.TelegramShowQRCode -> viewModelScope.launch(ioDispatcher) {
                val bitmap = runCatching { QRCodeDecoder.createQRCode(action.link) }.getOrNull()
                _uiState.update { it.copy(shareQRCodeBitmap = bitmap) }
            }
            MainAction.LocalTestToggleServer -> toggleLocalTestServer()
            is MainAction.LocalTestFetch -> localTestFetch(action.address)
            MainAction.LocalTestMoveGreenToMain -> localTestMoveGreenToMain()
            MainAction.UpdateConfig -> updateConfig(manualAddress = null)
            is MainAction.UpdateConfigWithAddress -> updateConfig(manualAddress = action.address)
            MainAction.UpdateConfigAddressDismissed ->
                _uiState.update { it.copy(localTest = it.localTest.copy(askServerAddress = false)) }
            is MainAction.ShareQRCode -> {
                val bitmap = dataSource.share2QRCode(action.guid)
                _uiState.update { it.copy(shareQRCodeBitmap = bitmap) }
            }

            MainAction.DismissQRCodeDialog -> {
                _uiState.update { it.copy(shareQRCodeBitmap = null) }
            }

            MainAction.ToggleService,
            MainAction.TestCurrentServer,
            MainAction.ImportQRcode,
            MainAction.ImportClipboard,
            MainAction.ImportConfigLocal,
            is MainAction.ImportManually,
            MainAction.RestartService,
            MainAction.LocateSelectedServer,
            is MainAction.EditServer,
            is MainAction.ShareClipboard,
            is MainAction.ShareFullContent,
            is MainAction.OpenSubscriptionLink -> {
                // Handled by Activity via its onAction lambda
            }
        }
    }

    // ---------- Initialization ----------
    fun initialize() {
        viewModelScope.launch(preloadDispatcher) {
            try {
                initialPageReady.await()
                delay(32)
                dataSource.initAssets()
                dataSource.syncSubscriptions()
                if (LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))) {
                    setupGroupTab(forceRefresh = true)
                }
                val savedAddress = LocalTestManager.savedAddress()
                val saveAll = LocalTestManager.saveAllEnabled()
                _uiState.update { it.copy(localTest = it.localTest.copy(savedAddress = savedAddress, saveAll = saveAll)) }
                if (TelegramProxyStore.ensureGroup(dataSource.getString(R.string.telegram_tab_title))) {
                    setupGroupTab(forceRefresh = true)
                }
                telegramLoadSaved()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Main background initialization failed", error)
            }
        }
    }

    fun refreshUiSettings() {
        _uiState.update {
            it.copy(
                confirmRemove = dataSource.getConfirmRemove(),
                doubleColumnDisplay = dataSource.getDoubleColumnDisplay()
            )
        }
    }

    // ---------- Group & server loading ----------
    private suspend fun buildServersCache(guids: List<String>): List<ServersCache> =
        guids.mapNotNull { guid ->
            currentCoroutineContext().ensureActive()
            val profile = dataSource.decodeServerConfig(guid) ?: return@mapNotNull null
            val affiliation = dataSource.decodeAffiliationInfo(guid)
            ServersCache(
                guid = guid,
                profile = profile.copy(),
                testDelayMillis = affiliation?.testDelayMillis ?: 0L
            )
        }

    private suspend fun loadGroup(
        groupId: String,
        forceRefresh: Boolean = false
    ): List<ServersCache> {
        val loadMutex = groupLoadMutexes.computeIfAbsent(groupId) { Mutex() }
        return loadMutex.withLock {
            if (!forceRefresh) {
                cacheMutex.withLock { groupDataCache[groupId]?.let { return@withLock it } }
            }
            val servers = buildServersCache(dataSource.getServerGuidList(groupId))
            currentCoroutineContext().ensureActive()
            cacheMutex.withLock { groupDataCache[groupId] = servers }
            servers
        }
    }

    private fun applyKeywordFilter(servers: List<ServersCache>): List<ServersCache> {
        val keyword = keywordFilter.trim()
        if (keyword.isEmpty()) return servers
        val regex = try {
            Regex(keyword, RegexOption.IGNORE_CASE)
        } catch (_: PatternSyntaxException) {
            return servers
        }
        return servers.filter { cache ->
            val profile = cache.profile
            profile.remarks.matchesPattern(regex, keyword) ||
                    profile.description.orEmpty().matchesPattern(regex, keyword) ||
                    profile.server.orEmpty().matchesPattern(regex, keyword) ||
                    profile.configType.name.matchesPattern(regex, keyword)
        }
    }

    private fun updateGroupUi(groupId: String, servers: List<ServersCache>) {
        val filteredServers = applyKeywordFilter(servers)
        mutableServerGroupState(groupId).value = ServerGroupUiState(
            servers = filteredServers,
            rows = buildServerRows(groupId, filteredServers)
        )
    }

    private fun buildServerRows(groupId: String, servers: List<ServersCache>): List<ServerRowUiModel> {
        val subscriptionRemarks = if (groupId.isEmpty()) {
            servers.asSequence()
                .map { it.profile.subscriptionId }
                .filter { it.isNotEmpty() }
                .distinct()
                .associateWith { subscriptionId ->
                    dataSource.getSubscriptionItem(subscriptionId)?.remarks.orEmpty()
                }
        } else {
            emptyMap()
        }
        return servers.map { server ->
            buildServerRowUiModel(
                server = server,
                subscriptionRemarks = subscriptionRemarks[server.profile.subscriptionId].orEmpty()
            )
        }
    }

    fun getSubscriptions(): List<SubscriptionCache> = dataSource.getSubscriptions()

    private fun resolveSelectedGroup(groups: List<GroupMapItem>): String {
        val current = uiState.value.selectedGroupId
        val resolved = when {
            groups.isEmpty() -> ""
            groups.any { it.id == current } -> current
            else -> groups.first().id
        }
        if (resolved != current) {
            dataSource.setSelectedSubscriptionId(resolved)
        }
        return resolved
    }

    private fun radialPreloadOrder(groups: List<GroupMapItem>, selectedIndex: Int): List<String> {
        if (groups.isEmpty()) return emptyList()
        val result = ArrayList<String>((groups.size - 1).coerceAtLeast(0))
        for (distance in 1 until groups.size) {
            val right = selectedIndex + distance
            val left = selectedIndex - distance
            if (right in groups.indices) result += groups[right].id
            if (left in groups.indices) result += groups[left].id
        }
        return result
    }

    fun setupGroupTab(forceRefresh: Boolean = false): Job {
        setupGroupJob?.cancel()
        preloadJob?.cancel()
        selectedGroupLoadJob?.cancel()

        return viewModelScope.launch(ioDispatcher) {
            try {
                if (forceRefresh) {
                    cacheMutex.withLock { groupDataCache.clear() }
                }
                val subscriptionGroups = dataSource.getSubscriptions().map {
                    GroupMapItem(
                        id = it.guid,
                        remarks = it.subscription.remarks,
                        usageInfo = it.subscription.usageInfo?.let { info ->
                            SubscriptionInfoParser.withWebPageFallback(info, it.subscription.url)
                        },
                    )
                }
                // Home is the first tab. It is not a subscription, so nothing is stored for it.
                val groups = listOf(
                    GroupMapItem(id = HOME_GROUP_ID, remarks = dataSource.getString(R.string.home_tab_title))
                ) + subscriptionGroups
                val selectedGroup = resolveSelectedGroup(groups)
                val validIds = groups.mapTo(HashSet()) { it.id }
                groupUiFlows.keys.removeAll { it !in validIds }
                groupServerFlows.keys.removeAll { it !in validIds }
                groupLoadMutexes.keys.removeAll { it !in validIds }

                _uiState.update {
                    it.copy(
                        groups = groups,
                        selectedGroupId = selectedGroup,
                        selectedGuid = dataSource.getSelectServer(),
                    )
                }
                refreshActiveConfig()
                groups.forEach { mutableServerGroupState(it.id) }

                if (groups.isEmpty()) {
                    cacheMutex.withLock { groupDataCache.clear() }
                    return@launch
                }

                val selectedServers = loadGroup(selectedGroup, forceRefresh)
                updateGroupUi(selectedGroup, selectedServers)

                if (!initialPageReady.isCompleted) {
                    initialPageReady.complete(Unit)
                }

                val selectedIndex =
                    groups.indexOfFirst { it.id == selectedGroup }.coerceAtLeast(0)
                val preloadOrder = radialPreloadOrder(groups, selectedIndex)
                preloadJob = viewModelScope.launch(preloadDispatcher) {
                    preloadOrder.forEach { groupId ->
                        ensureActive()
                        delay(32)
                        val servers = loadGroup(groupId, forceRefresh)
                        updateGroupUi(groupId, servers)
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to set up group tabs", error)
            } finally {
                if (!initialPageReady.isCompleted) {
                    initialPageReady.complete(Unit)
                }
            }
        }.also { setupGroupJob = it }
    }

    // ---------- Business actions (coroutine-based) ----------
    private fun importBatchConfig(configText: String) {
        // Telegram MTProto links are not v2ray profiles: they go to the Telegram tab.
        if (TelegramProxyManager.containsProxy(configText)) {
            telegramAdd(configText)
            return
        }
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val (count, countSub) = dataSource.importBatchConfig(
                        configText, importTargetGroupId(), true
                    )
                    when {
                        count > 0 -> {
                            toast(dataSource.getString(R.string.title_import_config_count, count))
                            setupGroupTab(forceRefresh = true)
                        }

                        countSub > 0 -> setupGroupTab(forceRefresh = true)
                        else -> toastError(R.string.toast_failure)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Failed to import batch config", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun importConfigViaSub(subId: String) {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val result = if (subId.isEmpty()) {
                        dataSource.updateConfigViaSubAll()
                    } else {
                        val item = dataSource.getSubscriptionItem(subId) ?: return@withContext
                        dataSource.updateConfigViaSub(SubscriptionCache(subId, item))
                    }
                    when {
                        result.successCount + result.failureCount + result.skipCount == 0 ->
                            toast(R.string.title_update_subscription_no_subscription)

                        result.successCount > 0 && result.failureCount + result.skipCount == 0 ->
                            toast(
                                getQuantityString(
                                    R.plurals.title_update_config_count,
                                    result.configCount,
                                    result.configCount,
                                )
                            )

                        else ->
                            toast(dataSource.getString(R.string.title_update_subscription_result, result.configCount, result.successCount, result.failureCount, result.skipCount))
                    }
                    if (result.configCount > 0) {
                        setupGroupTab(forceRefresh = true)
                        refreshSelectedGuid()
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Subscription update failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun exportAllAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val groupId = uiState.value.selectedGroupId
                    val list = if (groupId.isEmpty() && keywordFilter.isEmpty()) {
                        dataSource.getServerGuidList("")
                    } else {
                        currentServers().map { it.guid }
                    }
                    val ret = dataSource.shareNonCustomConfigsToClipboard(list)
                    if (ret > 0) {
                        toast(dataSource.getString(R.string.title_export_config_count, ret))
                    } else {
                        toastError(R.string.toast_failure)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Export failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeAllServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val count =
                        if (uiState.value.selectedGroupId.isEmpty() && keywordFilter.isEmpty()) {
                            dataSource.removeAllServer()
                        } else {
                            val guids = currentServers().map { it.guid }
                            guids.forEach { dataSource.removeServer(it) }
                            guids.size
                        }
                    viewModelScope.launch(ioDispatcher) {
                        cacheMutex.withLock { groupDataCache.clear() }
                    }
                    setupGroupTab(forceRefresh = true)
                    toast(dataSource.getString(R.string.title_del_config_count, count))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete all failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeDuplicateServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val seen = HashSet<ProfileItem>()
                    val duplicates = ArrayList<String>()
                    currentServers().forEach { server ->
                        val profile = server.profile
                        if (!profile.configType.isComplexType()) {
                            val identity = profile.duplicateIdentity()
                            if (!seen.add(identity)) duplicates += server.guid
                        }
                    }
                    duplicates.forEach { dataSource.removeServer(it) }
                    setupGroupTab(forceRefresh = true)
                    toast(dataSource.getString(R.string.title_del_duplicate_config_count, duplicates.size))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete duplicate failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeInvalidServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val count = removeInvalidServerInternal()
                    viewModelScope.launch(ioDispatcher) {
                        cacheMutex.withLock { groupDataCache.clear() }
                        setupGroupTab(forceRefresh = true)
                    }
                    toast(dataSource.getString(R.string.title_del_config_count, count))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete invalid failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeInvalidServerInternal(): Int {
        val visibleServersOnly =
            uiState.value.selectedGroupId.isNotEmpty() || keywordFilter.isNotBlank()
        return if (visibleServersOnly) {
            currentServers().sumOf { server ->
                dataSource.removeInvalidServerByGuid(server.guid)
            }
        } else {
            dataSource.removeInvalidServersInGroup("")
        }
    }

    private fun sortByTestResultsAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    sortByTestResultsInternal()
                    cacheMutex.withLock { groupDataCache.clear() }
                    setupGroupTab(forceRefresh = true)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Sort by test results failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun sortByTestResultsInternal() {
        val subs = if (uiState.value.selectedGroupId.isEmpty()) {
            dataSource.getSubsList()
        } else {
            listOf(uiState.value.selectedGroupId)
        }
        subs.forEach { dataSource.sortByTestResultsForSub(it) }
    }

    fun subscriptionIdChanged(id: String) {
        if (_uiState.value.groups.none { it.id == id }) return
        mutableServerGroupState(id)
        if (uiState.value.selectedGroupId != id) {
            dataSource.setSelectedSubscriptionId(id)
            _uiState.update { it.copy(selectedGroupId = id) }
        }
        selectedGroupLoadJob?.cancel()
        selectedGroupLoadJob = viewModelScope.launch(ioDispatcher) {
            try {
                updateGroupUi(id, loadGroup(id))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to load selected group: $id", error)
            }
        }
    }

    fun reloadServerList() {
        val groupId = uiState.value.selectedGroupId
        selectedGroupLoadJob?.cancel()
        selectedGroupLoadJob = viewModelScope.launch(ioDispatcher) {
            updateGroupUi(groupId, loadGroup(groupId, forceRefresh = true))
        }
    }

    fun reloadAllGroups(groupIds: List<String>) {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch(preloadDispatcher) {
            val selected = uiState.value.selectedGroupId
            val order = buildList {
                if (selected in groupIds) add(selected)
                addAll(groupIds.filter { it != selected })
            }
            order.forEachIndexed { index, groupId ->
                ensureActive()
                if (index > 0) delay(32)
                updateGroupUi(groupId, loadGroup(groupId, forceRefresh = true))
            }
        }
    }

    fun filterConfig(keyword: String) {
        if (keyword == keywordFilter) return
        keywordFilter = keyword
        filterJob?.cancel()
        filterJob = viewModelScope.launch(defaultDispatcher) {
            delay(300)
            val snapshot = cacheMutex.withLock { groupDataCache.toMap() }
            ensureActive()
            snapshot.forEach { (groupId, servers) ->
                ensureActive()
                updateGroupUi(groupId, servers)
            }
        }
    }

    fun updateSelectedGuid(guid: String) {
        dataSource.setSelectServer(guid)
        _uiState.update { it.copy(selectedGuid = guid) }
        refreshActiveConfig()
    }

    fun refreshSelectedGuid() {
        _uiState.update { it.copy(selectedGuid = dataSource.getSelectServer()) }
        refreshActiveConfig()
    }

    /** Group that imported or newly created profiles go to; Home owns none, so they land in the default group. */
    fun importTargetGroupId(): String =
        uiState.value.selectedGroupId.takeUnless { it == HOME_GROUP_ID }.orEmpty()

    private fun resubscribeSpeed() {
        if (speedUpdatesWanted) dataSource.setSpeedUpdates(true)
    }

    /** The daemon moved the core to [guid] (Auto connection); mirror it without restarting anything. */
    private fun onAutoSwitched(guid: String) {
        _uiState.update { it.copy(selectedGuid = guid) }
        refreshActiveConfig()
        viewModelScope.launch(ioDispatcher) {
            val name = dataSource.decodeServerConfig(guid)?.remarks.orEmpty()
            toast(dataSource.getString(R.string.auto_connection_switched, name))
        }
    }

    /** Reloads name and last test result of the selected profile for the Home page, off the main thread. */
    private fun refreshActiveConfig() {
        activeConfigJob?.cancel()
        activeConfigJob = viewModelScope.launch(ioDispatcher) {
            val guid = dataSource.getSelectServer()
            val profile = guid?.let { dataSource.decodeServerConfig(it) }
            val active = if (guid == null || profile == null) null else ActiveConfigUi(
                guid = guid,
                name = profile.remarks,
                delayMillis = dataSource.decodeAffiliationInfo(guid)?.testDelayMillis ?: 0L,
            )
            _uiState.update { it.copy(activeConfig = active) }
        }
    }

    fun removeServerAndRefresh(guid: String) {
        if (guid == uiState.value.selectedGuid) {
            toast(R.string.toast_action_not_allowed)
            return
        }
        viewModelScope.launch(ioDispatcher) {
            dataSource.removeServer(guid)
            cacheMutex.withLock { groupDataCache.clear() }
            setupGroupTab(forceRefresh = true).join()
        }
    }

    fun moveServer(groupId: String, fromPosition: Int, toPosition: Int) {
        val groupState = mutableServerGroupState(groupId).value
        val servers = groupState.servers.toMutableList()
        if (!servers.moveItem(fromPosition, toPosition)) return
        val rows = groupState.rows.toMutableList()
        rows.moveItem(fromPosition, toPosition)
        val guids = servers.map { it.guid }
        mutableServerGroupState(groupId).value = ServerGroupUiState(servers, rows)
        // A drag emits several moves; serialize writes so an older order cannot overwrite a newer one.
        val previousPersistenceJob = serverOrderPersistenceJobs[groupId]
        serverOrderPersistenceJobs[groupId] = viewModelScope.launch(ioDispatcher) {
            previousPersistenceJob?.join()
            dataSource.encodeServerList(guids, groupId)
            cacheMutex.withLock { groupDataCache[groupId] = servers }
        }
    }

    // ---------- Testing ----------
    fun cancelAllPing() {
        bulkTestJob?.cancel()
        bulkTestJob = null
        testRequests.cancelBulk()
        testRequests.invalidateCurrent()
        cancelPendingTestResults()
        resetTestStatus()
        dataSource.cancelAllPing()
    }

    private fun resetTestStatus() {
        _uiState.update {
            it.copy(
                isTesting = testRequests.isTesting,
                status = if (testRequests.isTesting) MainStatus.Testing
                else if (it.isRunning) MainStatus.Connected else MainStatus.Disconnected
            )
        }
    }

    fun testAllRealPing(onlyTcp: Boolean = false, onlyGuids: List<String> = emptyList()) {
        cancelAllPing()
        val groupId = uiState.value.selectedGroupId
        val servers = currentServers()
        // With an explicit list the group may still be loading, so the visible list can be empty.
        if (servers.isEmpty() && onlyGuids.isEmpty()) {
            return
        }
        val serverGuids = onlyGuids.ifEmpty { servers.map { it.guid } }
        val onlyGuidSet = onlyGuids.toHashSet()
        mutableServerGroupState(groupId).update { current ->
            current.copy(
                servers = current.servers.map { server ->
                    if (server.testDelayMillis == 0L || (onlyGuidSet.isNotEmpty() && server.guid !in onlyGuidSet)) server
                    else server.copy(testDelayMillis = 0L)
                },
                rows = current.rows.map { row ->
                    if (row.testDelayMillis == 0L || (onlyGuidSet.isNotEmpty() && row.guid !in onlyGuidSet)) row
                    else row.copy(testDelayMillis = 0L)
                }
            )
        }
        val request = testRequests.beginBulk(groupId)
        val message = TestServiceMessage(
            key = AppConfig.MSG_MEASURE_CONFIG_START,
            subscriptionId = groupId,
            serverGuids = if (onlyGuids.isNotEmpty() || keywordFilter.isNotEmpty()) serverGuids else emptyList(),
            onlyTcp = onlyTcp
        )
        _uiState.update {
            it.copy(
                isTesting = true,
                status = MainStatus.Testing
            )
        }
        bulkTestJob = viewModelScope.launch {
            withContext(ioDispatcher) {
                dataSource.clearAllTestDelayResults(serverGuids)
                val resetGuids = serverGuids.toHashSet()
                cacheMutex.withLock {
                    groupDataCache[groupId]?.let { cached ->
                        groupDataCache[groupId] = cached.map { server ->
                            if (server.guid !in resetGuids || server.testDelayMillis == 0L) server
                            else server.copy(testDelayMillis = 0L)
                        }
                    }
                }
            }
            dataSource.sendMsg2TestService(message, request.id)
        }
    }

    private fun cancelPendingTestResults() {
        testResultFlushJob?.cancel()
        testResultFlushJob = null
        pendingTestResults.clear()
    }

    fun testCurrentServerRealPing() {
        if (!uiState.value.isRunning) return
        val requestId = testRequests.beginCurrent()
        _uiState.update { it.copy(isTesting = true, status = MainStatus.Testing) }
        dataSource.testCurrentServerRealPing(requestId)
    }

    private fun onTestsFinished(requestId: String) {
        val finished = testRequests.completeBulk(requestId) ?: return
        resetTestStatus()
        viewModelScope.launch(ioDispatcher) {
            cacheMutex.withLock { groupDataCache.clear() }
            reloadAllGroups(_uiState.value.groups.map { it.id })
        }
    }

    // ---------- Local test ----------
    // The local server always hands out every config and proxy of the owner (live, so new ones appear too).
    private val localShareServer = LocalShareServer(
        ownerLinks = { LocalTestManager.ownerAllLinks() },
        onConfigsReceived = { links -> onLocalTestLinksReceived(links) },
    )

    private fun onLocalTestLinksReceived(links: List<String>) {
        viewModelScope.launch(ioDispatcher) {
            try {
                val (proxies, configText) = LocalTestManager.splitReceived(links.joinToString("\n"))
                var added = emptyList<String>()
                if (configText.isNotBlank()) {
                    LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))
                    val before = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).toHashSet()
                    dataSource.importBatchConfig(configText, LocalTestManager.GROUP_ID, true)
                    added = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).filter { it !in before }
                }
                handleReceived(proxies, added, testConfigs = false)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to import received configs", e)
            }
        }
    }

    /**
     * Decides where received items go. With "Save all to my collection" on, configs go to the main tab
     * and proxies to the proxy tab. With it off they wait in the Local test tab until the user picks them.
     * Returns how many new items arrived.
     */
    private suspend fun handleReceived(
        proxies: List<TelegramProxyManager.TelegramProxy>,
        freshGuids: List<String>,
        testConfigs: Boolean,
    ): Int {
        if (LocalTestManager.saveAllEnabled()) {
            val proxyCount = receiveProxies(proxies)
            when {
                freshGuids.isNotEmpty() -> deliverReceivedToMain(freshGuids, testThem = testConfigs)
                proxyCount > 0 -> showTelegramTab()
                else -> setupGroupTab(forceRefresh = true).join()
            }
            return freshGuids.size + proxyCount
        }
        val staged = stagePendingProxies(proxies)
        setupGroupTab(forceRefresh = true).join()
        withContext(Dispatchers.Main) {
            // Stay on the Local test tab so the received items can be selected there.
            subscriptionIdChanged(LocalTestManager.GROUP_ID)
            if (testConfigs && freshGuids.isNotEmpty()) testAllRealPing(onlyGuids = freshGuids)
        }
        return freshGuids.size + staged
    }

    private var pendingProxyJob: Job? = null

    /** Keeps received proxies in the Local test tab (not yet saved); returns how many were new. */
    private fun stagePendingProxies(proxies: List<TelegramProxyManager.TelegramProxy>): Int {
        if (proxies.isEmpty()) return 0
        val saved = TelegramProxyStore.load().mapTo(HashSet()) { it.id }
        var added = 0
        _uiState.update { st ->
            val known = st.localTest.pendingProxies.mapTo(HashSet()) { it.proxy.id }
            val fresh = proxies.filter { it.id !in saved && known.add(it.id) }
            added = fresh.size
            st.copy(
                localTest = st.localTest.copy(
                    pendingProxies = st.localTest.pendingProxies +
                        fresh.map { TelegramRow(it, countryCode = ServerCountryResolver.cached(it.server)) }
                )
            )
        }
        if (added > 0) testPendingProxies()
        return added
    }

    private fun testPendingProxies() {
        pendingProxyJob?.cancel()
        pendingProxyJob = viewModelScope.launch(ioDispatcher) {
            val proxies = _uiState.value.localTest.pendingProxies.map { it.proxy }
            coroutineScope {
                val limiter = Semaphore(TELEGRAM_CONCURRENCY)
                proxies.map { proxy ->
                    async {
                        val ms = limiter.withPermit { TelegramProxyManager.ping(proxy) }
                        updatePendingProxy(proxy.id) {
                            it.copy(ping = if (ms >= 0) TelegramPing.Done(ms) else TelegramPing.Failed)
                        }
                        ServerCountryResolver.resolve(proxy.server)?.let { code ->
                            updatePendingProxy(proxy.id) { it.copy(countryCode = code) }
                        }
                    }
                }.awaitAll()
            }
        }
    }

    private fun updatePendingProxy(id: String, change: (TelegramRow) -> TelegramRow) {
        _uiState.update { s ->
            s.copy(localTest = s.localTest.copy(
                pendingProxies = s.localTest.pendingProxies.map { if (it.proxy.id == id) change(it) else it }
            ))
        }
    }

    private fun clearLocalTestSelection() {
        _uiState.update {
            it.copy(localTest = it.localTest.copy(selectedGuids = emptySet(), selectedProxyIds = emptySet()))
        }
    }

    /**
     * OK on the selection bar: saves the picked configs and proxies into the collection. A single config
     * glides into the main tab, becomes the selected server and glows; several are just saved.
     */
    private fun saveSelectedToCollection() {
        val state = _uiState.value.localTest
        val guids = state.selectedGuids.toList()
        val proxies = state.pendingProxies.filter { it.proxy.id in state.selectedProxyIds }.map { it.proxy }
        if (guids.isEmpty() && proxies.isEmpty()) return
        viewModelScope.launch(ioDispatcher) {
            try {
                _uiState.update { st ->
                    val picked = proxies.mapTo(HashSet()) { it.id }
                    st.copy(
                        localTest = st.localTest.copy(
                            selectedGuids = emptySet(),
                            selectedProxyIds = emptySet(),
                            pendingProxies = st.localTest.pendingProxies.filter { it.proxy.id !in picked },
                        )
                    )
                }
                val single = guids.size + proxies.size == 1
                val newGuids = if (guids.isEmpty()) emptyList() else LocalTestManager.moveGuidsToMain(guids)
                val proxyCount = receiveProxies(proxies)
                when {
                    single && newGuids.size == 1 -> {
                        deliverReceivedToMain(newGuids, testThem = false)
                        _uiState.update { it.copy(autoSelectGuid = newGuids.first()) }
                    }
                    single && proxyCount == 1 -> showTelegramTab()
                    else -> {
                        toast(dataSource.getString(R.string.local_test_moved, newGuids.size + proxyCount))
                        setupGroupTab(forceRefresh = true).join()
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to save the selection", e)
                toastError(R.string.toast_failure)
            }
        }
    }

    /** Saves received Telegram proxies into the proxy tab (without leaving the current tab). Returns how many were new. */
    private suspend fun receiveProxies(proxies: List<TelegramProxyManager.TelegramProxy>): Int {
        if (proxies.isEmpty()) return 0
        val created = TelegramProxyStore.ensureGroup(dataSource.getString(R.string.telegram_tab_title))
        val added = TelegramProxyStore.add(proxies)
        if (created) setupGroupTab(forceRefresh = true).join()
        if (added.isEmpty()) return 0
        _uiState.update { state ->
            val known = state.telegram.rows.mapTo(HashSet()) { it.proxy.id }
            val newRows = added.filter { it.id !in known }
                .map { p -> TelegramRow(p, countryCode = ServerCountryResolver.cached(p.server)) }
            state.copy(telegram = state.telegram.copy(rows = state.telegram.rows + newRows))
        }
        telegramTestAll()
        return added.size
    }

    /** Glides slowly to the proxy tab; used when only proxies were received. */
    private suspend fun showTelegramTab() {
        withContext(Dispatchers.Main) {
            _uiState.update { it.copy(slowSlide = true) }
            subscriptionIdChanged(TelegramProxyStore.GROUP_ID)
        }
    }

    /** "Share as local": keeps one config or proxy link in the server so others get it on their next fetch. */
    private fun shareLinkAsLocal(link: String?) {
        val ok = !link.isNullOrBlank() && localShareServer.addLink(link)
        if (ok) toast(dataSource.getString(R.string.share_as_local_done)) else toastError(R.string.toast_failure)
    }

    /**
     * Moves freshly received configs from "Local test" into the main group, slides the pager
     * slowly to the main page and makes the new cards glow; the glow is cleared after a few seconds.
     */
    private suspend fun deliverReceivedToMain(guids: List<String>, testThem: Boolean) {
        if (guids.isEmpty()) {
            setupGroupTab(forceRefresh = true).join()
            return
        }
        val newGuids = LocalTestManager.moveGuidsToMain(guids)
        setupGroupTab(forceRefresh = true).join()
        if (newGuids.isEmpty()) return
        val mainId = AppConfig.DEFAULT_SUBSCRIPTION_ID
        withContext(Dispatchers.Main) {
            _uiState.update { it.copy(highlightGuids = newGuids.toHashSet(), slowSlide = true) }
            subscriptionIdChanged(mainId)
            if (testThem) testAllRealPing(onlyGuids = newGuids)
        }
        viewModelScope.launch {
            kotlinx.coroutines.delay(HIGHLIGHT_DURATION_MS)
            _uiState.update { it.copy(highlightGuids = emptySet()) }
        }
    }

    // ---------- Telegram tab ----------
    private var telegramJob: Job? = null

    private fun onTelegramTab() = uiState.value.selectedGroupId == TelegramProxyStore.GROUP_ID

    /** Shows saved proxies right away (country from cache) and re-pings them in the background. */
    private fun telegramLoadSaved() {
        val saved = TelegramProxyStore.load()
        if (saved.isEmpty()) return
        _uiState.update {
            it.copy(telegram = it.telegram.copy(rows = saved.map { p -> TelegramRow(p, countryCode = ServerCountryResolver.cached(p.server)) }))
        }
        telegramTestAll()
    }

    private fun telegramAdd(text: String) {
        viewModelScope.launch(ioDispatcher) {
            val found = TelegramProxyManager.parse(text)
            if (found.isEmpty()) {
                toastError(R.string.telegram_proxy_empty)
                return@launch
            }
            val created = TelegramProxyStore.ensureGroup(dataSource.getString(R.string.telegram_tab_title))
            val added = TelegramProxyStore.add(found)
            if (created) setupGroupTab(forceRefresh = true).join()
            _uiState.update { state ->
                val known = state.telegram.rows.mapTo(HashSet()) { it.proxy.id }
                val newRows = added.filter { it.id !in known }
                    .map { p -> TelegramRow(p, countryCode = ServerCountryResolver.cached(p.server)) }
                state.copy(telegram = state.telegram.copy(rows = state.telegram.rows + newRows))
            }
            toast(dataSource.getString(R.string.telegram_added_count, added.size))
            subscriptionIdChanged(TelegramProxyStore.GROUP_ID)
            telegramTestAll()
        }
    }

    /** Pings every saved proxy and looks up its country, a few at a time. */
    private fun telegramTestAll() {
        telegramJob?.cancel()
        telegramJob = viewModelScope.launch(ioDispatcher) {
            val proxies = _uiState.value.telegram.rows.map { it.proxy }
            if (proxies.isEmpty()) return@launch
            _uiState.update { s ->
                s.copy(telegram = s.telegram.copy(
                    isTesting = true,
                    rows = s.telegram.rows.map { it.copy(ping = TelegramPing.Testing) }
                ))
            }
            try {
                coroutineScope {
                    val limiter = Semaphore(TELEGRAM_CONCURRENCY)
                    proxies.map { proxy ->
                        async {
                            val ms = limiter.withPermit { TelegramProxyManager.ping(proxy) }
                            val ping = if (ms >= 0) TelegramPing.Done(ms) else TelegramPing.Failed
                            updateTelegramRow(proxy.id) { it.copy(ping = ping) }
                            // The country does not depend on the ping result, so look it up either way.
                            val code = ServerCountryResolver.resolve(proxy.server)
                            if (code != null) updateTelegramRow(proxy.id) { it.copy(countryCode = code) }
                        }
                    }.awaitAll()
                }
                _uiState.update { s ->
                    s.copy(telegram = s.telegram.copy(
                        rows = s.telegram.rows.sortedBy { (it.ping as? TelegramPing.Done)?.millis ?: Long.MAX_VALUE }
                    ))
                }
            } finally {
                _uiState.update { it.copy(telegram = it.telegram.copy(isTesting = false)) }
            }
        }
    }

    private fun updateTelegramRow(id: String, change: (TelegramRow) -> TelegramRow) {
        _uiState.update { s ->
            s.copy(telegram = s.telegram.copy(rows = s.telegram.rows.map { if (it.proxy.id == id) change(it) else it }))
        }
    }

    private fun telegramRemove(id: String) {
        viewModelScope.launch(ioDispatcher) {
            TelegramProxyStore.remove(id)
            _uiState.update { s -> s.copy(telegram = s.telegram.copy(rows = s.telegram.rows.filter { it.proxy.id != id })) }
        }
    }

    private fun telegramRemoveAll() {
        viewModelScope.launch(ioDispatcher) {
            telegramJob?.cancel()
            TelegramProxyStore.clear()
            _uiState.update { it.copy(telegram = TelegramTabUiState()) }
        }
    }

    private fun toggleLocalTestServer() {
        viewModelScope.launch(ioDispatcher) {
            if (localShareServer.isRunning) {
                localShareServer.stop()
                _uiState.update { it.copy(localTest = it.localTest.copy(serverRunning = false, serverAddress = "")) }
                return@launch
            }
            if (!localShareServer.start(LocalShareServer.DEFAULT_PORT)) {
                toastError(R.string.local_test_server_failed)
                return@launch
            }
            val ip = findLanAddress()
            _uiState.update {
                it.copy(
                    localTest = it.localTest.copy(
                        serverRunning = true,
                        serverAddress = "${ip ?: "?"}:${localShareServer.port}",
                    )
                )
            }
        }
    }

    /** First private IPv4 address of an active interface (Wi-Fi/hotspot), or null. */
    private fun findLanAddress(): String? = try {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is java.net.Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress
    } catch (e: java.net.SocketException) {
        LogUtil.e(AppConfig.TAG, "LocalTest: failed to read LAN address", e)
        null
    }

    private fun localTestFetch(address: String) {
        if (LocalTestManager.buildConfigsUrl(address) == null) {
            toastError(R.string.local_test_bad_address)
            return
        }
        _uiState.update { it.copy(localTest = it.localTest.copy(busy = true)) }
        viewModelScope.launch(ioDispatcher) {
            try {
                LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))
                val text = LocalTestManager.fetchLinks(address)
                if (text == null) {
                    toastError(R.string.local_test_fetch_failed)
                    _uiState.update { it.copy(localTest = it.localTest.copy(busy = false)) }
                    return@launch
                }
                // Proxies go to the proxy tab, configs to the config tab.
                val (proxies, configText) = LocalTestManager.splitReceived(text)
                val before = dataSource.getServerGuidList(LocalTestManager.GROUP_ID)
                val count = if (configText.isBlank()) 0
                else dataSource.importBatchConfig(configText, LocalTestManager.GROUP_ID, true).first
                if (count <= 0 && proxies.isEmpty()) {
                    toastError(R.string.local_test_nothing_received)
                    _uiState.update { it.copy(localTest = it.localTest.copy(busy = false)) }
                    return@launch
                }
                // The server answered with usable configs, so remember it for the next fetch.
                LocalTestManager.saveAddress(address)
                val savedAddress = LocalTestManager.savedAddress()
                _uiState.update {
                    it.copy(localTest = it.localTest.copy(busy = false, savedAddress = savedAddress))
                }
                // A repeated fetch must not pile up copies of configs already here or already in main.
                val knownGuids = before.toHashSet()
                val addedGuids = dataSource.getServerGuidList(LocalTestManager.GROUP_ID)
                    .filter { it !in knownGuids }
                val existing = before + dataSource.getServerGuidList(AppConfig.DEFAULT_SUBSCRIPTION_ID)
                val duplicates = LocalTestManager.findDuplicateGuids(
                    existing = existing.mapNotNull { dataSource.decodeServerConfig(it) },
                    added = addedGuids.mapNotNull { guid -> dataSource.decodeServerConfig(guid)?.let { guid to it } },
                ).toHashSet()
                duplicates.forEach { dataSource.removeServer(it) }
                val freshGuids = addedGuids.filter { it !in duplicates }
                val total = handleReceived(proxies, freshGuids, testConfigs = true)
                toast(dataSource.getString(R.string.title_import_config_count, total))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: fetch flow failed", e)
                toastError(R.string.toast_failure)
                _uiState.update { it.copy(localTest = it.localTest.copy(busy = false)) }
            }
        }
    }

    // ---------- Update config ----------
    private var updateConfigJob: Job? = null

    /**
     * Menu "Update config": pulls the configs of the saved server into the main tab. A fetched config that
     * already exists replaces the old one in place; the toast reports how many arrived and how many repeated.
     * With no usable saved server it scans the network and, failing that, asks for the server's IP.
     */
    private fun updateConfig(manualAddress: String?) {
        if (updateConfigJob?.isActive == true) return
        _uiState.update { it.copy(localTest = it.localTest.copy(askServerAddress = false)) }
        updateConfigJob = viewModelScope.launch(ioDispatcher) {
            _isLoading.value = true
            try {
                runUpdateConfig(manualAddress)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "UpdateConfig: flow failed", e)
                toastError(R.string.toast_failure)
            } finally {
                _isLoading.value = false
            }
        }
    }

    private suspend fun runUpdateConfig(manualAddress: String?) {
        val (address, text) = findUpdateServer(manualAddress) ?: return
        val (proxies, configText) = LocalTestManager.splitReceived(text)
        LocalTestManager.ensureGroup(dataSource.getString(R.string.local_test_title))
        // Fetched configs are parsed into the Local test group first, then matched against the main group.
        val before = dataSource.getServerGuidList(LocalTestManager.GROUP_ID).toHashSet()
        if (configText.isNotBlank()) dataSource.importBatchConfig(configText, LocalTestManager.GROUP_ID, true)
        val fetched = dataSource.getServerGuidList(LocalTestManager.GROUP_ID)
            .filter { it !in before }
            .mapNotNull { guid -> dataSource.decodeServerConfig(guid)?.let { guid to it } }
        val received = fetched.size + proxies.size
        if (received == 0) {
            toastError(R.string.local_test_nothing_received)
            return
        }
        // The server answered with usable configs, so remember it for the next update.
        LocalTestManager.saveAddress(address)
        _uiState.update { it.copy(localTest = it.localTest.copy(savedAddress = LocalTestManager.savedAddress())) }

        val existing = dataSource.getServerGuidList(AppConfig.DEFAULT_SUBSCRIPTION_ID)
            .mapNotNull { guid -> dataSource.decodeServerConfig(guid)?.let { guid to it } }
        val plan = LocalTestManager.planUpdate(existing, fetched)
        LocalTestManager.applyReplacements(plan.replacements)
        (plan.replacements.keys + plan.repeatedInBatch).forEach { dataSource.removeServer(it) }

        val newProxies = receiveProxies(proxies)
        val duplicates = plan.duplicateCount + (proxies.size - newProxies).coerceAtLeast(0)
        if (plan.fresh.isNotEmpty()) {
            deliverReceivedToMain(plan.fresh, testThem = true)
        } else {
            setupGroupTab(forceRefresh = true).join()
        }
        toast(dataSource.getString(R.string.update_config_result, received, duplicates))
    }

    /**
     * Finds the server to update from and downloads its configs: the typed [manualAddress] if given,
     * else the saved server, else a server found on the local network. Returns the address with the raw
     * text, or null after reporting the failure; when nothing was found the screen is asked for the IP.
     */
    private suspend fun findUpdateServer(manualAddress: String?): Pair<String, String>? {
        if (manualAddress != null) {
            val address = LocalTestManager.normalizeAddress(manualAddress)
            if (address == null) {
                toastError(R.string.local_test_bad_address)
                askServerAddress()
                return null
            }
            val text = LocalTestManager.fetchLinks(address)
            if (text == null) {
                toastError(R.string.local_test_fetch_failed)
                askServerAddress()
                return null
            }
            return address to text
        }
        val saved = LocalTestManager.savedAddress()
        if (saved.isNotBlank()) {
            LocalTestManager.fetchLinks(saved)?.let { return saved to it }
        }
        val discovered = LocalTestManager.discoverServer()
        if (discovered != null) {
            LocalTestManager.fetchLinks(discovered)?.let { return discovered to it }
        }
        askServerAddress()
        return null
    }

    private fun askServerAddress() {
        _uiState.update { it.copy(localTest = it.localTest.copy(askServerAddress = true)) }
    }

    private fun localTestMoveGreenToMain() {
        viewModelScope.launch(ioDispatcher) {
            try {
                val moved = LocalTestManager.moveGreenToMain()
                if (moved > 0) {
                    toast(dataSource.getString(R.string.local_test_moved, moved))
                    setupGroupTab(forceRefresh = true)
                } else {
                    toastError(R.string.local_test_no_green)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: move to main failed", e)
                toastError(R.string.toast_failure)
            }
        }
    }

    fun triggerLocateSelectedServer() {
        val selected = dataSource.getSelectServer() ?: return
        val profile = dataSource.decodeServerConfig(selected) ?: return
        val groupId = profile.subscriptionId
        if (_uiState.value.groups.none { it.id == groupId }) return
        viewModelScope.launch(ioDispatcher) {
            updateGroupUi(groupId, loadGroup(groupId))
            if (_uiState.value.selectedGroupId != groupId) {
                dataSource.setSelectedSubscriptionId(groupId)
            }
            val target = LocateTarget(groupId, selected)
            _uiState.update {
                it.copy(selectedGroupId = groupId, locateTarget = target)
            }
        }
    }

    private fun consumeLocateTarget() {
        _uiState.update { it.copy(locateTarget = null) }
    }

    // ---------- Running state ----------
    private fun updateRunningState(running: Boolean, clearTestingText: Boolean = true) {
        if (!running || clearTestingText) testRequests.invalidateCurrent()
        _uiState.update { state ->
            state.copy(
                isRunning = running,
                isTesting = testRequests.isTesting,
                status = if (!clearTestingText && state.isRunning == running) state.status
                else if (running) MainStatus.Connected else MainStatus.Disconnected
            )
        }
    }

    override fun onCleared() {
        localShareServer.stop()
        setupGroupJob?.cancel()
        preloadJob?.cancel()
        selectedGroupLoadJob?.cancel()
        reloadJob?.cancel()
        filterJob?.cancel()
        cancelAllPing()
        dataSource.close()
        super.onCleared()
    }

    // ---------- Factory ----------
    class Factory(private val application: Application, private val dataSource: MainDataSource) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(application, dataSource) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }

    private companion object {
        const val TEST_RESULT_FLUSH_INTERVAL_MS = 500L

        /** How long newly received configs keep their colored border before it fades away. */
        const val HIGHLIGHT_DURATION_MS = 4_000L

        /** ID of the user's own default config list (no subscription). */
        const val MAIN_GROUP_ID = ""
        private const val TELEGRAM_CONCURRENCY = 8
    }
}
