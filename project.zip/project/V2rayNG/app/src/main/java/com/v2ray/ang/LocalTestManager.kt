package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.util.LogUtil
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Data operations behind the "Local test" tab. The tab is a regular subscription group
 * (fixed ID) so listing, ping and connect reuse the existing main-screen machinery.
 */
object LocalTestManager {
    const val GROUP_ID = "local_test"

    private const val CONNECT_TIMEOUT_MS = 5_000
    private const val READ_TIMEOUT_MS = 10_000
    private const val MAX_RESPONSE_CHARS = 1_000_000

    /** Creates the "Local test" group if missing; returns true when it was just created. */
    fun ensureGroup(remarks: String): Boolean {
        if (MmkvManager.decodeSubscription(GROUP_ID) != null) return false
        MmkvManager.encodeSubscription(
            GROUP_ID,
            SubscriptionItem(remarks = remarks, enabled = true, autoUpdate = false)
        )
        return true
    }

    /**
     * Turns user input ("192.168.1.5:8765" or "http://192.168.1.5:8765") into the /configs URL.
     * Only plain http and a host[:port] are accepted; returns null for anything else.
     */
    fun buildConfigsUrl(input: String): String? {
        val text = input.trim().removePrefix("http://").trimEnd('/')
        if (text.isEmpty() || text.contains('/') || text.contains(' ') || text.contains("://")) return null
        val host = text.substringBefore(':')
        val port = if (text.contains(':')) text.substringAfter(':').toIntOrNull() else LocalShareServer.DEFAULT_PORT
        if (host.isEmpty() || port == null || port !in 1..65535) return null
        if (!host.all { it.isLetterOrDigit() || it == '.' || it == '-' }) return null
        return "http://$host:$port/configs"
    }

    /** Blocking; call from Dispatchers.IO. Returns the raw text or null on failure. */
    fun fetchLinks(input: String): String? {
        val url = buildConfigsUrl(input) ?: return null
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                requestMethod = "GET"
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            connection.inputStream.bufferedReader().use { reader ->
                val buffer = CharArray(8192)
                val out = StringBuilder()
                while (out.length < MAX_RESPONSE_CHARS) {
                    val n = reader.read(buffer)
                    if (n < 0) break
                    out.append(buffer, 0, n)
                }
                out.toString()
            }
        } catch (e: IOException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: fetch failed", e)
            null
        } finally {
            connection?.disconnect()
        }
    }

    /** Share links of all the owner's own configs (every group except "Local test"). */
    fun ownerShareLinks(): List<String> {
        val inLocalTest = MmkvManager.decodeServerList(GROUP_ID).toSet()
        return AngConfigManager.shareLinks(MmkvManager.decodeAllServerList().filter { it !in inLocalTest })
    }

    /** Empties the "Local test" group so a new fetch replaces the old list instead of duplicating it. */
    fun clearGroup() = MmkvManager.removeServerViaSubid(GROUP_ID)

    /** Removes every server in the group whose last test was not green (delay <= 0). */
    fun removeNonGreen(): Int {
        val dead = MmkvManager.decodeServerList(GROUP_ID).filter { guid ->
            (MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L) <= 0L
        }
        MmkvManager.removeServers(dead, GROUP_ID)
        return dead.size
    }

    /**
     * Copies green servers into the main (default) group, keeping their ping result,
     * then removes them from "Local test". Returns the number moved.
     */
    fun moveGreenToMain(): Int {
        var moved = 0
        val movedGuids = mutableListOf<String>()
        MmkvManager.decodeServerList(GROUP_ID).forEach { guid ->
            val delay = MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L
            if (delay <= 0L) return@forEach
            val profile = MmkvManager.decodeServerConfig(guid) ?: return@forEach
            try {
                val newGuid = MmkvManager.encodeServerConfig("", profile.copy(subscriptionId = ""))
                MmkvManager.encodeServerTestDelayMillis(newGuid, delay)
                movedGuids += guid
                moved++
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to move profile $guid", e)
            }
        }
        MmkvManager.removeServers(movedGuids, GROUP_ID)
        return moved
    }
}
