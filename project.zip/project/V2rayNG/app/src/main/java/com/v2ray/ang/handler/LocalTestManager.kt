package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.util.LogUtil
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Data operations behind the "Local test" tab. The tab is a regular subscription group
 * (fixed ID) so listing, ping and connect reuse the existing main-screen machinery.
 */
object LocalTestManager {
    const val GROUP_ID = "local_test"

    private const val CONNECT_TIMEOUT_MS = 5_000
    private const val READ_TIMEOUT_MS = 10_000
    private const val MAX_RESPONSE_CHARS = 1_000_000

    /** Creates the "Local test" group if missing; returns true when it was just created. */
    fun ensureGroup(remarks: String): Boolean {
        if (MmkvManager.decodeSubscription(GROUP_ID) != null) return false
        MmkvManager.encodeSubscription(
            GROUP_ID,
            SubscriptionItem(remarks = remarks, enabled = true, autoUpdate = false)
        )
        return true
    }

    /**
     * Turns user input ("192.168.1.5:8765" or "http://192.168.1.5:8765") into the /configs URL.
     * Only plain http and a host[:port] are accepted; returns null for anything else.
     */
    fun buildConfigsUrl(input: String): String? {
        val text = input.trim().removePrefix("http://").trimEnd('/')
        if (text.isEmpty() || text.contains('/') || text.contains(' ') || text.contains("://")) return null
        val host = text.substringBefore(':')
        val port = if (text.contains(':')) text.substringAfter(':').toIntOrNull() else LocalShareServer.DEFAULT_PORT
        if (host.isEmpty() || port == null || port !in 1..65535) return null
        if (!host.all { it.isLetterOrDigit() || it == '.' || it == '-' }) return null
        return "http://$host:$port/configs"
    }

    /** Blocking; call from Dispatchers.IO. Returns the raw text or null on failure. */
    fun fetchLinks(input: String): String? {
        val url = buildConfigsUrl(input) ?: return null
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                requestMethod = "GET"
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            connection.inputStream.bufferedReader().use { reader ->
                val buffer = CharArray(8192)
                val out = StringBuilder()
                while (out.length < MAX_RESPONSE_CHARS) {
                    val n = reader.read(buffer)
                    if (n < 0) break
                    out.append(buffer, 0, n)
                }
                out.toString()
            }
        } catch (e: IOException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: fetch failed", e)
            null
        } finally {
            connection?.disconnect()
        }
    }

    /** GUIDs of all the owner's own configs (every group except "Local test"). */
    fun ownerGuids(): List<String> {
        val inLocalTest = MmkvManager.decodeServerList(GROUP_ID).toSet()
        return MmkvManager.decodeAllServerList().filter { it !in inLocalTest }
    }

    /** Links of every Telegram proxy the owner saved; shared together with the configs. */
    fun ownerProxyLinks(): List<String> = TelegramProxyStore.load().map { it.link }

    /** Everything the owner shares: all configs plus all Telegram proxies. */
    fun ownerAllLinks(): List<String> = ownerShareLinks(null) + ownerProxyLinks()

    /**
     * Splits received text into Telegram proxies (go to the proxy tab) and the remaining lines
     * (v2ray configs, go to the config tab).
     */
    fun splitReceived(text: String): Pair<List<TelegramProxyManager.TelegramProxy>, String> {
        val proxies = TelegramProxyManager.parse(text)
        val configText = text.lineSequence()
            .filterNot { TelegramProxyManager.containsProxy(it) }
            .joinToString("\n")
        return proxies to configText
    }

    /** The owner's own configs with their last ping result, for the "Share selection config" picker. */
    fun ownerConfigs(): List<OwnerConfig> = ownerGuids().mapNotNull { guid ->
        val profile = MmkvManager.decodeServerConfig(guid) ?: return@mapNotNull null
        OwnerConfig(
            guid = guid,
            remarks = profile.remarks,
            delayMillis = MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L,
        )
    }

    /** GUIDs of the owner's configs whose last ping succeeded (green). */
    fun greenOwnerGuids(): List<String> = pickGreen(ownerConfigs())

    /**
     * Share links of the owner's own configs. [guids] limits the result to those GUIDs;
     * null means every config of the owner. GUIDs outside the owner's configs are ignored.
     */
    fun ownerShareLinks(guids: Collection<String>? = null): List<String> {
        val owner = ownerGuids()
        val allowed = guids?.toHashSet()
        val wanted = if (allowed == null) owner else owner.filter { it in allowed }
        return AngConfigManager.shareLinks(wanted)
    }

    /** Keeps the GUIDs whose ping result is positive (green), in the given order. */
    fun pickGreen(configs: List<OwnerConfig>): List<String> =
        configs.filter { it.delayMillis > 0L }.map { it.guid }

    /**
     * Picks the GUIDs in [added] that repeat a profile in [existing] or an earlier entry of [added].
     * Complex profiles (policy groups, proxy chains) are never treated as duplicates.
     */
    fun findDuplicateGuids(existing: Collection<ProfileItem>, added: List<Pair<String, ProfileItem>>): List<String> {
        val seen = HashSet<ProfileItem>()
        existing.forEach { if (!it.configType.isComplexType()) seen.add(it.duplicateIdentity()) }
        return added.filter { (_, profile) ->
            !profile.configType.isComplexType() && !seen.add(profile.duplicateIdentity())
        }.map { it.first }
    }

    /** "Save all to my collection": when true everything received goes straight to the main/proxy tabs. Default on. */
    fun saveAllEnabled(): Boolean = MmkvManager.decodeSettingsBool(AppConfig.PREF_LOCAL_TEST_SAVE_ALL, true)

    fun setSaveAllEnabled(enabled: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_TEST_SAVE_ALL, enabled)
    }

    /** Address of the last server that delivered configs successfully, or "" when none was saved yet. */
    fun savedAddress(): String = MmkvManager.decodeSettingsString(AppConfig.PREF_LOCAL_TEST_ADDRESS, "").orEmpty()

    /** Remembers [address] so the next fetch starts from the same server. Call only after a successful fetch. */
    fun saveAddress(address: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_TEST_ADDRESS, address.trim())
    }

    /**
     * Copies servers from "Local test" into the main (default) group, keeping their ping result,
     * then removes them from "Local test". [onlyGreen] limits the move to servers whose last ping
     * succeeded; false moves everything. Returns the number moved.
     */
    fun moveToMain(onlyGreen: Boolean): Int = moveGuidsToMain(null, onlyGreen).size

    /**
     * Moves the given [guids] (null = every server of "Local test") into the main group and returns
     * the NEW guids they got there, so the UI can highlight them. Ping results are kept.
     */
    fun moveGuidsToMain(guids: Collection<String>?, onlyGreen: Boolean = false): List<String> {
        val allowed = guids?.toHashSet()
        val movedGuids = mutableListOf<String>()
        val newGuids = mutableListOf<String>()
        // Reversed so the first received config ends up first (new profiles are inserted at the top).
        MmkvManager.decodeServerList(GROUP_ID).reversed().forEach { guid ->
            if (allowed != null && guid !in allowed) return@forEach
            val delay = MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L
            if (onlyGreen && delay <= 0L) return@forEach
            val profile = MmkvManager.decodeServerConfig(guid) ?: return@forEach
            try {
                val newGuid = MmkvManager.encodeServerConfig("", profile.copy(subscriptionId = ""))
                if (delay != 0L) MmkvManager.encodeServerTestDelayMillis(newGuid, delay)
                movedGuids += guid
                newGuids += newGuid
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to move profile $guid", e)
            }
        }
        MmkvManager.removeServers(movedGuids, GROUP_ID)
        return newGuids
    }

    /** Copies green servers into the main group; see [moveToMain]. */
    fun moveGreenToMain(): Int = moveToMain(onlyGreen = true)
}

/** One of the owner's own configs as listed in the share picker. */
data class OwnerConfig(val guid: String, val remarks: String, val delayMillis: Long)
