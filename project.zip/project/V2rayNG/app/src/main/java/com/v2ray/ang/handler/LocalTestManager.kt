package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.util.LogUtil
import java.io.IOException
import com.google.gson.Gson
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketException
import java.net.URL
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors

/**
 * Data operations behind the "Local test" tab. The tab is a regular subscription group
 * (fixed ID) so listing, ping and connect reuse the existing main-screen machinery.
 */
object LocalTestManager {
    const val GROUP_ID = "local_test"

    private const val CONNECT_TIMEOUT_MS = 5_000
    private const val READ_TIMEOUT_MS = 10_000
    private const val MAX_RESPONSE_CHARS = 1_000_000
    private const val PROBE_CONNECT_TIMEOUT_MS = 400
    private const val SCAN_THREADS = 64
    private const val FETCH_ATTEMPTS = 3
    private const val RETRY_DELAY_MS = 600L

    /** Creates the "Local test" group if missing; returns true when it was just created. */
    fun ensureGroup(remarks: String): Boolean {
        if (MmkvManager.decodeSubscription(GROUP_ID) != null) return false
        MmkvManager.encodeSubscription(
            GROUP_ID,
            SubscriptionItem(remarks = remarks, enabled = true, autoUpdate = false)
        )
        return true
    }

    /**
     * Turns user input ("192.168.1.5:8765" or "http://192.168.1.5:8765") into the /configs URL.
     * Only plain http and a host[:port] are accepted; returns null for anything else.
     */
    fun buildConfigsUrl(input: String): String? {
        val text = input.trim().removePrefix("http://").trimEnd('/')
        if (text.isEmpty() || text.contains('/') || text.contains(' ') || text.contains("://")) return null
        val host = text.substringBefore(':')
        val port = if (text.contains(':')) text.substringAfter(':').toIntOrNull() else LocalShareServer.DEFAULT_PORT
        if (host.isEmpty() || port == null || port !in 1..65535) return null
        if (!host.all { it.isLetterOrDigit() || it == '.' || it == '-' }) return null
        return "http://$host:$port/configs"
    }

    /** "host:port" form of user input ("192.168.1.5" gets the default port), or null when invalid. */
    fun normalizeAddress(input: String): String? =
        buildConfigsUrl(input)?.removePrefix("http://")?.removeSuffix("/configs")

    private val VIRTUAL_INTERFACE_PREFIXES = listOf("tun", "tap", "ppp", "wg", "ipsec", "dummy", "rmnet", "ccmni", "v4-")

    /** True for VPN tunnels and mobile-data interfaces, whose private addresses are not a Wi-Fi/hotspot LAN. */
    private fun isVirtualInterface(ni: NetworkInterface): Boolean {
        val name = ni.name.lowercase()
        return ni.isPointToPoint || VIRTUAL_INTERFACE_PREFIXES.any { name.startsWith(it) }
    }

    /**
     * Private IPv4 addresses of this device's real LAN interfaces (Wi-Fi, hotspot, Ethernet), Wi-Fi first.
     * The VPN's own tunnel address (10.x) is skipped; otherwise the shown server IP is sometimes wrong
     * while the VPN is on and nobody can reach it.
     */
    fun lanIpv4Addresses(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback && !isVirtualInterface(it) }
            .sortedBy { ni ->
                val name = ni.name.lowercase()
                when {
                    name.startsWith("wlan") -> 0
                    name.startsWith("ap") || name.startsWith("swlan") -> 1
                    else -> 2
                }
            }
            .flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }
    } catch (e: SocketException) {
        LogUtil.e(AppConfig.TAG, "LocalTest: failed to read LAN addresses", e)
        emptyList()
    }

    /** The address other devices should use to reach this one, or null when there is no LAN. */
    fun primaryLanAddress(): String? = lanIpv4Addresses().firstOrNull()

    /** Every other host of the /24 network that contains [ip]; empty when [ip] is not a valid IPv4 address. */
    fun subnetHosts(ip: String): List<String> {
        val parts = ip.split('.')
        if (parts.size != 4 || parts.any { part -> part.toIntOrNull().let { it == null || it !in 0..255 } }) {
            return emptyList()
        }
        val prefix = parts.take(3).joinToString(".")
        return (1..254).map { "$prefix.$it" }.filter { it != ip }
    }

    /**
     * Looks for a running share server on the local network(s) of this device. Blocking; call from
     * Dispatchers.IO. Returns "ip:port" of the first host that answers like the share server, or null.
     */
    fun discoverServer(port: Int = LocalShareServer.DEFAULT_PORT): String? {
        val hosts = lanIpv4Addresses().flatMap { subnetHosts(it) }.distinct()
        if (hosts.isEmpty()) return null
        val pool = Executors.newFixedThreadPool(SCAN_THREADS)
        try {
            val completion = ExecutorCompletionService<String?>(pool)
            hosts.forEach { host -> completion.submit { probe(host, port) } }
            repeat(hosts.size) {
                val found = try {
                    completion.take().get()
                } catch (e: ExecutionException) {
                    null
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return null
                }
                if (found != null) return found
            }
            return null
        } finally {
            pool.shutdownNow()
        }
    }

    /** "host:port" when [host] has the port open and /configs answers with HTTP 200, otherwise null. */
    private fun probe(host: String, port: Int): String? {
        try {
            Socket().use { it.connect(InetSocketAddress(host, port), PROBE_CONNECT_TIMEOUT_MS) }
        } catch (e: IOException) {
            return null
        }
        val address = "$host:$port"
        return if (fetchLinks(address, attempts = 1) != null) address else null
    }

    /** Fetched configs matched against the configs already in the main group. */
    data class UpdatePlan(
        /** Fetched GUID -> GUID in the main group whose content it replaces. */
        val replacements: Map<String, String>,
        /** Fetched GUIDs that are new to the main group. */
        val fresh: List<String>,
        /** Fetched GUIDs that repeat an earlier fetched entry. */
        val repeatedInBatch: List<String>,
    ) {
        val duplicateCount: Int get() = replacements.size + repeatedInBatch.size
    }

    /**
     * Sorts [added] (fetched GUID + profile) into replacements of a profile in [existing] (GUID + profile),
     * new profiles and repeats inside [added]. Complex profiles (policy groups, proxy chains) are always new.
     */
    fun planUpdate(existing: List<Pair<String, ProfileItem>>, added: List<Pair<String, ProfileItem>>): UpdatePlan {
        val existingByIdentity = HashMap<ProfileItem, String>()
        existing.forEach { (guid, profile) ->
            if (!profile.configType.isComplexType()) existingByIdentity.putIfAbsent(profile.duplicateIdentity(), guid)
        }
        val seen = HashSet<ProfileItem>()
        val replacements = LinkedHashMap<String, String>()
        val fresh = mutableListOf<String>()
        val repeated = mutableListOf<String>()
        added.forEach { (guid, profile) ->
            if (profile.configType.isComplexType()) {
                fresh += guid
                return@forEach
            }
            val identity = profile.duplicateIdentity()
            if (!seen.add(identity)) {
                repeated += guid
                return@forEach
            }
            val target = existingByIdentity[identity]
            if (target != null) replacements[guid] = target else fresh += guid
        }
        return UpdatePlan(replacements, fresh, repeated)
    }

    /**
     * Overwrites each existing profile with the fetched one, keeping the existing GUID so its position,
     * selection and ping result stay. The fetched copies are left for the caller to remove.
     */
    fun applyReplacements(replacements: Map<String, String>) {
        replacements.forEach { (fetchedGuid, existingGuid) ->
            val fetched = MmkvManager.decodeServerConfig(fetchedGuid) ?: return@forEach
            val existing = MmkvManager.decodeServerConfig(existingGuid) ?: return@forEach
            try {
                MmkvManager.encodeServerConfig(existingGuid, fetched.copy(subscriptionId = existing.subscriptionId))
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to replace profile $existingGuid", e)
            }
        }
    }

    /**
     * Blocking; call from Dispatchers.IO. Returns the raw text or null on failure.
     * A flaky Wi-Fi often drops the first connection, so it tries up to [attempts] times
     * (with a short pause) before giving up.
     */
    fun fetchLinks(input: String, attempts: Int = FETCH_ATTEMPTS): String? {
        val url = buildConfigsUrl(input) ?: return null
        repeat(attempts.coerceAtLeast(1)) { attempt ->
            fetchOnce(url)?.let { return it }
            if (attempt < attempts - 1) {
                try {
                    Thread.sleep(RETRY_DELAY_MS)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return null
                }
            }
        }
        return null
    }

    private fun fetchOnce(url: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                requestMethod = "GET"
                useCaches = false
                setRequestProperty("Connection", "close")
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            connection.inputStream.bufferedReader().use { reader ->
                val buffer = CharArray(8192)
                val out = StringBuilder()
                while (out.length < MAX_RESPONSE_CHARS) {
                    val n = reader.read(buffer)
                    if (n < 0) break
                    out.append(buffer, 0, n)
                }
                out.toString()
            }
        } catch (e: IOException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: fetch failed", e)
            null
        } finally {
            connection?.disconnect()
        }
    }

    private val chatGson = Gson()

    /** Sends a chat message to the server at [address] ("ip" or "ip:port"). Blocking; call from Dispatchers.IO. */
    fun postMessage(address: String, payload: ChatPayload): Boolean {
        val host = normalizeAddress(address) ?: return false
        repeat(2) { attempt ->
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("http://$host/msg").openConnection() as HttpURLConnection).apply {
                    connectTimeout = CONNECT_TIMEOUT_MS
                    readTimeout = READ_TIMEOUT_MS
                    requestMethod = "POST"
                    doOutput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Connection", "close")
                }
                connection.outputStream.use { it.write(chatGson.toJson(payload).toByteArray(Charsets.UTF_8)) }
                if (connection.responseCode == HttpURLConnection.HTTP_OK) return true
            } catch (e: IOException) {
                LogUtil.e(AppConfig.TAG, "LocalTest: message post failed (attempt ${attempt + 1})", e)
            } finally {
                connection?.disconnect()
            }
        }
        return false
    }

    /** Messages the server at [address] queued for this device after id [since]; null when it cannot be reached. */
    fun pollMessages(address: String, since: Long): List<OutboxMessage>? {
        val host = normalizeAddress(address) ?: return null
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL("http://$host/poll?since=$since").openConnection() as HttpURLConnection).apply {
                connectTimeout = 3_000
                readTimeout = READ_TIMEOUT_MS
                requestMethod = "GET"
                useCaches = false
                setRequestProperty("Connection", "close")
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            chatGson.fromJson(text, Array<OutboxMessage>::class.java)?.toList().orEmpty()
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "LocalTest: poll failed", e)
            null
        } finally {
            connection?.disconnect()
        }
    }

    /** GUIDs of all the owner's own configs (every group except "Local test"). */
    fun ownerGuids(): List<String> {
        val inLocalTest = MmkvManager.decodeServerList(GROUP_ID).toSet()
        return MmkvManager.decodeAllServerList().filter { it !in inLocalTest }
    }

    /** Links of every Telegram proxy the owner saved; shared together with the configs. */
    fun ownerProxyLinks(): List<String> = TelegramProxyStore.load().map { it.link }

    /** Everything the owner shares: all configs plus all Telegram proxies. */
    fun ownerAllLinks(): List<String> = ownerShareLinks(null) + ownerProxyLinks()

    /**
     * Splits received text into Telegram proxies (go to the proxy tab) and the remaining lines
     * (v2ray configs, go to the config tab).
     */
    fun splitReceived(text: String): Pair<List<TelegramProxyManager.TelegramProxy>, String> {
        val proxies = TelegramProxyManager.parse(text)
        val configText = text.lineSequence()
            .filterNot { TelegramProxyManager.containsProxy(it) }
            .joinToString("\n")
        return proxies to configText
    }

    /** The owner's own configs with their last ping result, for the "Share selection config" picker. */
    fun ownerConfigs(): List<OwnerConfig> = ownerGuids().mapNotNull { guid ->
        val profile = MmkvManager.decodeServerConfig(guid) ?: return@mapNotNull null
        OwnerConfig(
            guid = guid,
            remarks = profile.remarks,
            delayMillis = MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L,
        )
    }

    /** GUIDs of the owner's configs whose last ping succeeded (green). */
    fun greenOwnerGuids(): List<String> = pickGreen(ownerConfigs())

    /**
     * Share links of the owner's own configs. [guids] limits the result to those GUIDs;
     * null means every config of the owner. GUIDs outside the owner's configs are ignored.
     */
    fun ownerShareLinks(guids: Collection<String>? = null): List<String> {
        val owner = ownerGuids()
        val allowed = guids?.toHashSet()
        val wanted = if (allowed == null) owner else owner.filter { it in allowed }
        return AngConfigManager.shareLinks(wanted)
    }

    /** Keeps the GUIDs whose ping result is positive (green), in the given order. */
    fun pickGreen(configs: List<OwnerConfig>): List<String> =
        configs.filter { it.delayMillis > 0L }.map { it.guid }

    /**
     * Picks the GUIDs in [added] that repeat a profile in [existing] or an earlier entry of [added].
     * Complex profiles (policy groups, proxy chains) are never treated as duplicates.
     */
    fun findDuplicateGuids(existing: Collection<ProfileItem>, added: List<Pair<String, ProfileItem>>): List<String> {
        val seen = HashSet<ProfileItem>()
        existing.forEach { if (!it.configType.isComplexType()) seen.add(it.duplicateIdentity()) }
        return added.filter { (_, profile) ->
            !profile.configType.isComplexType() && !seen.add(profile.duplicateIdentity())
        }.map { it.first }
    }

    /** "Save all to my collection": when true everything received goes straight to the main/proxy tabs. Default on. */
    fun saveAllEnabled(): Boolean = MmkvManager.decodeSettingsBool(AppConfig.PREF_LOCAL_TEST_SAVE_ALL, true)

    fun setSaveAllEnabled(enabled: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_TEST_SAVE_ALL, enabled)
    }

    /** Address of the last server that delivered configs successfully, or "" when none was saved yet. */
    fun savedAddress(): String = MmkvManager.decodeSettingsString(AppConfig.PREF_LOCAL_TEST_ADDRESS, "").orEmpty()

    /** Remembers [address] so the next fetch starts from the same server. Call only after a successful fetch. */
    fun saveAddress(address: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_TEST_ADDRESS, address.trim())
    }

    /**
     * Copies servers from "Local test" into the main (default) group, keeping their ping result,
     * then removes them from "Local test". [onlyGreen] limits the move to servers whose last ping
     * succeeded; false moves everything. Returns the number moved.
     */
    fun moveToMain(onlyGreen: Boolean): Int = moveGuidsToMain(null, onlyGreen).size

    /**
     * Moves the given [guids] (null = every server of "Local test") into the main group and returns
     * the NEW guids they got there, so the UI can highlight them. Ping results are kept.
     */
    fun moveGuidsToMain(guids: Collection<String>?, onlyGreen: Boolean = false): List<String> {
        val allowed = guids?.toHashSet()
        val movedGuids = mutableListOf<String>()
        val newGuids = mutableListOf<String>()
        // Reversed so the first received config ends up first (new profiles are inserted at the top).
        MmkvManager.decodeServerList(GROUP_ID).reversed().forEach { guid ->
            if (allowed != null && guid !in allowed) return@forEach
            val delay = MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L
            if (onlyGreen && delay <= 0L) return@forEach
            val profile = MmkvManager.decodeServerConfig(guid) ?: return@forEach
            try {
                val newGuid = MmkvManager.encodeServerConfig("", profile.copy(subscriptionId = ""))
                if (delay != 0L) MmkvManager.encodeServerTestDelayMillis(newGuid, delay)
                movedGuids += guid
                newGuids += newGuid
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "LocalTest: failed to move profile $guid", e)
            }
        }
        MmkvManager.removeServers(movedGuids, GROUP_ID)
        return newGuids
    }

    /** Copies green servers into the main group; see [moveToMain]. */
    fun moveGreenToMain(): Int = moveToMain(onlyGreen = true)
}

/** One of the owner's own configs as listed in the share picker. */
data class OwnerConfig(val guid: String, val remarks: String, val delayMillis: Long)
