package com.v2ray.ang.handler

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.v2ray.ang.AppConfig
import com.v2ray.ang.util.LogUtil
import java.io.ByteArrayOutputStream

/** Turns a picked photo into a small base64 JPEG for the local chat, and back into a bitmap for display. */
object ChatImageCodec {
    private const val MAX_SIDE = 1024
    private const val MAX_BYTES = 600 * 1024

    /** Blocking; call from Dispatchers.IO. Returns null when the image cannot be read. */
    fun encodeUri(context: Context, uri: Uri): String? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > MAX_SIDE * 2 || bounds.outHeight / sample > MAX_SIDE * 2) sample *= 2
        val decoded = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (decoded == null) {
            null
        } else {
            val scale = MAX_SIDE.toFloat() / maxOf(decoded.width, decoded.height)
            val bitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(decoded, (decoded.width * scale).toInt().coerceAtLeast(1), (decoded.height * scale).toInt().coerceAtLeast(1), true)
            } else decoded
            var quality = 82
            var bytes: ByteArray
            do {
                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
                bytes = out.toByteArray()
                quality -= 12
            } while (bytes.size > MAX_BYTES && quality > 30)
            if (bytes.size > MAX_BYTES) null else Base64.encodeToString(bytes, Base64.NO_WRAP)
        }
    } catch (e: Exception) {
        LogUtil.e(AppConfig.TAG, "LocalTest: failed to encode image", e)
        null
    }

    fun decode(base64: String): Bitmap? = try {
        val bytes = Base64.decode(base64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (e: Exception) {
        null
    }
}
