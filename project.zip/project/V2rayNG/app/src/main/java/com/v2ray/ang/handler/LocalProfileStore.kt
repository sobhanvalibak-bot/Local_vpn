package com.v2ray.ang.handler

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.v2ray.ang.AppConfig
import com.v2ray.ang.util.LogUtil
import java.io.ByteArrayOutputStream
import java.io.File

/** Result of choosing a banner. */
enum class BannerResult { OK, TOO_LARGE, UNSUPPORTED, FAILED }

/**
 * This device's Local test profile: a display name, a small avatar and a banner (an image or a short MP4).
 * Other devices see it instead of this device's IP. Everything here is blocking file work: call it from Dispatchers.IO.
 */
object LocalProfileStore {
    private const val AVATAR_SIDE_PX = 160
    private const val BANNER_MAX_SIDE_PX = 1024

    fun name(): String = MmkvManager.decodeSettingsString(AppConfig.PREF_LOCAL_PROFILE_NAME).orEmpty()

    fun saveName(raw: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_PROFILE_NAME, LocalProfileRules.cleanName(raw))
    }

    fun avatarFile(context: Context) = File(context.filesDir, AppConfig.LOCAL_PROFILE_AVATAR_FILE)

    fun bannerMime(): String? =
        MmkvManager.decodeSettingsString(AppConfig.PREF_LOCAL_PROFILE_BANNER_MIME)?.takeIf { LocalProfileRules.isValidBannerMime(it) }

    /** The banner file for the stored MIME type, or null when there is no banner. */
    fun bannerFile(context: Context): File? {
        val mime = bannerMime() ?: return null
        return File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + extensionOf(mime)).takeIf { it.exists() }
    }

    fun extensionOf(mime: String?): String = if (LocalProfileRules.isVideo(mime)) ".mp4" else ".jpg"

    /** Square-crops the picked image to a small JPEG. A failed save leaves the previous avatar untouched. */
    fun saveAvatar(context: Context, uri: Uri): Boolean = try {
        val source = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (source == null) {
            false
        } else {
            val side = minOf(source.width, source.height)
            val square = Bitmap.createBitmap(source, (source.width - side) / 2, (source.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, AVATAR_SIDE_PX, AVATAR_SIDE_PX, true)
            writeAtomically(avatarFile(context)) { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        }
    } catch (e: Exception) {
        LogUtil.e(AppConfig.TAG, "LocalProfile: failed to save avatar", e)
        false
    }

    fun clearAvatar(context: Context) {
        avatarFile(context).delete()
    }

    /** Saves a banner: an image (scaled to a JPEG) or an MP4 up to [LocalProfileRules.MAX_BANNER_BYTES]. */
    fun saveBanner(context: Context, uri: Uri): BannerResult = try {
        val type = context.contentResolver.getType(uri).orEmpty()
        when {
            type.startsWith("image/") -> saveImageBanner(context, uri)
            type == LocalProfileRules.MIME_MP4 -> saveVideoBanner(context, uri)
            else -> BannerResult.UNSUPPORTED
        }
    } catch (e: Exception) {
        LogUtil.e(AppConfig.TAG, "LocalProfile: failed to save banner", e)
        BannerResult.FAILED
    }

    private fun saveImageBanner(context: Context, uri: Uri): BannerResult {
        val source = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: return BannerResult.FAILED
        val scale = BANNER_MAX_SIDE_PX.toFloat() / maxOf(source.width, source.height)
        val bitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true)
        } else source
        var quality = 82
        var bytes: ByteArray
        do {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bytes = out.toByteArray()
            quality -= 12
        } while (bytes.size > LocalProfileRules.MAX_BANNER_BYTES && quality > 30)
        if (bytes.size > LocalProfileRules.MAX_BANNER_BYTES) return BannerResult.TOO_LARGE
        return storeBanner(context, LocalProfileRules.MIME_JPEG, bytes)
    }

    /** Streams the video straight into the banner file, so a 25 MB clip is never held in memory. */
    private fun saveVideoBanner(context: Context, uri: Uri): BannerResult {
        val target = File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + ".mp4")
        val temp = File(context.filesDir, target.name + ".tmp")
        var total = 0L
        try {
            val input = context.contentResolver.openInputStream(uri) ?: return BannerResult.FAILED
            input.use { source ->
                temp.outputStream().use { out ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val read = source.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > LocalProfileRules.MAX_BANNER_BYTES) {
                            temp.delete()
                            return BannerResult.TOO_LARGE
                        }
                        out.write(buffer, 0, read)
                    }
                }
            }
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
        if (total == 0L || !temp.renameTo(target)) {
            temp.delete()
            return BannerResult.FAILED
        }
        File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + ".jpg").delete()
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_PROFILE_BANNER_MIME, LocalProfileRules.MIME_MP4)
        return BannerResult.OK
    }

    private fun storeBanner(context: Context, mime: String, bytes: ByteArray): BannerResult {
        val target = File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + extensionOf(mime))
        if (!writeAtomically(target) { it.write(bytes) }) return BannerResult.FAILED
        // The other extension belongs to the previous banner.
        File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + extensionOf(if (mime == LocalProfileRules.MIME_MP4) LocalProfileRules.MIME_JPEG else LocalProfileRules.MIME_MP4)).delete()
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_PROFILE_BANNER_MIME, mime)
        return BannerResult.OK
    }

    fun clearBanner(context: Context) {
        File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + ".jpg").delete()
        File(context.filesDir, AppConfig.LOCAL_PROFILE_BANNER_FILE + ".mp4").delete()
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_PROFILE_BANNER_MIME, "")
    }

    fun avatarBase64(context: Context): String? =
        avatarFile(context).takeIf { it.exists() }?.let { Base64.encodeToString(it.readBytes(), Base64.NO_WRAP) }

    private fun writeAtomically(target: File, write: (java.io.OutputStream) -> Unit): Boolean = try {
        val temp = File(target.parentFile, target.name + ".tmp")
        temp.outputStream().use(write)
        temp.renameTo(target)
    } catch (e: Exception) {
        LogUtil.e(AppConfig.TAG, "LocalProfile: failed to write ${target.name}", e)
        false
    }
}
