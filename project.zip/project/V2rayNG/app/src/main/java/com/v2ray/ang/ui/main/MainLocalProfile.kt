package com.v2ray.ang.ui.main

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.Settings
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.viewinterop.AndroidView
import com.v2ray.ang.R
import com.v2ray.ang.handler.LocalProfileRules
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Round profile picture; shows the first letter of [fallback] when there is no picture. */
@Composable
fun ProfileAvatar(bitmap: Bitmap?, fallback: String, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            // Decorative next to the name, which is always shown as text.
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Text(
                text = fallback.trim().take(1).uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }
    }
}

/**
 * Banner of a profile: a picture, or a short MP4 played muted in a loop. When the system's animations are
 * turned off the video stays on its first frame. Without a banner it is a plain coloured band.
 */
@Composable
fun ProfileBanner(mime: String?, path: String?, modifier: Modifier = Modifier, version: Long = 0L) {
    val description = stringResource(R.string.local_profile_banner)
    val shape = Modifier
        .fillMaxWidth()
        .semantics { contentDescription = description }
    Box(modifier = modifier.then(shape).background(MaterialTheme.colorScheme.surfaceVariant)) {
        if (path == null) return@Box
        if (LocalProfileRules.isVideo(mime)) {
            val context = LocalContext.current
            val animationsOn = remember {
                Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) != 0f
            }
            val view = remember(path, version) {
                VideoView(context).apply {
                    setOnPreparedListener { player ->
                        player.isLooping = true
                        player.setVolume(0f, 0f)
                        if (!animationsOn) seekTo(1)
                    }
                    setVideoPath(path)
                    if (animationsOn) start()
                }
            }
            DisposableEffect(view) { onDispose { view.stopPlayback() } }
            AndroidView(factory = { view }, modifier = Modifier.fillMaxSize())
        } else {
            val bitmap by produceState<Bitmap?>(null, path, version) {
                value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(path) }.getOrNull() }
            }
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

/** Editor of this device's own profile, shown at the top of the Local test panel. */
@Composable
fun MyProfileCard(profile: MyProfileUi, onAction: (MainAction) -> Unit) {
    var name by rememberSaveable(profile.name) { mutableStateOf(profile.name) }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onAction(MainAction.LocalTestSetAvatar(uri))
    }
    val bannerPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onAction(MainAction.LocalTestSetBanner(uri))
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            stringResource(R.string.local_profile_my_title),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        ProfileBanner(profile.bannerMime, profile.bannerPath, Modifier.height(96.dp).clip(RoundedCornerShape(12.dp)), profile.bannerVersion)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { bannerPicker.launch(arrayOf("image/*", LocalProfileRules.MIME_MP4)) }) {
                Text(stringResource(R.string.local_profile_pick_banner), maxLines = 1)
            }
            if (profile.bannerPath != null) {
                TextButton(onClick = { onAction(MainAction.LocalTestClearBanner) }) {
                    Text(stringResource(R.string.local_profile_remove), maxLines = 1)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ProfileAvatar(profile.avatar, profile.name, 52.dp)
            OutlinedButton(onClick = { avatarPicker.launch("image/*") }) {
                Text(stringResource(R.string.local_profile_pick_avatar), maxLines = 1)
            }
            if (profile.avatar != null) {
                TextButton(onClick = { onAction(MainAction.LocalTestClearAvatar) }) {
                    Text(stringResource(R.string.local_profile_remove), maxLines = 1)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(LocalProfileRules.MAX_NAME_CHARS) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text(stringResource(R.string.local_profile_name)) },
            )
            Button(
                onClick = { onAction(MainAction.LocalTestSaveProfileName(name)) },
                enabled = LocalProfileRules.cleanName(name) != profile.name,
            ) {
                Text(stringResource(R.string.local_profile_save), maxLines = 1)
            }
        }
    }
}

/**
 * Full-screen profile page of one device: a banner (picture or looping video) fading into the page, the picture
 * overlapping it, the name with an online badge, quick actions, and the configs the device shared as cards.
 */
@Composable
fun LocalProfileScreen(state: LocalTestUiState, onAction: (MainAction) -> Unit) {
    val ip = state.profilePeer ?: return
    val peer = state.peers.firstOrNull { it.ip == ip }
    val profile = state.peerProfiles[ip]
    val title = profile?.name?.ifBlank { null } ?: ip
    val online = peer?.online == true
    val colors = MaterialTheme.colorScheme
    val avatarSize = 96.dp

    BackHandler { onAction(MainAction.LocalTestCloseProfile) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            // Swallow touches so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.WindowInsets.navigationBars.asPaddingValues(),
        ) {
            item {
                Box {
                    ProfileBanner(profile?.bannerMime, profile?.bannerPath, Modifier.height(230.dp), profile?.bannerVersion ?: 0L)
                    // Fades the banner into the page so the name below stays readable on any picture.
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                    0.55f to androidx.compose.ui.graphics.Color.Transparent,
                                    1f to colors.background,
                                )
                            )
                    )
                }
            }
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .offset(y = -(avatarSize / 2)),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(avatarSize + 8.dp)
                            .background(colors.background, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        ProfileAvatar(profile?.avatar, title, avatarSize)
                    }
                    Text(
                        title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (online) colors.primary else colors.outline, CircleShape)
                        )
                        Text(
                            stringResource(if (online) R.string.local_test_online else R.string.local_test_offline),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (online) colors.primary else colors.outline,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                onAction(MainAction.LocalTestCloseProfile)
                                onAction(MainAction.LocalTestOpenChat(ip))
                            },
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.local_profile_message), maxLines = 1) }
                        OutlinedButton(
                            onClick = { onAction(MainAction.LocalTestAddReceived(state.profileConfigs.joinToString("\n") { it.link })) },
                            enabled = state.profileConfigs.isNotEmpty(),
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.local_profile_add_all), maxLines = 1) }
                    }
                }
            }
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .offset(y = -(avatarSize / 2) + 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        stringResource(R.string.local_profile_configs),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (state.profileConfigs.isNotEmpty()) {
                        Surface(shape = CircleShape, color = colors.secondaryContainer) {
                            Text(
                                state.profileConfigs.size.toString(),
                                style = MaterialTheme.typography.labelMedium,
                                color = colors.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            )
                        }
                    }
                }
            }
            if (state.profileConfigs.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = colors.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .offset(y = -(avatarSize / 2) + 16.dp),
                    ) {
                        Text(
                            stringResource(R.string.local_profile_no_configs),
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.onSurfaceVariant,
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                }
            } else {
                items(state.profileConfigs, key = { it.link }) { config ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = colors.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 20.dp, bottom = 10.dp)
                            .offset(y = -(avatarSize / 2) + 16.dp),
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Surface(shape = RoundedCornerShape(8.dp), color = colors.primaryContainer) {
                                Text(
                                    config.protocol,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    maxLines = 1,
                                )
                            }
                            Text(
                                config.name,
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            androidx.compose.material3.FilledTonalButton(onClick = { onAction(MainAction.LocalTestAddReceived(config.link)) }) {
                                Text(stringResource(R.string.local_profile_add), maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        // Back button over the banner, clear of the status bar.
        androidx.compose.material3.FilledTonalButton(
            onClick = { onAction(MainAction.LocalTestCloseProfile) },
            modifier = Modifier
                .windowInsetsPadding(androidx.compose.foundation.layout.WindowInsets.statusBars)
                .padding(12.dp),
        ) {
            Text(stringResource(R.string.local_test_chat_back))
        }
    }
}
