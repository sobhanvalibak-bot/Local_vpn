package com.v2ray.ang.handler

import com.v2ray.ang.enums.DefaultTabSort

/** Test results of one profile, as the ranking sees them. */
data class RankedServer(
    val guid: String,
    /** Positive: measured ping. 0: never tested. Negative: failed. */
    val delayMillis: Long,
    /** Positive: measured download speed. 0: not measured or failed. */
    val downloadBytesPerSec: Long,
)

/** Pure ordering rules for the Default tab and for the notification's "Change" action. */
object ServerRanking {

    /**
     * Orders [items] by [mode]. The sort is stable, so profiles that tie or have no result keep their stored order.
     * - [DefaultTabSort.TIME]: unchanged.
     * - [DefaultTabSort.DOWNLOAD]: highest speed first, ping breaks ties; profiles without a speed come last.
     * - [DefaultTabSort.PING]: lowest ping first; untested profiles, then failed ones, come last.
     */
    fun sort(items: List<RankedServer>, mode: DefaultTabSort): List<RankedServer> = when (mode) {
        DefaultTabSort.TIME -> items
        DefaultTabSort.DOWNLOAD -> items.sortedWith(
            compareByDescending<RankedServer> { it.downloadBytesPerSec > 0L }
                .thenByDescending { it.downloadBytesPerSec }
                .thenBy { pingRank(it.delayMillis) }
        )
        DefaultTabSort.PING -> items.sortedBy { pingRank(it.delayMillis) }
    }

    /** The profile with the highest measured download speed, or null when none was measured. */
    fun bestDownload(items: List<RankedServer>): String? =
        items.filter { it.downloadBytesPerSec > 0L }
            .maxWithOrNull(compareBy<RankedServer> { it.downloadBytesPerSec }.thenByDescending { pingRank(it.delayMillis) })
            ?.guid

    /** Smaller is better: successful pings by value, then untested (0), then failed (negative). */
    private fun pingRank(delayMillis: Long): Long = when {
        delayMillis > 0L -> delayMillis
        delayMillis == 0L -> Long.MAX_VALUE - 1
        else -> Long.MAX_VALUE
    }
}
