package com.v2ray.ang.ui.main

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.TrafficSpeed
import com.v2ray.ang.extension.toSpeedString
import kotlinx.coroutines.flow.StateFlow

/**
 * The Home page keeps its own dark, terminal-like look (near-black surfaces, mint accent, monospace
 * headings) whatever the app theme is, so it reads the same in light and dark mode.
 */
private object HomeColors {
    val Background = Color(0xFF080B0A)
    val Card = Color(0xFF0F1412)
    val CardBorder = Color(0xFF29302D)
    val Ring = Color(0xFF566159)
    val Accent = Color(0xFF7BE0A6)
    val AccentGlow = Color(0x337BE0A6)
    val Amber = Color(0xFFE6C27A)
    val Danger = Color(0xFFFF8A80)
    val TextPrimary = Color(0xFFE6ECE8)
    val TextMuted = Color(0xFF8A958F)
    val IconBubble = Color(0xFF1A211E)
}

private val HomeLabelStyle = androidx.compose.ui.text.TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Medium,
    fontSize = 12.sp,
    letterSpacing = 2.sp,
)

@Composable
private fun String.upper(): String = uppercase(LocalConfiguration.current.locales[0])

/**
 * Home tab: power button, connection status, Auto connection switch and the active configuration
 * with its ping and live downlink / uplink.
 */
@Composable
fun MainHomePage(
    state: MainUiState,
    statusText: String,
    speed: StateFlow<TrafficSpeed>,
    contentPadding: PaddingValues,
    onAction: (MainAction) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HomeColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(contentPadding)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(20.dp))
        PowerButton(isRunning = state.isRunning, onClick = { onAction(MainAction.ToggleService) })
        Spacer(Modifier.height(24.dp))
        StatusCard(isRunning = state.isRunning, statusText = statusText)
        Spacer(Modifier.height(14.dp))
        AutoConnectionRow(
            enabled = state.autoConnection,
            onChange = { onAction(MainAction.SetAutoConnection(it)) },
        )
        Spacer(Modifier.height(14.dp))
        ActiveConfigCard(
            state = state,
            speed = speed,
            onLocate = { onAction(MainAction.LocateSelectedServer) },
            onTestPing = { onAction(MainAction.TestCurrentServer) },
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PowerButton(isRunning: Boolean, onClick: () -> Unit) {
    val tint = if (isRunning) HomeColors.Accent else HomeColors.Ring
    val label = stringResource(if (isRunning) R.string.home_power_disconnect else R.string.home_power_connect)
    Box(
        modifier = Modifier
            .size(216.dp)
            .then(
                if (isRunning) {
                    Modifier.drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(HomeColors.AccentGlow, Color.Transparent),
                                radius = size.minDimension * 0.62f,
                            )
                        )
                    }
                } else Modifier
            )
            .padding(8.dp)
            .clip(CircleShape)
            .background(HomeColors.Card)
            .border(BorderStroke(2.dp, tint), CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(64.dp)) {
            val strokeWidth = 6.dp.toPx()
            val inset = strokeWidth / 2
            // Open ring with the gap at the top, plus the short bar that makes it a power symbol.
            drawArc(
                color = tint,
                startAngle = -55f,
                sweepAngle = 290f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - strokeWidth, size.height - strokeWidth),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
            drawLine(
                color = tint,
                start = Offset(size.width / 2, 0f),
                end = Offset(size.width / 2, size.height * 0.46f),
                strokeWidth = strokeWidth,
                cap = StrokeCap.Round,
            )
        }
    }
}

@Composable
private fun HomeCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(HomeColors.Card)
            .border(BorderStroke(1.dp, HomeColors.CardBorder), RoundedCornerShape(16.dp)),
    ) { content() }
}

@Composable
private fun StatusCard(isRunning: Boolean, statusText: String) {
    val title = stringResource(if (isRunning) R.string.home_status_connected else R.string.home_status_not_connected)
    val body = if (isRunning) statusText else stringResource(R.string.home_status_hint)
    HomeCard(
        // One node: title and detail are read together.
        modifier = Modifier.semantics(mergeDescendants = true) {},
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(CircleShape).background(HomeColors.IconBubble),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(if (isRunning) HomeColors.Accent else HomeColors.Ring)
                )
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    text = title.upper(),
                    style = HomeLabelStyle.copy(fontSize = 18.sp),
                    color = if (isRunning) HomeColors.Accent else HomeColors.TextMuted,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = HomeColors.TextPrimary,
                )
            }
        }
    }
}

@Composable
private fun AutoConnectionRow(enabled: Boolean, onChange: (Boolean) -> Unit) {
    HomeCard(
        // The whole row is the switch: one focus target with one name and one on/off state.
        modifier = Modifier.toggleable(value = enabled, role = Role.Switch, onValueChange = onChange),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.home_auto_connection),
                    style = MaterialTheme.typography.titleMedium,
                    color = HomeColors.TextPrimary,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = stringResource(R.string.home_auto_connection_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = HomeColors.TextMuted,
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = enabled,
                onCheckedChange = null,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = HomeColors.Background,
                    checkedTrackColor = HomeColors.Accent,
                    uncheckedThumbColor = HomeColors.TextMuted,
                    uncheckedTrackColor = HomeColors.IconBubble,
                    uncheckedBorderColor = HomeColors.Ring,
                ),
            )
        }
    }
}

@Composable
private fun ActiveConfigCard(
    state: MainUiState,
    speed: StateFlow<TrafficSpeed>,
    onLocate: () -> Unit,
    onTestPing: () -> Unit,
) {
    val active = state.activeConfig
    HomeCard {
        Column(Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(role = Role.Button, enabled = active != null, onClick = onLocate),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.home_active_config).upper(),
                        style = HomeLabelStyle,
                        color = HomeColors.TextMuted,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = active?.name?.ifBlank { null } ?: stringResource(R.string.home_not_set),
                        style = MaterialTheme.typography.titleLarge,
                        color = HomeColors.TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text("›", style = MaterialTheme.typography.headlineMedium, color = HomeColors.Accent)
            }

            Spacer(Modifier.height(14.dp))
            PingLine(delayMillis = active?.delayMillis, canTest = state.isRunning, onTestPing = onTestPing)

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = HomeColors.CardBorder)
            Spacer(Modifier.height(16.dp))
            SpeedRow(speed = speed, isRunning = state.isRunning)
        }
    }
}

@Composable
private fun PingLine(delayMillis: Long?, canTest: Boolean, onTestPing: () -> Unit) {
    val value: String
    val detail: String
    val color: Color
    when {
        delayMillis == null || delayMillis == 0L -> {
            value = "–"; detail = stringResource(R.string.home_ping_never); color = HomeColors.Amber
        }

        delayMillis < 0L -> {
            value = "–"; detail = stringResource(R.string.home_ping_failed); color = HomeColors.Danger
        }

        else -> {
            value = stringResource(R.string.server_test_delay_value, delayMillis)
            detail = ""; color = HomeColors.Amber
        }
    }
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(role = Role.Button, enabled = canTest, onClick = onTestPing)
            .semantics(mergeDescendants = true) {},
    ) {
        Text(
            text = stringResource(R.string.home_ping) + " " + value,
            style = MaterialTheme.typography.titleMedium,
            color = color,
        )
        if (detail.isNotEmpty()) {
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = HomeColors.TextMuted)
        }
    }
}

/** Collects the per-second speed itself, so only this row recomposes while data flows. */
@Composable
private fun SpeedRow(speed: StateFlow<TrafficSpeed>, isRunning: Boolean) {
    val current by speed.collectAsStateWithLifecycle()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        SpeedColumn(
            label = stringResource(R.string.home_downlink),
            arrow = "↓",
            value = if (isRunning) current.downlinkBytesPerSec.toSpeedString() else "—",
        )
        SpeedColumn(
            label = stringResource(R.string.home_uplink),
            arrow = "↑",
            value = if (isRunning) current.uplinkBytesPerSec.toSpeedString() else "—",
        )
    }
}

@Composable
private fun SpeedColumn(label: String, arrow: String, value: String) {
    Column(
        // Read as "Downlink, 1.2 MB/s"; the arrow glyph is decoration.
        modifier = Modifier.semantics(mergeDescendants = true) {},
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(text = label.upper(), style = HomeLabelStyle, color = HomeColors.TextMuted)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = arrow,
                modifier = Modifier.clearAndSetSemantics {},
                style = MaterialTheme.typography.titleMedium,
                color = HomeColors.Accent,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                color = HomeColors.TextPrimary,
            )
        }
    }
}
