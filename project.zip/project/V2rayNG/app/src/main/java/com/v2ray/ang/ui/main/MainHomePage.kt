package com.v2ray.ang.ui.main

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.TrafficSpeed
import com.v2ray.ang.extension.toSpeedString
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Home palette, derived from the app theme. */
private class HomeColors(
    val background: Color,
    val card: Color,
    val cardBorder: Color,
    val ring: Color,
    val accent: Color,
    val accentSoft: Color,
    val amber: Color,
    val danger: Color,
    val textPrimary: Color,
    val textMuted: Color,
    val bubble: Color,
    val onAccent: Color,
)

/** Builds the home palette from the app's Material theme so Home matches every other screen (light, dark and dynamic color). */
@Composable
private fun rememberHomeColors(): HomeColors {
    val scheme = MaterialTheme.colorScheme
    return remember(scheme) {
        HomeColors(
            background = scheme.surface,
            card = scheme.surfaceContainerLow,
            cardBorder = scheme.outlineVariant,
            ring = scheme.outline,
            accent = scheme.tertiary,
            accentSoft = scheme.tertiary.copy(alpha = 0.14f),
            amber = scheme.secondary,
            danger = scheme.error,
            textPrimary = scheme.onSurface,
            textMuted = scheme.onSurfaceVariant,
            bubble = scheme.surfaceContainerHighest,
            onAccent = scheme.onTertiary,
        )
    }
}

private val HomeLabelStyle = androidx.compose.ui.text.TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Medium,
    fontSize = 12.sp,
    letterSpacing = 2.sp,
)

@Composable
private fun String.upper(): String = uppercase(LocalConfiguration.current.locales[0])

/**
 * Home tab (the first and start tab): power button, connection status, the active configuration
 * with its ping, live downlink / uplink and the Auto connection switch. Follows the light / dark theme.
 */
@Composable
fun MainHomePage(
    state: MainUiState,
    statusText: String,
    speed: StateFlow<TrafficSpeed>,
    contentPadding: PaddingValues,
    onAction: (MainAction) -> Unit,
) {
    val c = rememberHomeColors()
    val pageBackground by animateColorAsState(c.background, tween(300), label = "homeBg")
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBackground)
            .verticalScroll(rememberScrollState())
            .padding(contentPadding)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(16.dp))
        TunnelHeader(c = c, isRunning = state.isRunning)
        Spacer(Modifier.height(14.dp))
        PowerButton(c = c, isRunning = state.isRunning, onClick = { onAction(MainAction.ToggleService) })
        Spacer(Modifier.height(16.dp))
        StatusText(c = c, isRunning = state.isRunning, statusText = statusText)
        Spacer(Modifier.height(16.dp))
        ActiveConfigCard(
            c = c,
            state = state,
            onLocate = { onAction(MainAction.LocateSelectedServer) },
            onTestPing = { onAction(MainAction.TestCurrentServer) },
        )
        Spacer(Modifier.height(12.dp))
        SpeedTiles(c = c, speed = speed, isRunning = state.isRunning)
        Spacer(Modifier.height(12.dp))
        AutoConnectionRow(
            c = c,
            enabled = state.autoConnection,
            onChange = { onAction(MainAction.SetAutoConnection(it)) },
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun TunnelHeader(c: HomeColors, isRunning: Boolean) {
    val pillBg by animateColorAsState(if (isRunning) c.accentSoft else c.bubble, tween(350), label = "pillBg")
    val pillFg by animateColorAsState(if (isRunning) c.accent else c.textMuted, tween(350), label = "pillFg")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = stringResource(R.string.home_tab_title).upper(),
            modifier = Modifier.weight(1f),
            style = HomeLabelStyle,
            color = c.textMuted,
        )
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(pillBg)
                .padding(horizontal = 10.dp, vertical = 3.dp),
        ) {
            AnimatedContent(
                targetState = isRunning,
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                label = "pillText",
            ) { running ->
                Text(
                    text = stringResource(
                        if (running) R.string.home_status_connected else R.string.home_status_not_connected
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Medium,
                    color = pillFg,
                )
            }
        }
    }
}

/**
 * Power button. On connect / disconnect: the core pops with a spring, the power symbol turns in,
 * two rings spread outwards and the border colour glides between grey and green.
 */
@Composable
private fun PowerButton(c: HomeColors, isRunning: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(if (isRunning) c.accent else c.ring, tween(400), label = "powerTint")
    val halo by animateColorAsState(if (isRunning) c.accentSoft else Color.Transparent, tween(400), label = "powerHalo")
    val label = stringResource(if (isRunning) R.string.home_power_disconnect else R.string.home_power_connect)

    // Rings start "finished" (1f = fully faded) so nothing plays when the page first appears.
    val pop = remember { Animatable(1f) }
    val spin = remember { Animatable(1f) }
    val ringA = remember { Animatable(1f) }
    val ringB = remember { Animatable(1f) }
    var firstRun by remember { mutableStateOf(true) }
    LaunchedEffect(isRunning) {
        if (firstRun) {
            firstRun = false
            return@LaunchedEffect
        }
        launch {
            pop.snapTo(1f)
            pop.animateTo(0.88f, tween(120))
            pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
        }
        launch {
            spin.snapTo(0f)
            spin.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
        }
        launch {
            ringA.snapTo(0f)
            ringA.animateTo(1f, tween(1000, easing = LinearOutSlowInEasing))
        }
        launch {
            delay(180)
            ringB.snapTo(0f)
            ringB.animateTo(1f, tween(1000, easing = LinearOutSlowInEasing))
        }
    }

    Box(
        modifier = Modifier
            .size(216.dp)
            .drawBehind {
                val base = (size.minDimension - 16.dp.toPx()) / 2f
                listOf(ringA.value, ringB.value).forEach { p ->
                    if (p < 1f) {
                        drawCircle(
                            color = c.accent.copy(alpha = (1f - p) * 0.7f),
                            radius = base * (0.8f + 0.45f * p),
                            style = Stroke(width = 2.dp.toPx()),
                        )
                    }
                }
            }
            .padding(8.dp)
            .clip(CircleShape)
            .background(halo)
            .border(BorderStroke(1.5.dp, tint), CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(150.dp)
                .graphicsLayer {
                    scaleX = pop.value
                    scaleY = pop.value
                }
                .clip(CircleShape)
                .background(c.card)
                .border(BorderStroke(2.dp, tint), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(
                Modifier
                    .size(60.dp)
                    .graphicsLayer {
                        rotationZ = -90f * (1f - spin.value)
                        val s = 0.7f + 0.3f * spin.value
                        scaleX = s
                        scaleY = s
                    }
            ) {
                val strokeWidth = 6.dp.toPx()
                val inset = strokeWidth / 2
                // Open ring with the gap at the top, plus the short bar that makes it a power symbol.
                drawArc(
                    color = tint,
                    startAngle = -55f,
                    sweepAngle = 290f,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = Size(size.width - strokeWidth, size.height - strokeWidth),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                )
                drawLine(
                    color = tint,
                    start = Offset(size.width / 2, 0f),
                    end = Offset(size.width / 2, size.height * 0.46f),
                    strokeWidth = strokeWidth,
                    cap = StrokeCap.Round,
                )
            }
        }
    }
}

@Composable
private fun StatusText(c: HomeColors, isRunning: Boolean, statusText: String) {
    val titleColor by animateColorAsState(if (isRunning) c.accent else c.textMuted, tween(350), label = "statusTitle")
    Column(
        // One node: title and detail are read together.
        modifier = Modifier.semantics(mergeDescendants = true) {},
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AnimatedContent(
            targetState = isRunning,
            transitionSpec = { fadeIn(tween(250, delayMillis = 100)) togetherWith fadeOut(tween(150)) },
            label = "statusContent",
        ) { running ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = stringResource(
                        if (running) R.string.home_status_connected else R.string.home_status_not_connected
                    ).upper(),
                    style = HomeLabelStyle.copy(fontSize = 18.sp),
                    color = titleColor,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (running) statusText else stringResource(R.string.home_status_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.textMuted,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun HomeCard(c: HomeColors, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val cardColor by animateColorAsState(c.card, tween(300), label = "cardBg")
    val borderColor by animateColorAsState(c.cardBorder, tween(300), label = "cardBorder")
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cardColor)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(16.dp)),
    ) { content() }
}

@Composable
private fun ActiveConfigCard(
    c: HomeColors,
    state: MainUiState,
    onLocate: () -> Unit,
    onTestPing: () -> Unit,
) {
    val active = state.activeConfig
    HomeCard(c) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(role = Role.Button, enabled = active != null, onClick = onLocate),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.home_active_config).upper(),
                        style = HomeLabelStyle.copy(fontSize = 11.sp),
                        color = c.textMuted,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = active?.name?.ifBlank { null } ?: stringResource(R.string.home_not_set),
                        style = MaterialTheme.typography.titleMedium,
                        color = c.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text("›", style = MaterialTheme.typography.headlineMedium, color = c.accent)
            }
            Spacer(Modifier.height(12.dp))
            PingChip(c = c, delayMillis = active?.delayMillis, canTest = state.isRunning, onTestPing = onTestPing)
        }
    }
}

@Composable
private fun PingChip(c: HomeColors, delayMillis: Long?, canTest: Boolean, onTestPing: () -> Unit) {
    val value: String
    val detail: String
    val color: Color
    when {
        delayMillis == null || delayMillis == 0L -> {
            value = "–"; detail = stringResource(R.string.home_ping_never); color = c.amber
        }

        delayMillis < 0L -> {
            value = "–"; detail = stringResource(R.string.home_ping_failed); color = c.danger
        }

        else -> {
            value = stringResource(R.string.server_test_delay_value, delayMillis)
            detail = ""; color = c.amber
        }
    }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(role = Role.Button, enabled = canTest, onClick = onTestPing)
            .semantics(mergeDescendants = true) {},
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(c.bubble)
                .padding(horizontal = 10.dp, vertical = 4.dp),
        ) {
            Text(
                text = stringResource(R.string.home_ping) + " " + value,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Medium,
                color = color,
            )
        }
        if (detail.isNotEmpty()) {
            Spacer(Modifier.width(8.dp))
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = c.textMuted)
        }
    }
}

/** Collects the per-second speed itself, so only this card recomposes while data flows. */
@Composable
private fun SpeedTiles(c: HomeColors, speed: StateFlow<TrafficSpeed>, isRunning: Boolean) {
    val current by speed.collectAsStateWithLifecycle()
    HomeCard(c) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SpeedCell(
                c = c,
                modifier = Modifier.weight(1f),
                label = stringResource(R.string.home_downlink),
                arrow = "↓",
                value = if (isRunning) current.downlinkBytesPerSec.toSpeedString() else "—",
            )
            Box(
                Modifier
                    .padding(horizontal = 10.dp)
                    .width(1.dp)
                    .height(36.dp)
                    .background(c.cardBorder),
            )
            SpeedCell(
                c = c,
                modifier = Modifier.weight(1f),
                label = stringResource(R.string.home_uplink),
                arrow = "↑",
                value = if (isRunning) current.uplinkBytesPerSec.toSpeedString() else "—",
            )
        }
    }
}

@Composable
private fun SpeedCell(c: HomeColors, modifier: Modifier, label: String, arrow: String, value: String) {
    Column(
        // Read as "Downlink, 1.2 MB/s"; the arrow glyph is decoration.
        modifier = modifier.semantics(mergeDescendants = true) {},
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = arrow,
                modifier = Modifier.clearAndSetSemantics {},
                style = MaterialTheme.typography.titleSmall,
                color = c.accent,
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = label.upper(),
                style = HomeLabelStyle.copy(fontSize = 10.sp),
                color = c.textMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
            color = c.textPrimary,
            maxLines = 1,
        )
    }
}

@Composable
private fun AutoConnectionRow(c: HomeColors, enabled: Boolean, onChange: (Boolean) -> Unit) {
    HomeCard(
        c,
        // The whole row is the switch: one focus target with one name and one on/off state.
        modifier = Modifier.toggleable(value = enabled, role = Role.Switch, onValueChange = onChange),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.home_auto_connection),
                    style = MaterialTheme.typography.titleMedium,
                    color = c.textPrimary,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = stringResource(R.string.home_auto_connection_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = c.textMuted,
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = enabled,
                onCheckedChange = null,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = c.onAccent,
                    checkedTrackColor = c.accent,
                    uncheckedThumbColor = c.textMuted,
                    uncheckedTrackColor = c.bubble,
                    uncheckedBorderColor = c.ring,
                ),
            )
        }
    }
}
