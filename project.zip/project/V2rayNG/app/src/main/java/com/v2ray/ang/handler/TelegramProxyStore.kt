package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.handler.TelegramProxyManager.TelegramProxy
import com.v2ray.ang.util.LogUtil
import org.json.JSONArray

/**
 * Keeps the Telegram MTProto proxies the user added so they survive restarts and show up as a
 * "Telegram" tab on the main screen. Proxies are stored as their original links (the parser
 * rebuilds everything else), never as v2ray profiles.
 */
object TelegramProxyStore {
    /** Fixed ID of the pseudo-group that renders as the "Telegram" tab. */
    const val GROUP_ID = "telegram_proxy"

    private const val KEY_LINKS = "pref_telegram_proxy_links"
    private const val MAX_SAVED = 500

    private val lock = Any()

    /** Creates the group entry if missing; returns true when it was just created. */
    fun ensureGroup(remarks: String): Boolean {
        if (MmkvManager.decodeSubscription(GROUP_ID) != null) return false
        MmkvManager.encodeSubscription(
            GROUP_ID,
            SubscriptionItem(remarks = remarks, enabled = true, autoUpdate = false)
        )
        return true
    }

    /** All saved proxies in insertion order. */
    fun load(): List<TelegramProxy> = synchronized(lock) { readLinks().mapNotNull { TelegramProxyManager.parseLink(it) } }

    /** Adds [proxies] that are not saved yet; returns the ones that were really new. */
    fun add(proxies: List<TelegramProxy>): List<TelegramProxy> = synchronized(lock) {
        val current = readLinks().mapNotNull { TelegramProxyManager.parseLink(it) }
        val known = current.mapTo(HashSet()) { it.id }
        val added = proxies.filter { known.add(it.id) }
        if (added.isNotEmpty()) writeLinks((current + added).takeLast(MAX_SAVED).map { it.link })
        added
    }

    fun remove(id: String) = synchronized(lock) {
        writeLinks(readLinks().filter { TelegramProxyManager.parseLink(it)?.id != id })
    }

    fun clear() = synchronized(lock) { writeLinks(emptyList()) }

    private fun readLinks(): List<String> {
        val raw = MmkvManager.decodeSettingsString(KEY_LINKS) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { array.optString(it).takeIf { s -> s.isNotBlank() } }
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "Telegram proxy store is corrupt, ignoring it", e)
            emptyList()
        }
    }

    private fun writeLinks(links: List<String>) {
        MmkvManager.encodeSettings(KEY_LINKS, JSONArray(links).toString())
    }
}
