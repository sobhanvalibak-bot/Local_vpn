package com.v2ray.ang.ui.main

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.LiquidGlassState
import com.v2ray.ang.ui.compose.liquidGlass
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val connectedGreen = Color(0xFF22C55E)
private val slideTrackColor = Color(0xFFE5E5E2)
private const val SLIDE_TRIGGER_FRACTION = 0.8f

/**
 * Bottom controls: a "slide to connect" pill (a "tap to disconnect" pill while connected) and, below
 * it, a smaller box with the ping / status / error text. Tapping that box re-runs the ping test.
 */
@Composable
fun MainBottomBar(
    glass: LiquidGlassState,
    displayText: String,
    isRunning: Boolean,
    isDarkTheme: Boolean,
    onAction: (MainAction) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        ConnectSlider(
            glass = glass,
            isRunning = isRunning,
            onToggle = { onAction(MainAction.ToggleService) },
        )
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 40.dp)
                .liquidGlass(glass, RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClick = { onAction(MainAction.TestCurrentServer) })
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(if (isRunning) connectedGreen else MaterialTheme.colorScheme.outline)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = displayText,
                modifier = Modifier
                    .weight(1f)
                    .semantics { contentDescription = displayText },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.width(8.dp))
            Icon(
                painter = painterResource(R.drawable.ic_refresh_24dp),
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ConnectSlider(
    glass: LiquidGlassState,
    isRunning: Boolean,
    onToggle: () -> Unit,
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val thumbSize = 48.dp
    val padding = 4.dp
    val thumbOffset = remember { Animatable(0f) }
    var trackWidthPx by remember { mutableIntStateOf(0) }
    val maxOffsetPx = with(density) {
        (trackWidthPx - (thumbSize + padding * 2).toPx()).coerceAtLeast(0f)
    }

    LaunchedEffect(isRunning) { thumbOffset.snapTo(0f) }

    val label = stringResource(if (isRunning) R.string.tap_to_disconnect else R.string.slide_to_connect)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(thumbSize + padding * 2)
            .then(
                if (isRunning) {
                    // Connected: a green liquid-glass pill, so the list behind it stays visible.
                    Modifier.liquidGlass(glass, CircleShape, tint = connectedGreen.copy(alpha = 0.45f))
                } else {
                    Modifier.clip(CircleShape).background(slideTrackColor)
                }
            )
            .onSizeChanged { trackWidthPx = it.width }
            .then(
                if (isRunning) {
                    Modifier.clickable(role = Role.Button, onClick = onToggle)
                } else {
                    Modifier.pointerInput(maxOffsetPx) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                scope.launch {
                                    val reached = maxOffsetPx > 0f &&
                                        thumbOffset.value >= maxOffsetPx * SLIDE_TRIGGER_FRACTION
                                    if (reached) onToggle()
                                    thumbOffset.animateTo(0f)
                                }
                            },
                            onDragCancel = { scope.launch { thumbOffset.animateTo(0f) } },
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                scope.launch {
                                    thumbOffset.snapTo((thumbOffset.value + dragAmount).coerceIn(0f, maxOffsetPx))
                                }
                            },
                        )
                    }
                }
            )
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = if (isRunning) Color.White.copy(alpha = 0.95f) else Color(0xFF9A9A98),
            textAlign = TextAlign.Center,
        )
        if (!isRunning) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = padding)
                    .offset { IntOffset(thumbOffset.value.roundToInt(), 0) }
                    .size(thumbSize)
                    .clip(CircleShape)
                    .background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                Text("›", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
}
