package com.v2ray.ang.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R

/**
 * Controls shown at the top of the "Local test" tab: a card to start/stop sharing all of this device's
 * configs and a card to load configs from another device. Holds only the uncommitted address input; every
 * operation goes through [MainAction] to [MainViewModel].
 */
@Composable
fun LocalTestPanel(
    state: LocalTestUiState,
    onAction: (MainAction) -> Unit,
) {
    var address by rememberSaveable { mutableStateOf("") }
    // Pre-fill with the last server that worked, without overwriting something the user already typed.
    LaunchedEffect(state.savedAddress) {
        if (address.isBlank() && state.savedAddress.isNotBlank()) address = state.savedAddress
    }

    val selectedCount = state.selectedGuids.size + state.selectedProxyIds.size
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (selectedCount > 0) {
            // Long-press picked something: OK saves it into the collection.
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.local_test_selected_count, selectedCount),
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { onAction(MainAction.LocalTestClearSelection) }) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    Button(onClick = { onAction(MainAction.LocalTestSaveSelected) }) {
                        Text(stringResource(android.R.string.ok))
                    }
                }
            }
        }
        PanelCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(
                            color = if (state.serverRunning) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline,
                            shape = CircleShape
                        )
                )
                Text(
                    text = stringResource(R.string.local_test_share_title),
                    style = MaterialTheme.typography.titleSmall,
                )
            }
            if (state.serverRunning) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text(
                        text = stringResource(R.string.local_test_server_on, state.serverAddress),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                    )
                }
            }
            FilledTonalButton(
                onClick = { onAction(MainAction.LocalTestToggleServer) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    stringResource(
                        if (state.serverRunning) R.string.local_test_stop_server
                        else R.string.local_test_start_server
                    )
                )
            }
        }

        PanelCard {
            Text(
                text = stringResource(R.string.local_test_fetch_title),
                style = MaterialTheme.typography.titleSmall,
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
                label = { Text(stringResource(R.string.local_test_address_hint)) },
            )
            if (state.busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.local_test_save_all),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = state.saveAll,
                    onCheckedChange = { onAction(MainAction.LocalTestSetSaveAll(it)) },
                )
            }
            Button(
                onClick = { onAction(MainAction.LocalTestFetch(address)) },
                enabled = !state.busy && address.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(stringResource(R.string.local_test_fetch_and_test))
            }
        }

        if (state.pendingProxies.isNotEmpty()) {
            PanelCard {
                Text(
                    text = stringResource(R.string.local_test_pending_proxies, state.pendingProxies.size),
                    style = MaterialTheme.typography.titleSmall,
                )
                Column(
                    modifier = Modifier
                        .heightIn(max = 260.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    state.pendingProxies.forEach { row ->
                        val toggle = { onAction(MainAction.LocalTestToggleProxySelect(row.proxy.id)) }
                        TelegramProxyCard(
                            row = row,
                            checked = row.proxy.id in state.selectedProxyIds,
                            onOpen = toggle,
                            onShare = toggle,
                            onClick = toggle,
                            onLongClick = toggle,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PanelCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = { content() }
        )
    }
}
