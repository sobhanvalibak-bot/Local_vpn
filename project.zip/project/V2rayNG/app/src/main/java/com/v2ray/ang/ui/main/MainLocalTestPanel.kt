package com.v2ray.ang.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R

/**
 * Controls shown at the top of the "Local test" tab: connect to a server by IP (the port is automatic),
 * the connection status, the list of devices that can be chatted with, and the switch for this phone's own
 * server. Holds only the uncommitted address input; every operation goes through [MainAction] to [MainViewModel].
 */
@Composable
fun LocalTestPanel(
    state: LocalTestUiState,
    onAction: (MainAction) -> Unit,
) {
    var address by rememberSaveable { mutableStateOf("") }
    // Pre-fill with the last server that worked (its IP only), without overwriting something already typed.
    LaunchedEffect(state.savedAddress) {
        if (address.isBlank() && state.savedAddress.isNotBlank()) address = state.savedAddress.substringBefore(':')
    }

    val selectedCount = state.selectedGuids.size + state.selectedProxyIds.size
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 380.dp)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (selectedCount > 0) {
            // Long-press picked something: OK saves it into the collection.
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.local_test_selected_count, selectedCount),
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { onAction(MainAction.LocalTestClearSelection) }) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    Button(onClick = { onAction(MainAction.LocalTestSaveSelected) }) {
                        Text(stringResource(android.R.string.ok))
                    }
                }
            }
        }

        PanelCard {
            Text(
                text = stringResource(R.string.local_test_fetch_title),
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                text = stringResource(R.string.local_test_connect_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
                label = { Text(stringResource(R.string.local_test_ip_hint)) },
                trailingIcon = {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(end = 8.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.local_test_port_auto),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            maxLines = 1,
                        )
                    }
                },
            )
            if (state.busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.local_test_save_all),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = state.saveAll,
                    onCheckedChange = { onAction(MainAction.LocalTestSetSaveAll(it)) },
                )
            }
            Button(
                onClick = { onAction(MainAction.LocalTestFetch(address)) },
                enabled = !state.busy && address.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(stringResource(R.string.local_test_fetch_and_test))
            }
        }

        if (state.connectedServer.isNotEmpty()) {
            val serverIp = state.connectedServer.substringBefore(':')
            Surface(
                color = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                // Text on top and the buttons on their own row: in one row the buttons took all the width and
                // squeezed the text down to a single word per line.
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.18f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            StatusDot(online = true)
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = stringResource(R.string.local_test_connected_to, serverIp),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = stringResource(R.string.local_test_connected_hint),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.75f),
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilledTonalButton(
                            onClick = { onAction(MainAction.LocalTestOpenChat(serverIp)) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                text = stringResource(R.string.local_test_message_server),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        OutlinedButton(
                            onClick = { onAction(MainAction.LocalTestDisconnect) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                text = stringResource(R.string.local_test_disconnect),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }

        PanelCard {
            MyProfileCard(profile = state.myProfile, onAction = onAction)
        }

        PanelCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.local_test_devices_title),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f),
                )
                if (state.peers.isNotEmpty()) {
                    Text(
                        text = stringResource(R.string.local_test_devices_count, state.peers.size),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (state.peers.isEmpty()) {
                Text(
                    text = stringResource(R.string.local_test_devices_empty),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                state.peers.forEach { peer ->
                    PeerRow(
                        peer = peer,
                        onClick = { onAction(MainAction.LocalTestOpenChat(peer.ip)) },
                        onProfile = { onAction(MainAction.LocalTestOpenProfile(peer.ip)) },
                    )
                }
            }
        }

        PanelCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusDot(online = state.serverRunning)
                Text(
                    text = stringResource(
                        if (state.serverRunning) R.string.local_test_this_is_server else R.string.local_test_share_title
                    ),
                    style = MaterialTheme.typography.titleSmall,
                )
            }
            if (state.serverRunning) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Text(
                        text = stringResource(R.string.local_test_server_on, state.serverAddress),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                    )
                }
            }
            FilledTonalButton(
                onClick = { onAction(MainAction.LocalTestToggleServer) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    stringResource(
                        if (state.serverRunning) R.string.local_test_stop_server
                        else R.string.local_test_start_server
                    )
                )
            }
        }

        if (state.pendingProxies.isNotEmpty()) {
            PanelCard {
                Text(
                    text = stringResource(R.string.local_test_pending_proxies, state.pendingProxies.size),
                    style = MaterialTheme.typography.titleSmall,
                )
                Column(
                    modifier = Modifier
                        .heightIn(max = 260.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    state.pendingProxies.forEach { row ->
                        val toggle = { onAction(MainAction.LocalTestToggleProxySelect(row.proxy.id)) }
                        TelegramProxyCard(
                            row = row,
                            checked = row.proxy.id in state.selectedProxyIds,
                            onOpen = toggle,
                            onShare = toggle,
                            onClick = toggle,
                            onLongClick = toggle,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusDot(online: Boolean) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .background(
                color = if (online) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                shape = CircleShape
            )
    )
}

@Composable
private fun PeerRow(peer: ChatPeerUi, onClick: () -> Unit, onProfile: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // The picture opens the device's profile page; the rest of the row opens the chat.
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .clickable(onClickLabel = stringResource(R.string.local_profile_open), onClick = onProfile)
        ) {
            ProfileAvatar(peer.avatar, peer.name.ifBlank { peer.ip.substringAfterLast('.') }, 42.dp)
        }
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // The profile name replaces the IP once the device has sent one.
                Text(
                    text = peer.name.ifBlank { peer.ip },
                    style = if (peer.name.isBlank()) MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace)
                    else MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (peer.isServer) {
                    Text(
                        text = stringResource(R.string.local_test_server_label),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            Text(
                text = peer.lastText.ifEmpty {
                    stringResource(if (peer.online) R.string.local_test_online else R.string.local_test_offline)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (peer.unread > 0) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = peer.unread.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimary,
                )
            }
        } else {
            StatusDot(online = peer.online)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = { content() }
        )
    }
}
