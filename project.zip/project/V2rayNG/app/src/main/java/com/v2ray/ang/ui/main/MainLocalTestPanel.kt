package com.v2ray.ang.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.OwnerConfig

/**
 * Controls shown at the top of the "Local test" tab: a card to share this device's configs and a
 * card to load configs from another device. Holds only the uncommitted address input; every
 * operation goes through [MainAction] to [MainViewModel].
 */
@Composable
fun LocalTestPanel(
    state: LocalTestUiState,
    onAction: (MainAction) -> Unit,
) {
    var address by rememberSaveable { mutableStateOf("") }
    var showSendDialog by rememberSaveable { mutableStateOf(false) }
    var showShareDialog by rememberSaveable { mutableStateOf(false) }
    // Pre-fill with the last server that worked, without overwriting something the user already typed.
    LaunchedEffect(state.savedAddress) {
        if (address.isBlank() && state.savedAddress.isNotBlank()) address = state.savedAddress
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PanelCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(
                            color = if (state.serverRunning) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline,
                            shape = CircleShape
                        )
                )
                Text(
                    text = stringResource(R.string.local_test_share_title),
                    style = MaterialTheme.typography.titleSmall,
                )
            }
            if (state.serverRunning) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text(
                        text = stringResource(R.string.local_test_server_on, state.serverAddress),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                    )
                }
            }
            FilledTonalButton(
                onClick = { onAction(MainAction.LocalTestToggleServer) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    stringResource(
                        if (state.serverRunning) R.string.local_test_stop_server
                        else R.string.local_test_start_server
                    )
                )
            }
            Button(
                onClick = { showShareDialog = true },
                enabled = state.serverRunning,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(stringResource(R.string.local_test_share_config))
            }
        }

        PanelCard {
            Text(
                text = stringResource(R.string.local_test_fetch_title),
                style = MaterialTheme.typography.titleSmall,
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
                label = { Text(stringResource(R.string.local_test_address_hint)) },
            )
            if (state.busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onAction(MainAction.LocalTestFetch(address)) },
                    enabled = !state.busy && address.isNotBlank(),
                    modifier = Modifier.weight(1f),
                ) {
                    Text(stringResource(R.string.local_test_fetch_and_test))
                }
                FilledTonalButton(
                    onClick = { showSendDialog = true },
                    enabled = !state.busy,
                    modifier = Modifier.weight(1f),
                ) {
                    Text(stringResource(R.string.local_test_send_to))
                }
            }
        }
    }

    if (showSendDialog) {
        OptionsDialog(
            title = stringResource(R.string.local_test_send_to),
            options = listOf(
                stringResource(R.string.local_test_send_all) to { onAction(MainAction.LocalTestSendToMain(onlyGreen = false)) },
                stringResource(R.string.local_test_send_green) to { onAction(MainAction.LocalTestSendToMain(onlyGreen = true)) },
            ),
            onDismiss = { showSendDialog = false },
        )
    }
    if (showShareDialog) {
        OptionsDialog(
            title = stringResource(R.string.local_test_share_config),
            options = listOf(
                stringResource(R.string.local_test_share_all) to { onAction(MainAction.LocalTestShareAll) },
                stringResource(R.string.local_test_share_green) to { onAction(MainAction.LocalTestShareGreen) },
                stringResource(R.string.local_test_share_selection) to { onAction(MainAction.LocalTestOpenShareSelection) },
            ),
            onDismiss = { showShareDialog = false },
        )
    }
    state.shareCandidates?.let { candidates ->
        ShareSelectionDialog(
            candidates = candidates,
            onConfirm = { guids -> onAction(MainAction.LocalTestShareSelection(guids)) },
            onDismiss = { onAction(MainAction.LocalTestDismissShareSelection) },
        )
    }
}

/** Tap-an-option dialog; every option closes the dialog, and the last button is always Cancel. */
@Composable
private fun OptionsDialog(
    title: String,
    options: List<Pair<String, () -> Unit>>,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                options.forEach { (label, action) ->
                    TextButton(
                        onClick = {
                            onDismiss()
                            action()
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(label)
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        },
        confirmButton = {},
    )
}

/** Checklist of the owner's configs; the chosen GUIDs are the ones the server will hand out. */
@Composable
private fun ShareSelectionDialog(
    candidates: List<OwnerConfig>,
    onConfirm: (List<String>) -> Unit,
    onDismiss: () -> Unit,
) {
    var selected by rememberSaveable(
        stateSaver = listSaver<Set<String>, String>(save = { it.toList() }, restore = { it.toSet() })
    ) { mutableStateOf(emptySet<String>()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.local_test_share_selection)) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                items(candidates, key = { it.guid }) { config ->
                    val checked = config.guid in selected
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .toggleable(
                                value = checked,
                                role = Role.Checkbox,
                                onValueChange = { on ->
                                    selected = if (on) selected + config.guid else selected - config.guid
                                },
                            )
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Checkbox(checked = checked, onCheckedChange = null)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(config.remarks, style = MaterialTheme.typography.bodyLarge)
                            if (config.delayMillis > 0L) {
                                Text(
                                    stringResource(R.string.server_test_delay_value, config.delayMillis),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(candidates.map { it.guid }.filter { it in selected }) },
                enabled = selected.isNotEmpty(),
            ) {
                Text(stringResource(R.string.local_test_share_config))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

@Composable
private fun PanelCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = { content() }
        )
    }
}
