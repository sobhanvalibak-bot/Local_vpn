package com.v2ray.ang.handler

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.ui.main.MainActivity
import com.v2ray.ang.util.LogUtil

/** Heads-up notifications for the "Local test" feature (which device connected to which server). */
object LocalTestNotifier {
    private const val CHANNEL_ID = "local_test_channel"
    private const val BASE_ID = 4100

    /** Extra carrying the IP of the device whose chat should open when the notification is tapped. */
    const val EXTRA_CHAT_PEER = "local_test_chat_peer"

    /**
     * Posts a notification. [key] picks the notification slot: the same key replaces the earlier one,
     * different keys (e.g. different client IPs) stack.
     *
     * Tapping the notification opens the app; when [chatPeer] is set it goes straight to the chat with
     * that device.
     */
    fun notify(context: Context, key: String, title: String, text: String, chatPeer: String? = null) {
        // The user is looking at the app (it shows the same information itself): stay quiet.
        if (AppForegroundTracker.isInForeground) return
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return
            ensureChannel(context)
            val id = BASE_ID + (key.hashCode() and 0xFFFF)
            val open = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                if (chatPeer != null) putExtra(EXTRA_CHAT_PEER, chatPeer)
            }
            // The notification id doubles as request code so every chat gets its own PendingIntent extras.
            val contentIntent = PendingIntent.getActivity(
                context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_name)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(context).notify(id, notification)
        } catch (e: SecurityException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: notification not allowed", e)
        } catch (e: RuntimeException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: notification failed", e)
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.local_test_title),
                NotificationManager.IMPORTANCE_HIGH
            )
        )
    }
}
