package com.v2ray.ang.handler

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.util.LogUtil

/** Heads-up notifications for the "Local test" feature (which device connected to which server). */
object LocalTestNotifier {
    private const val CHANNEL_ID = "local_test_channel"
    private const val BASE_ID = 4100

    /**
     * Posts a notification. [key] picks the notification slot: the same key replaces the earlier one,
     * different keys (e.g. different client IPs) stack.
     */
    fun notify(context: Context, key: String, title: String, text: String) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return
            ensureChannel(context)
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_name)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(context).notify(BASE_ID + (key.hashCode() and 0xFFFF), notification)
        } catch (e: SecurityException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: notification not allowed", e)
        } catch (e: RuntimeException) {
            LogUtil.e(AppConfig.TAG, "LocalTest: notification failed", e)
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.local_test_title),
                NotificationManager.IMPORTANCE_HIGH
            )
        )
    }
}
