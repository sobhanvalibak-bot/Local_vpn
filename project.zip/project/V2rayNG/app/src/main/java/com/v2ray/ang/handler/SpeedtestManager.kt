package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.IPAPIInfo
import com.v2ray.ang.dto.UrlContentRequest
import com.v2ray.ang.util.HttpUtil
import com.v2ray.ang.util.JsonUtil
import com.v2ray.ang.util.LogUtil
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.UnknownHostException

object SpeedtestManager {

    data class RemoteEndpointInfo(
        val country: String?,
        val ipAddress: String?,
    )

    /**
     * Measures the time taken to establish a TCP connection to a given URL and port.
     *
     * @param url The URL to connect to.
     * @param port The port to connect to.
     * @return The connection time in milliseconds, or -1 if the connection failed.
     */
    fun socketConnectTime(url: String, port: Int, timeoutMs: Int = 1500): Long {
        var socket: Socket? = null
        val start = System.currentTimeMillis()

        try {
            socket = Socket()
            socket.connect(InetSocketAddress(url, port), timeoutMs)

            return System.currentTimeMillis() - start
        } catch (e: UnknownHostException) {
            LogUtil.e(AppConfig.TAG, "Unknown host: $url", e)
        } catch (e: IOException) {
            LogUtil.e(AppConfig.TAG, "socketConnectTime IOException: ${e.message}")
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "Failed to establish socket connection to $url:$port", e)
        } finally {
            socket?.let { s ->
                try {
                    if (!s.isClosed) {
                        s.close()
                    }
                } catch (closeEx: IOException) {
                }
            }
        }
        return -1
    }

    /** Bytes per second for [bytes] received in [elapsedMs]; 0 when nothing was received or no time passed. */
    internal fun bytesPerSecond(bytes: Long, elapsedMs: Long): Long =
        if (bytes <= 0L || elapsedMs <= 0L) 0L else bytes * 1000L / elapsedMs

    /**
     * Downloads [url] through the local SOCKS5 proxy on [socksPort] and returns the speed in bytes per second.
     * Stops after [maxMs] or [maxBytes]; the time to the first byte is not counted, so it measures
     * throughput and not latency. Blocking: call it off the main thread.
     *
     * @return The speed, or 0 when the download failed or received nothing.
     */
    fun measureDownloadSpeed(
        socksPort: Int,
        url: String,
        maxMs: Long = AppConfig.DOWNLOAD_TEST_MAX_MS,
        maxBytes: Long = AppConfig.DOWNLOAD_TEST_MAX_BYTES,
    ): Long {
        var connection: java.net.HttpURLConnection? = null
        try {
            val proxy = java.net.Proxy(java.net.Proxy.Type.SOCKS, InetSocketAddress(AppConfig.LOOPBACK, socksPort))
            connection = (java.net.URL(url).openConnection(proxy) as java.net.HttpURLConnection).apply {
                connectTimeout = 5_000
                readTimeout = 5_000
                useCaches = false
            }
            if (connection.responseCode !in 200..299) return 0L
            val buffer = ByteArray(16 * 1024)
            var total = 0L
            var start = 0L
            connection.inputStream.use { input ->
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    val now = System.currentTimeMillis()
                    if (start == 0L) {
                        // The clock starts with the first chunk, so connection setup is not counted.
                        start = now
                    } else {
                        total += read
                    }
                    if (now - start >= maxMs || total >= maxBytes) break
                }
            }
            return if (start == 0L) 0L else bytesPerSecond(total, System.currentTimeMillis() - start)
        } catch (e: Exception) {
            LogUtil.w(AppConfig.TAG, "Download speed test failed: ${e.message}")
            return 0L
        } finally {
            connection?.disconnect()
        }
    }

    fun getRemoteIPInfo(): RemoteEndpointInfo? {
        val url = MmkvManager.decodeSettingsString(AppConfig.PREF_IP_API_URL)
            .takeIf { !it.isNullOrBlank() } ?: AppConfig.IP_API_URL

        val proxyUsername = SettingsManager.getSocksUsername()
        val proxyPassword = SettingsManager.getSocksPassword()
        val httpPort = SettingsManager.getHttpPort()
        if (httpPort == 0) return null
        val content = HttpUtil.getUrlContent(
            UrlContentRequest(
                url = url,
                timeout = 5000,
                httpPort = httpPort,
                proxyUsername = proxyUsername,
                proxyPassword = proxyPassword
            )
        ) ?: return null
        val ipInfo = JsonUtil.fromJsonSafe(content, IPAPIInfo::class.java) ?: return null

        val ip = listOf(
            ipInfo.ip,
            ipInfo.clientIp,
            ipInfo.ip_addr,
            ipInfo.query
        ).firstOrNull { !it.isNullOrBlank() }

        val country = listOf(
            ipInfo.country_code,
            ipInfo.country,
            ipInfo.countryCode,
            ipInfo.location?.country_code
        ).firstOrNull { !it.isNullOrBlank() }

        return RemoteEndpointInfo(
            country = country,
            ipAddress = ip,
        )
    }
}
