package com.v2ray.ang.ui.main

import com.v2ray.ang.dto.ConnectionTestResult
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.dto.LocateTarget

/** Locale-neutral state formatted only when it reaches the main UI. */
sealed interface MainStatus {
    data object Disconnected : MainStatus
    data object Connected : MainStatus
    data object Testing : MainStatus
    data class TestProgress(val progress: String) : MainStatus
    data class ConnectionTest(val result: ConnectionTestResult) : MainStatus
}

/**
 * Main UI state
 */
data class MainUiState(
    val groups: List<GroupMapItem> = emptyList(),
    val selectedGroupId: String = "",
    val selectedGuid: String? = null,
    val isRunning: Boolean = false,
    val isTesting: Boolean = false,
    val status: MainStatus = MainStatus.Disconnected,
    val locateTarget: LocateTarget? = null,
    /** Configs that just arrived from a server; their cards glow for a few seconds. */
    val highlightGuids: Set<String> = emptySet(),
    /** When true the pager glides slowly to the selected page instead of jumping. */
    val slowSlide: Boolean = false,
    /** A config to select (as the active server) once the screen has handled it. */
    val autoSelectGuid: String? = null,
    val confirmRemove: Boolean = false,
    val doubleColumnDisplay: Boolean = false,
    val shareQRCodeBitmap: android.graphics.Bitmap? = null,
    val localTest: LocalTestUiState = LocalTestUiState(),
    val telegram: TelegramTabUiState = TelegramTabUiState(),
)

/** Ping state of one Telegram proxy row. */
sealed interface TelegramPing {
    data object Testing : TelegramPing
    data class Done(val millis: Long) : TelegramPing
    data object Failed : TelegramPing
}

data class TelegramRow(
    val proxy: com.v2ray.ang.handler.TelegramProxyManager.TelegramProxy,
    val ping: TelegramPing = TelegramPing.Testing,
    /** ISO country code ("DE") once the server's IP has been located. */
    val countryCode: String? = null,
)

/** State of the "Telegram" tab on the main screen. */
data class TelegramTabUiState(
    val rows: List<TelegramRow> = emptyList(),
    val isTesting: Boolean = false,
)

/** State of the "Local test" tab panel. */
data class LocalTestUiState(
    val serverRunning: Boolean = false,
    /** Address others should type, e.g. 192.168.1.5:8765; empty when the server is off. */
    val serverAddress: String = "",
    val busy: Boolean = false,
    /** Address of the last server that delivered configs; pre-fills the fetch field. */
    val savedAddress: String = "",
    /** "Save all to my collection": received items go straight to the main/proxy tabs. */
    val saveAll: Boolean = true,
    /** Proxies received while [saveAll] is off; they wait here until the user selects and saves them. */
    val pendingProxies: List<TelegramRow> = emptyList(),
    /** Configs of the Local test tab picked by long-press, waiting for OK. */
    val selectedGuids: Set<String> = emptySet(),
    val selectedProxyIds: Set<String> = emptySet(),
)

/**
 * All possible user interaction intents
 */
sealed interface MainAction {
    data object Initialize : MainAction
    data object SlowSlideHandled : MainAction
    data object AutoSelectHandled : MainAction
    data class LocalTestSetSaveAll(val enabled: Boolean) : MainAction
    data class LocalTestToggleSelect(val guid: String) : MainAction
    data class LocalTestToggleProxySelect(val id: String) : MainAction
    data object LocalTestClearSelection : MainAction
    data object LocalTestSaveSelected : MainAction
    data object RefreshGroups : MainAction
    data object ToggleService : MainAction
    data object TestCurrentServer : MainAction
    data object TestAllServers : MainAction
    data object TestRealAllServers : MainAction
    data object CancelTesting : MainAction
    data object RemoveAllServers : MainAction
    data object RemoveDuplicateServers : MainAction
    data object RemoveInvalidServers : MainAction
    data object SortByTestResults : MainAction
    data object UpdateSubscriptions : MainAction
    data class UpdateGroupSubscription(val groupId: String) : MainAction
    data object ExportAll : MainAction

    data object ImportQRcode : MainAction
    data object ImportClipboard : MainAction
    data object ImportConfigLocal : MainAction
    data class ImportManually(val type: Int) : MainAction
    data object RestartService : MainAction
    data object LocateSelectedServer : MainAction

    data class SelectGroup(val groupId: String) : MainAction
    data class SelectServer(val guid: String) : MainAction
    data class RemoveServer(val guid: String) : MainAction
    data class EditServer(val guid: String, val profile: com.v2ray.ang.dto.entities.ProfileItem) : MainAction
    data class Search(val query: String) : MainAction
    data class ShareQRCode(val guid: String) : MainAction
    data class ShareClipboard(val guid: String) : MainAction
    data class ShareAsLocal(val guid: String) : MainAction
    data class TelegramShareAsLocal(val id: String) : MainAction
    data class TelegramShowQRCode(val link: String) : MainAction
    data class ShareFullContent(val guid: String) : MainAction
    data object DismissQRCodeDialog : MainAction
    data class OpenSubscriptionLink(val url: String) : MainAction

    data class ImportBatchConfig(val configText: String) : MainAction

    data object LocateHandled : MainAction

    data object LocalTestToggleServer : MainAction
    data class LocalTestFetch(val address: String) : MainAction
    data object LocalTestMoveGreenToMain : MainAction

    /** Telegram tab: save proxies found in [text], then ping them and look up their country. */
    data class TelegramAdd(val text: String) : MainAction
    data object TelegramTestAll : MainAction
    data class TelegramRemove(val id: String) : MainAction
    data object TelegramRemoveAll : MainAction
}
