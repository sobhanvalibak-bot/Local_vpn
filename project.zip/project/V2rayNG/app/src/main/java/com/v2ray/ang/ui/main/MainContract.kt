package com.v2ray.ang.ui.main

import com.v2ray.ang.dto.ConnectionTestResult
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.dto.LocateTarget

/** Id of the "Home" page, a virtual first tab that owns no servers and is never stored as a subscription. */
const val HOME_GROUP_ID = "__home__"

/** The profile the Home page shows as "Active configuration". [delayMillis]: 0 never tested, negative failed. */
data class ActiveConfigUi(
    val guid: String,
    val name: String,
    val delayMillis: Long = 0L,
)

/** Locale-neutral state formatted only when it reaches the main UI. */
sealed interface MainStatus {
    data object Disconnected : MainStatus
    data object Connected : MainStatus
    data object Testing : MainStatus
    data class TestProgress(val progress: String) : MainStatus
    data class ConnectionTest(val result: ConnectionTestResult) : MainStatus
}

/**
 * Main UI state
 */
data class MainUiState(
    val groups: List<GroupMapItem> = emptyList(),
    val selectedGroupId: String = "",
    val selectedGuid: String? = null,
    val isRunning: Boolean = false,
    val isTesting: Boolean = false,
    val status: MainStatus = MainStatus.Disconnected,
    val locateTarget: LocateTarget? = null,
    /** Configs that just arrived from a server; their cards glow for a few seconds. */
    val highlightGuids: Set<String> = emptySet(),
    /** When true the pager glides slowly to the selected page instead of jumping. */
    val slowSlide: Boolean = false,
    /** A config to select (as the active server) once the screen has handled it. */
    val autoSelectGuid: String? = null,
    val confirmRemove: Boolean = false,
    val doubleColumnDisplay: Boolean = false,
    val shareQRCodeBitmap: android.graphics.Bitmap? = null,
    val localTest: LocalTestUiState = LocalTestUiState(),
    val telegram: TelegramTabUiState = TelegramTabUiState(),
    /** Auto connection: when the active config stops working, switch to the best working one. */
    val autoConnection: Boolean = false,
    val activeConfig: ActiveConfigUi? = null,
    /** Order of the Default tab: by download speed, by ping, or by the time configs were added. */
    /** Auto change is fetching, testing or connecting. */
    val autoChanging: Boolean = false,
    /** Set when Auto change picked a config: the screen restarts (or starts) the service once and clears it. */
    val connectAfterAutoChange: Boolean = false,
    val defaultTabSort: com.v2ray.ang.enums.DefaultTabSort = com.v2ray.ang.enums.DefaultTabSort.TIME,
)

/** Ping state of one Telegram proxy row. */
sealed interface TelegramPing {
    data object Testing : TelegramPing
    data class Done(val millis: Long) : TelegramPing
    data object Failed : TelegramPing
}

data class TelegramRow(
    val proxy: com.v2ray.ang.handler.TelegramProxyManager.TelegramProxy,
    val ping: TelegramPing = TelegramPing.Testing,
    /** ISO country code ("DE") once the server's IP has been located. */
    val countryCode: String? = null,
)

/** State of the "Telegram" tab on the main screen. */
data class TelegramTabUiState(
    val rows: List<TelegramRow> = emptyList(),
    val isTesting: Boolean = false,
)

/** One chat message as the UI shows it. [kind]: "text", "image" (base64 JPEG in [image]) or "config" (links in [text]). */
data class ChatMessageUi(
    val id: Long,
    val mine: Boolean,
    val kind: String,
    val text: String,
    val image: String? = null,
    val time: Long = 0L,
)

/** A device in the Local test device list: the server this phone is connected to, or a client of its own server. */
data class ChatPeerUi(
    val ip: String,
    val isServer: Boolean,
    val online: Boolean,
    val lastText: String,
    val unread: Int,
    /** Display name from the device's profile; empty until the device has sent one (the list then shows the IP). */
    val name: String = "",
    val avatar: android.graphics.Bitmap? = null,
)

/** Profile another device sent: name, avatar and a banner (image or MP4) stored as a file in the cache. */
data class PeerProfileUi(
    val name: String = "",
    val avatar: android.graphics.Bitmap? = null,
    val bannerMime: String? = null,
    val bannerPath: String? = null,
    /** Changes whenever a new banner arrives, so the view reloads a file that kept its name. */
    val bannerVersion: Long = 0L,
)

/** This device's own profile, as other devices see it. */
data class MyProfileUi(
    val name: String = "",
    val avatar: android.graphics.Bitmap? = null,
    val bannerMime: String? = null,
    val bannerPath: String? = null,
    val bannerVersion: Long = 0L,
)

enum class FileStatus { IDLE, DOWNLOADING, READY, FAILED }

/** Progress of one received file, keyed by its id in [LocalTestUiState.fileTransfers]. */
data class FileTransferUi(val status: FileStatus = FileStatus.IDLE, val progress: Float = 0f, val path: String? = null)

/** A config a device shared: the link to add and a readable name. */
data class ProfileConfigUi(val link: String, val name: String, val protocol: String = "")

/** State of the "Local test" tab panel. */
data class LocalTestUiState(
    val serverRunning: Boolean = false,
    /** Address others should type, e.g. 192.168.1.5:8765; empty when the server is off. */
    val serverAddress: String = "",
    val busy: Boolean = false,
    /** Address of the last server that delivered configs; pre-fills the fetch field. */
    val savedAddress: String = "",
    /** "Save all to my collection": received items go straight to the main/proxy tabs. */
    val saveAll: Boolean = true,
    /** Proxies received while [saveAll] is off; they wait here until the user selects and saves them. */
    val pendingProxies: List<TelegramRow> = emptyList(),
    /** Configs of the Local test tab picked by long-press, waiting for OK. */
    val selectedGuids: Set<String> = emptySet(),
    val selectedProxyIds: Set<String> = emptySet(),
    /** "Update config" found no server on the network; the screen asks for its IP. */
    val askServerAddress: Boolean = false,
    /** "ip:port" of the server this phone is connected to; empty when not connected. */
    val connectedServer: String = "",
    val peers: List<ChatPeerUi> = emptyList(),
    /** IP of the device whose chat is open, or null. */
    val chatPeer: String? = null,
    val chatMessages: List<ChatMessageUi> = emptyList(),
    /** Non-null while the "send a config" picker is open. */
    val configPicker: List<com.v2ray.ang.handler.OwnerConfig>? = null,
    val myProfile: MyProfileUi = MyProfileUi(),
    val peerProfiles: Map<String, PeerProfileUi> = emptyMap(),
    /** IP of the device whose profile page is open, or null. */
    val profilePeer: String? = null,
    /** Configs the device of [profilePeer] shared with this phone. */
    val profileConfigs: List<ProfileConfigUi> = emptyList(),
    val fileTransfers: Map<String, FileTransferUi> = emptyMap(),
    /** A file is being copied and uploaded for the open chat. */
    val fileSending: Boolean = false,
)

/**
 * All possible user interaction intents
 */
sealed interface MainAction {
    data object Initialize : MainAction
    data object SlowSlideHandled : MainAction
    data object AutoSelectHandled : MainAction
    data class LocalTestSetSaveAll(val enabled: Boolean) : MainAction
    data class LocalTestToggleSelect(val guid: String) : MainAction
    data class LocalTestToggleProxySelect(val id: String) : MainAction
    data object LocalTestClearSelection : MainAction
    data object LocalTestSaveSelected : MainAction
    data object RefreshGroups : MainAction
    data object ToggleService : MainAction
    data object TestCurrentServer : MainAction
    data object TestAllServers : MainAction
    data object TestRealAllServers : MainAction
    data object CancelTesting : MainAction
    data class SetAutoConnection(val enabled: Boolean) : MainAction
    /** Default tab "Auto change": fetch, test ping + download, rank, connect to the best download. Pressed again it cancels. */
    data object AutoChange : MainAction
    data object AutoChangeConnectHandled : MainAction
    data class SetDefaultTabSort(val mode: com.v2ray.ang.enums.DefaultTabSort) : MainAction

    /** The Home page is on screen (true) or not (false); the daemon only sends live speed while it is. */
    data class SpeedUpdatesWanted(val wanted: Boolean) : MainAction
    data object RemoveAllServers : MainAction
    data object RemoveDuplicateServers : MainAction
    data object RemoveInvalidServers : MainAction
    data object SortByTestResults : MainAction
    data object UpdateSubscriptions : MainAction
    data class UpdateGroupSubscription(val groupId: String) : MainAction
    data object ExportAll : MainAction

    data object ImportQRcode : MainAction
    data object ImportClipboard : MainAction
    data object ImportConfigLocal : MainAction
    data object ImportNpvFile : MainAction
    data class ImportManually(val type: Int) : MainAction
    data object RestartService : MainAction
    data object LocateSelectedServer : MainAction

    data class SelectGroup(val groupId: String) : MainAction
    data class SelectServer(val guid: String) : MainAction
    data class RemoveServer(val guid: String) : MainAction
    data class EditServer(val guid: String, val profile: com.v2ray.ang.dto.entities.ProfileItem) : MainAction
    data class Search(val query: String) : MainAction
    data class ShareQRCode(val guid: String) : MainAction
    data class ShareClipboard(val guid: String) : MainAction
    data class ShareAsLocal(val guid: String) : MainAction
    data class TelegramShareAsLocal(val id: String) : MainAction
    data class TelegramShowQRCode(val link: String) : MainAction
    data class ShareFullContent(val guid: String) : MainAction
    data object DismissQRCodeDialog : MainAction
    data class OpenSubscriptionLink(val url: String) : MainAction

    data class ImportBatchConfig(val configText: String) : MainAction

    data object LocateHandled : MainAction

    data object LocalTestToggleServer : MainAction
    data class LocalTestFetch(val address: String) : MainAction
    data object LocalTestMoveGreenToMain : MainAction

    data class LocalTestOpenChat(val ip: String) : MainAction
    data object LocalTestCloseChat : MainAction
    data class LocalTestSendText(val text: String) : MainAction
    data class LocalTestSendImage(val base64: String) : MainAction
    data object LocalTestPickConfig : MainAction
    data object LocalTestPickConfigDismiss : MainAction
    data class LocalTestSendConfig(val guid: String) : MainAction
    data class LocalTestAddReceived(val text: String) : MainAction
    data class LocalTestSendFile(val uri: android.net.Uri) : MainAction
    data class LocalTestDownloadFile(val ref: com.v2ray.ang.handler.FileRef) : MainAction
    data class LocalTestSaveFile(val ref: com.v2ray.ang.handler.FileRef, val uri: android.net.Uri) : MainAction
    data class LocalTestOpenProfile(val ip: String) : MainAction
    data object LocalTestCloseProfile : MainAction
    data class LocalTestSaveProfileName(val name: String) : MainAction
    data class LocalTestSetAvatar(val uri: android.net.Uri) : MainAction
    data object LocalTestClearAvatar : MainAction
    data class LocalTestSetBanner(val uri: android.net.Uri) : MainAction
    data object LocalTestClearBanner : MainAction
    data object LocalTestDisconnect : MainAction

    /** Menu "Update config": fetch from the saved server, else find one on the network, else ask for its IP. */
    data object UpdateConfig : MainAction
    data class UpdateConfigWithAddress(val address: String) : MainAction
    data object UpdateConfigAddressDismissed : MainAction

    /** Telegram tab: save proxies found in [text], then ping them and look up their country. */
    data class TelegramAdd(val text: String) : MainAction
    data object TelegramTestAll : MainAction
    data class TelegramRemove(val id: String) : MainAction
    data object TelegramRemoveAll : MainAction
}
