package com.v2ray.ang.ui.main

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.min

private val SplashBgTop = Color(0xFF1E1656)
private val SplashBgBottom = Color(0xFF0A0620)
private val ShieldBlue = Color(0xFF4F8BFF)
private val ShieldViolet = Color(0xFF8B5CF6)

// Shield geometry in the same 108 x 108 space as the launcher icon.
private const val SHIELD_CENTER_X = 54f
private const val SHIELD_CENTER_Y = 54.75f
private const val SHIELD_HEIGHT = 59.5f

/** Total splash length. The shield lands at ~0.4s, the ring draws, then the whole screen fades out. */
private const val SPLASH_TOTAL_MS = 3000
private const val FADE_OUT_MS = 550

/**
 * Full-screen intro: the shield rushes in from above, slams onto the screen, bounces once with a
 * shockwave, the open ring draws itself, then everything fades out so the app underneath shows.
 * Calls [onFinished] after [SPLASH_TOTAL_MS].
 */
@Composable
fun ShieldSplash(onFinished: () -> Unit) {
    val fly = remember { Animatable(0f) }
    val impact = remember { Animatable(0f) }
    val wave = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    val dot = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val shield = remember { shieldPath() }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch {
                // Strong ease-in so the shield arrives at full speed, like it is thrown at the screen.
                fly.animateTo(1f, tween(380, easing = CubicBezierEasing(0.55f, 0f, 1f, 0.45f)))
                impact.snapTo(1f)
                launch { wave.animateTo(1f, tween(750, easing = LinearOutSlowInEasing)) }
                launch {
                    impact.animateTo(0f, spring(dampingRatio = 0.3f, stiffness = Spring.StiffnessMediumLow))
                }
            }
            launch {
                delay(520)
                ring.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
                dot.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
            }
            launch {
                delay((SPLASH_TOTAL_MS - FADE_OUT_MS).toLong())
                fade.animateTo(1f, tween(FADE_OUT_MS))
                onFinished()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - fade.value }
            .background(Brush.verticalGradient(listOf(SplashBgTop, SplashBgBottom)))
            // Swallow touches so nothing underneath reacts while the intro plays.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val unit = min(size.width, size.height) * 0.36f / SHIELD_HEIGHT
            val center = Offset(size.width / 2f, size.height / 2f)
            val p = fly.value

            // Shockwave ring that leaves the impact point.
            if (wave.value > 0f && wave.value < 1f) {
                val r = SHIELD_HEIGHT * unit * (0.35f + 0.9f * wave.value)
                drawCircle(
                    color = ShieldViolet.copy(alpha = 0.35f * (1f - wave.value)),
                    radius = r,
                    center = center,
                    style = Stroke(width = 3f * unit * 0.5f + 2f),
                )
            }

            // Speed trail while flying in.
            if (p < 1f) {
                for (g in 3 downTo 1) {
                    val pg = (p - 0.07f * g).coerceAtLeast(0f)
                    drawShield(shield, center, unit, pg, 1f, 1f, 0.16f / g)
                }
            }

            val squash = 0.10f * impact.value
            drawShield(
                path = shield,
                center = center,
                unit = unit,
                progress = p,
                scaleX = 1f + squash,
                scaleY = 1f - squash,
                alpha = (p * 4f).coerceIn(0f, 1f),
                ring = ring.value,
                dot = dot.value,
                withGlyph = true,
            )
        }
    }
}

private fun shieldPath() = Path().apply {
    moveTo(54f, 25f)
    cubicTo(60f, 29.5f, 68f, 32.5f, 76f, 33.5f)
    lineTo(76f, 53f)
    cubicTo(76f, 68f, 66f, 78f, 54f, 84.5f)
    cubicTo(42f, 78f, 32f, 68f, 32f, 53f)
    lineTo(32f, 33.5f)
    cubicTo(40f, 32.5f, 48f, 29.5f, 54f, 25f)
    close()
}

private fun DrawScope.drawShield(
    path: Path,
    center: Offset,
    unit: Float,
    progress: Float,
    scaleX: Float,
    scaleY: Float,
    alpha: Float,
    ring: Float = 0f,
    dot: Float = 0f,
    withGlyph: Boolean = false,
) {
    val fromAbove = (1f - progress) * size.height * 0.55f
    val flyScale = 1f + (1f - progress) * 1.4f
    withTransform({
        translate(center.x, center.y - fromAbove)
        scale(unit * flyScale * scaleX, unit * flyScale * scaleY, pivot = Offset.Zero)
        translate(-SHIELD_CENTER_X, -SHIELD_CENTER_Y)
    }) {
        drawPath(
            path = path,
            brush = Brush.linearGradient(
                colors = listOf(ShieldBlue, ShieldViolet),
                start = Offset(32f, 25f),
                end = Offset(76f, 85f),
            ),
            alpha = alpha,
        )
        if (withGlyph && ring > 0f) {
            // Open ring: starts just below the gap, sweeps clockwise.
            drawArc(
                color = Color.White,
                startAngle = -5f,
                sweepAngle = 280f * ring,
                useCenter = false,
                topLeft = Offset(54f - 12f, 52f - 12f),
                size = Size(24f, 24f),
                alpha = alpha,
                style = Stroke(width = 4.6f, cap = StrokeCap.Round),
            )
        }
        if (withGlyph && dot > 0f) {
            drawCircle(
                color = Color.White,
                radius = 2.5f * dot,
                center = Offset(62.49f, 43.51f),
                alpha = alpha,
            )
        }
    }
}
